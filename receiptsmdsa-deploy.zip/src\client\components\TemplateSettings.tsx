import React, { useState } from 'react';
import {
  Palette,
  Building,
  Upload,
  QrCode,
  FileCheck,
  Save,
  MessageSquare,
  Check,
  RefreshCw,
  Eye,
  Sliders,
} from 'lucide-react';
import { Settings } from '../types';
import { DigitalReceiptTemplate } from './DigitalReceiptTemplate';

interface Props {
  settings: Settings;
  onSettingsUpdated: (newSettings: Settings) => void;
}

export const TemplateSettings: React.FC<Props> = ({ settings, onSettingsUpdated }) => {
  const [formData, setFormData] = useState<Settings>({ ...settings });
  const [activeTab, setActiveTab] = useState<'branding' | 'styling' | 'whatsapp' | 'preview'>('branding');
  const [savedSuccess, setSavedSuccess] = useState<boolean>(false);
  const [isSaving, setIsSaving] = useState<boolean>(false);

  // Handle text input change
  const handleChange = (key: keyof Settings, value: string) => {
    setFormData((prev) => ({ ...prev, [key]: value }));
  };

  // Handle Logo Upload (Base64)
  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        if (reader.result) {
          handleChange('logo_image', reader.result as string);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  // Handle Signature Upload (Base64)
  const handleSignatureUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        if (reader.result) {
          handleChange('signature_image', reader.result as string);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  // Themes list
  const themePresets = [
    { id: 'classic-emerald', name: 'Classic Emerald', color: '#059669', bg: 'bg-emerald-600' },
    { id: 'royal-navy', name: 'Royal Navy', color: '#1e3a8a', bg: 'bg-blue-900' },
    { id: 'burgundy-crimson', name: 'Burgundy Crimson', color: '#9f1239', bg: 'bg-rose-800' },
    { id: 'modern-slate', name: 'Charcoal Slate', color: '#334155', bg: 'bg-slate-700' },
    { id: 'golden-amber', name: 'Golden Amber', color: '#b45309', bg: 'bg-amber-700' },
  ];

  // Save settings to backend
  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    setSavedSuccess(false);

    try {
      const res = await fetch('/api/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });

      const data = await res.json();
      if (data.settings) {
        onSettingsUpdated(data.settings);
        setSavedSuccess(true);
        setTimeout(() => setSavedSuccess(false), 3000);
      }
    } catch (err) {
      console.error('Failed to save settings:', err);
    } finally {
      setIsSaving(false);
    }
  };

  // Mock receipt for live preview
  const samplePreviewReceipt = {
    id: 999,
    receipt_number: `${formData.receipt_prefix || 'REC'}-2026-1001`,
    receipt_date: new Date().toISOString().split('T')[0],
    customer_name: 'Al-Madina Trading Co.',
    customer_phone: '+91 98470 54321',
    customer_address: 'Suite 302, Diamond Commercial Tower, Calicut',
    description: 'Hardware licensing and digital paperless POS implementation fee',
    amount: 18500,
    paid_amount: 18500,
    balance_amount: 0,
    payment_method: 'UPI',
    transaction_id: 'UPI/20261109/982104',
    payment_status: 'Paid' as const,
    remarks: 'Official digital acknowledgement. Retain for warranty claims.',
    items_json: JSON.stringify([
      { description: 'Paperless Digital POS Terminal Setup', quantity: 1, rate: 12000, amount: 12000 },
      { description: 'System Annual Cloud Maintenance (Q1-Q4)', quantity: 1, rate: 6500, amount: 6500 },
    ]),
    whatsapp_status: 'Not Sent',
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  };

  return (
    <div className="space-y-5">
      {/* Top Banner */}
      <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
            <Sliders className="w-5 h-5 text-emerald-600" /> Receipt Template & Branding Designer
          </h2>
          <p className="text-xs text-slate-500">
            Configure your organization branding, upload logo, customize colors, signatures and WhatsApp defaults
          </p>
        </div>

        {savedSuccess && (
          <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs px-3 py-1.5 rounded-lg flex items-center gap-1.5 font-semibold">
            <Check className="w-4 h-4 text-emerald-600" /> Settings Saved!
          </div>
        )}
      </div>

      {/* Tabs */}
      <div className="flex border-b border-slate-200 bg-white rounded-t-2xl px-4 pt-3 gap-2">
        {[
          { id: 'branding', label: 'Organization & Logo', icon: Building },
          { id: 'styling', label: 'Colors & Signatures', icon: Palette },
          { id: 'whatsapp', label: 'WhatsApp & Cloud API', icon: MessageSquare },
          { id: 'preview', label: 'Live Receipt Preview', icon: Eye },
        ].map((tab) => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => setActiveTab(tab.id as any)}
              className={`pb-3 px-3 text-xs font-bold border-b-2 flex items-center gap-1.5 transition-all ${
                activeTab === tab.id
                  ? 'border-emerald-600 text-emerald-700'
                  : 'border-transparent text-slate-500 hover:text-slate-800'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Tab Panels */}
      <div className="bg-white rounded-b-2xl border-x border-b border-slate-200 shadow-sm p-5 sm:p-7">
        <form onSubmit={handleSave} className="space-y-6">
          {/* TAB 1: Organization & Logo */}
          {activeTab === 'branding' && (
            <div className="space-y-4 animate-fadeIn">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold uppercase text-slate-700 mb-1">
                    Organization / Company Name
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.org_name || ''}
                    onChange={(e) => handleChange('org_name', e.target.value)}
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-300 font-bold text-slate-900 text-sm focus:outline-none focus:ring-1 focus:ring-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase text-slate-700 mb-1">
                    Tagline / Subtitle
                  </label>
                  <input
                    type="text"
                    value={formData.org_tagline || ''}
                    onChange={(e) => handleChange('org_tagline', e.target.value)}
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-slate-800 text-sm focus:outline-none focus:ring-1 focus:ring-emerald-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase text-slate-700 mb-1">
                  Full Registered Address
                </label>
                <input
                  type="text"
                  value={formData.org_address || ''}
                  onChange={(e) => handleChange('org_address', e.target.value)}
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-slate-800 text-sm focus:outline-none focus:ring-1 focus:ring-emerald-500"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold uppercase text-slate-700 mb-1">
                    Contact Phone Number
                  </label>
                  <input
                    type="text"
                    value={formData.org_phone || ''}
                    onChange={(e) => handleChange('org_phone', e.target.value)}
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-slate-800 text-sm focus:outline-none focus:ring-1 focus:ring-emerald-500 font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase text-slate-700 mb-1">
                    Official Email
                  </label>
                  <input
                    type="email"
                    value={formData.org_email || ''}
                    onChange={(e) => handleChange('org_email', e.target.value)}
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-slate-800 text-sm focus:outline-none focus:ring-1 focus:ring-emerald-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold uppercase text-slate-700 mb-1">
                    Tax / GST Number / VAT ID
                  </label>
                  <input
                    type="text"
                    value={formData.org_tax_id || ''}
                    onChange={(e) => handleChange('org_tax_id', e.target.value)}
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-slate-800 text-sm focus:outline-none focus:ring-1 focus:ring-emerald-500 font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase text-slate-700 mb-1">
                    Registration / License Number
                  </label>
                  <input
                    type="text"
                    value={formData.org_reg_no || ''}
                    onChange={(e) => handleChange('org_reg_no', e.target.value)}
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-slate-800 text-sm focus:outline-none focus:ring-1 focus:ring-emerald-500 font-mono"
                  />
                </div>
              </div>

              {/* Logo Upload Box */}
              <div className="border border-slate-200 rounded-xl p-4 bg-slate-50/50">
                <label className="block text-xs font-bold uppercase text-slate-700 mb-2">
                  Organization Logo Image
                </label>
                <div className="flex flex-col sm:flex-row items-center gap-4">
                  {formData.logo_image ? (
                    <div className="w-20 h-20 rounded-xl border border-slate-200 bg-white p-1 flex items-center justify-center overflow-hidden">
                      <img
                        src={formData.logo_image}
                        alt="Logo Preview"
                        className="max-h-full max-w-full object-contain"
                      />
                    </div>
                  ) : (
                    <div className="w-20 h-20 rounded-xl border-2 border-dashed border-slate-300 bg-white flex items-center justify-center text-slate-400 text-xs text-center p-2">
                      No Logo
                    </div>
                  )}

                  <div className="flex-1 space-y-2">
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleLogoUpload}
                      className="text-xs text-slate-500 file:mr-3 file:py-2 file:px-4 file:rounded-xl file:border-0 file:text-xs file:font-semibold file:bg-emerald-50 file:text-emerald-700 hover:file:bg-emerald-100 cursor-pointer"
                    />
                    {formData.logo_image && (
                      <button
                        type="button"
                        onClick={() => handleChange('logo_image', '')}
                        className="text-xs text-rose-600 hover:text-rose-700 font-semibold block"
                      >
                        Remove Logo
                      </button>
                    )}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: Colors & Signatures */}
          {activeTab === 'styling' && (
            <div className="space-y-4 animate-fadeIn">
              {/* Color Preset Palette */}
              <div>
                <label className="block text-xs font-bold uppercase text-slate-700 mb-2">
                  Receipt Theme Color Accent
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
                  {themePresets.map((tp) => (
                    <button
                      key={tp.id}
                      type="button"
                      onClick={() => {
                        handleChange('theme_style', tp.id);
                        handleChange('primary_color', tp.color);
                      }}
                      className={`p-3 rounded-xl border text-center transition-all ${
                        formData.primary_color === tp.color
                          ? 'border-slate-800 ring-2 ring-slate-800/20 bg-slate-50'
                          : 'border-slate-200 hover:bg-slate-50'
                      }`}
                    >
                      <div className={`w-8 h-8 rounded-full mx-auto mb-2 ${tp.bg} shadow-sm`}></div>
                      <span className="text-xs font-bold text-slate-800 block">{tp.name}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Numbering Prefix & Currency Symbol */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold uppercase text-slate-700 mb-1">
                    Receipt Number Prefix
                  </label>
                  <input
                    type="text"
                    value={formData.receipt_prefix || 'REC'}
                    onChange={(e) => handleChange('receipt_prefix', e.target.value)}
                    placeholder="e.g. REC"
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-300 font-mono font-bold text-sm"
                  />
                  <span className="text-[11px] text-slate-400 mt-1 block">
                    Receipt format will be: {formData.receipt_prefix || 'REC'}-2026-1001
                  </span>
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase text-slate-700 mb-1">
                    Currency Symbol
                  </label>
                  <div className="flex gap-2">
                    {['₹', '$', 'AED', 'SAR', '€', '£'].map((sym) => (
                      <button
                        key={sym}
                        type="button"
                        onClick={() => handleChange('currency_symbol', sym)}
                        className={`px-3 py-1.5 rounded-lg border text-xs font-bold font-mono ${
                          formData.currency_symbol === sym
                            ? 'bg-emerald-600 text-white border-emerald-600'
                            : 'bg-white border-slate-200 text-slate-700'
                        }`}
                      >
                        {sym}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Signatory Settings */}
              <div className="border border-slate-200 rounded-xl p-4 bg-slate-50/50 space-y-3">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold uppercase text-slate-700">
                    Authorized Signatory Details
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer text-xs font-medium text-slate-600">
                    <input
                      type="checkbox"
                      checked={formData.show_signature !== 'false'}
                      onChange={(e) => handleChange('show_signature', e.target.checked ? 'true' : 'false')}
                      className="rounded text-emerald-600"
                    />
                    Include Signature on Receipt
                  </label>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <span className="text-xs text-slate-500 block mb-1">Signatory Name</span>
                    <input
                      type="text"
                      value={formData.signatory_name || ''}
                      onChange={(e) => handleChange('signatory_name', e.target.value)}
                      placeholder="e.g. Authorized Signatory"
                      className="w-full px-3 py-1.5 rounded-lg border border-slate-300 text-xs"
                    />
                  </div>
                  <div>
                    <span className="text-xs text-slate-500 block mb-1">Signatory Title</span>
                    <input
                      type="text"
                      value={formData.signatory_title || ''}
                      onChange={(e) => handleChange('signatory_title', e.target.value)}
                      placeholder="e.g. Accounts Department"
                      className="w-full px-3 py-1.5 rounded-lg border border-slate-300 text-xs"
                    />
                  </div>
                </div>

                {/* Signature Image Upload */}
                <div>
                  <span className="text-xs text-slate-500 block mb-1">Signature Image (Optional)</span>
                  <div className="flex items-center gap-3">
                    {formData.signature_image && (
                      <div className="h-12 border border-slate-200 bg-white p-1 rounded">
                        <img src={formData.signature_image} alt="Signature" className="h-full object-contain" />
                      </div>
                    )}
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleSignatureUpload}
                      className="text-xs text-slate-500 file:mr-2 file:py-1 file:px-3 file:rounded-lg file:border-0 file:text-xs file:font-semibold file:bg-slate-200"
                    />
                    {formData.signature_image && (
                      <button
                        type="button"
                        onClick={() => handleChange('signature_image', '')}
                        className="text-xs text-rose-600 font-semibold"
                      >
                        Clear
                      </button>
                    )}
                  </div>
                </div>
              </div>

              {/* Terms and Conditions */}
              <div>
                <label className="block text-xs font-bold uppercase text-slate-700 mb-1">
                  Footer Terms & Conditions / Remarks
                </label>
                <textarea
                  rows={3}
                  value={formData.terms_and_conditions || ''}
                  onChange={(e) => handleChange('terms_and_conditions', e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs leading-relaxed"
                />
              </div>
            </div>
          )}

          {/* TAB 3: WhatsApp & Cloud API */}
          {activeTab === 'whatsapp' && (
            <div className="space-y-4 animate-fadeIn">
              <div>
                <label className="block text-xs font-bold uppercase text-slate-700 mb-1">
                  Default WhatsApp Message Template
                </label>
                <p className="text-[11px] text-slate-500 mb-2">
                  Variables supported: [Customer Name], [Receipt Number], [Date], [Amount], [Currency], [Method], [Description], [Status], [Organization Name], [Additional Message]
                </p>
                <textarea
                  rows={9}
                  value={formData.whatsapp_default_message || ''}
                  onChange={(e) => handleChange('whatsapp_default_message', e.target.value)}
                  className="w-full font-mono text-xs p-3 rounded-xl border border-slate-300 bg-slate-50/50 leading-relaxed"
                />
              </div>

              {/* Official WhatsApp Business Cloud API Configuration */}
              <div className="border border-slate-200 rounded-xl p-4 bg-slate-50/50 space-y-3">
                <div className="flex items-center gap-2">
                  <MessageSquare className="w-4 h-4 text-emerald-600" />
                  <span className="text-xs font-bold uppercase text-slate-800">
                    Official WhatsApp Business Cloud API (Optional Advanced Integration)
                  </span>
                </div>
                <p className="text-[11px] text-slate-500 leading-relaxed">
                  Enter your Meta Graph API credentials if you wish to dispatch receipts automatically via server-to-server WhatsApp Cloud API. Otherwise, the 1-click WhatsApp Click-to-Chat works out-of-the-box!
                </p>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Phone Number ID
                    </label>
                    <input
                      type="text"
                      value={formData.whatsapp_cloud_api_phone_id || ''}
                      onChange={(e) => handleChange('whatsapp_cloud_api_phone_id', e.target.value)}
                      placeholder="e.g. 1048291039821"
                      className="w-full px-3 py-1.5 rounded-lg border border-slate-300 text-xs font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Permanent Access Token
                    </label>
                    <input
                      type="password"
                      value={formData.whatsapp_cloud_api_token || ''}
                      onChange={(e) => handleChange('whatsapp_cloud_api_token', e.target.value)}
                      placeholder="EAAGm..."
                      className="w-full px-3 py-1.5 rounded-lg border border-slate-300 text-xs font-mono"
                    />
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: Live Receipt Preview */}
          {activeTab === 'preview' && (
            <div className="animate-fadeIn space-y-3">
              <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-800 text-xs flex items-center justify-between">
                <span>👁️ Live Preview reflects your currently configured branding, colors, and layout:</span>
                <span className="font-bold">Sample Receipt #{samplePreviewReceipt.receipt_number}</span>
              </div>
              <div className="overflow-x-auto p-4 bg-slate-100 rounded-xl flex justify-center">
                <div className="w-full max-w-2xl">
                  <DigitalReceiptTemplate
                    receipt={samplePreviewReceipt}
                    settings={formData}
                  />
                </div>
              </div>
            </div>
          )}

          {/* Save Button */}
          <div className="pt-4 border-t border-slate-200 flex justify-end">
            <button
              type="submit"
              disabled={isSaving}
              className="px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs sm:text-sm flex items-center gap-2 shadow-md transition-all disabled:opacity-50"
            >
              <Save className="w-4 h-4" />
              {isSaving ? 'Saving Settings...' : 'Save Template Settings'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};


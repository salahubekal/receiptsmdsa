import React, { useState, useEffect } from 'react';
import { MessageSquare, Send, Copy, Download, Share2, Check, AlertCircle, FileText, Image as ImageIcon, ExternalLink, X } from 'lucide-react';
import { Receipt, Settings } from '../types';
import {
  composeWhatsAppMessage,
  getWhatsAppClickToChatUrl,
  shareViaWebShareApi,
  formatPhoneNumberForWhatsApp,
} from '../utils/whatsappHelper';
import { generateReceiptPdf } from '../utils/pdfGenerator';
import { generateReceiptImage, getReceiptImageFile } from '../utils/imageGenerator';

interface Props {
  receipt: Receipt;
  settings: Partial<Settings>;
  isOpen: boolean;
  onClose: () => void;
  onStatusUpdated?: () => void;
}

export const WhatsAppShareModal: React.FC<Props> = ({
  receipt,
  settings,
  isOpen,
  onClose,
  onStatusUpdated,
}) => {
  if (!isOpen || !receipt) return null;

  const [messageText, setMessageText] = useState<string>('');
  const [additionalNote, setAdditionalNote] = useState<string>('');
  const [copied, setCopied] = useState<boolean>(false);
  const [isGeneratingFile, setIsGeneratingFile] = useState<boolean>(false);
  const [activeTemplate, setActiveTemplate] = useState<'standard' | 'thankyou' | 'reminder'>('standard');
  const [cloudApiLoading, setCloudApiLoading] = useState<boolean>(false);
  const [cloudApiSuccess, setCloudApiSuccess] = useState<string | null>(null);
  const [cloudApiError, setCloudApiError] = useState<string | null>(null);

  // Template variations
  const templates = {
    standard: `Dear [Customer Name],

Thank you for your payment.

Please find your digital receipt details attached:

📄 *Receipt No:* [Receipt Number]
📅 *Date:* [Date]
💰 *Amount:* [Currency] [Amount]
💳 *Payment Method:* [Method]
📝 *Description:* [Description]
📊 *Payment Status:* [Status]

Additional Details:
[Additional Message]

Thank you for choosing [Organization Name]!
_[Organization Name]_`,

    thankyou: `Dear [Customer Name],

Thank you very much! We have received your payment of *[Currency] [Amount]* with thanks.

Receipt Details:
• Receipt: [Receipt Number]
• Date: [Date]
• Description: [Description]
• Method: [Method]

[Additional Message]

We truly value your trust and look forward to serving you again!
Best regards,
*[Organization Name]*`,

    reminder: `Dear [Customer Name],

This is an acknowledgment of your partial payment of *[Currency] [Paid Amount]* against Receipt #[Receipt Number].

• Total Amount: [Currency] [Amount]
• Amount Paid: [Currency] [Paid Amount]
• *Remaining Balance Due: [Currency] [Balance Amount]*
• Date: [Date]

Note:
[Additional Message]

Please let us know once the balance settlement is completed.
Thank you,
*[Organization Name]*`,
  };

  useEffect(() => {
    const rawTemplate = templates[activeTemplate];
    const composed = composeWhatsAppMessage(rawTemplate, receipt, settings, additionalNote);
    setMessageText(composed);
  }, [activeTemplate, additionalNote, receipt]);

  const cleanPhone = formatPhoneNumberForWhatsApp(receipt.customer_phone || '');
  const clickToChatUrl = getWhatsAppClickToChatUrl(cleanPhone, messageText);

  // Log status in database
  const logShareStatus = async (method: string) => {
    try {
      await fetch(`/api/receipts/${receipt.id}/whatsapp-status`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: `Shared via ${method}`, method }),
      });
      if (onStatusUpdated) onStatusUpdated();
    } catch (err) {
      console.error('Failed to log WhatsApp status:', err);
    }
  };

  // Open WhatsApp Web / App
  const handleOpenWhatsApp = () => {
    logShareStatus('Click-to-Chat');
    window.open(clickToChatUrl, '_blank');
  };

  // Copy Message to clipboard
  const handleCopyMessage = () => {
    navigator.clipboard.writeText(messageText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Native Web Share API (mobile direct file share)
  const handleNativeShare = async () => {
    setIsGeneratingFile(true);
    try {
      const imageFile = await getReceiptImageFile('digital-receipt-canvas', receipt.receipt_number);
      const shared = await shareViaWebShareApi({
        title: `Receipt ${receipt.receipt_number}`,
        text: messageText,
        files: [imageFile],
      });
      if (shared) {
        logShareStatus('Mobile Direct Share');
      }
    } catch (err) {
      console.error('Share failed, opening WhatsApp URL fallback:', err);
      handleOpenWhatsApp();
    } finally {
      setIsGeneratingFile(false);
    }
  };

  // Download PDF
  const handleDownloadPdf = async () => {
    setIsGeneratingFile(true);
    try {
      await generateReceiptPdf('digital-receipt-canvas', receipt.receipt_number);
      logShareStatus('PDF Downloaded for WhatsApp');
    } catch (err) {
      console.error('PDF error:', err);
    } finally {
      setIsGeneratingFile(false);
    }
  };

  // Download Image
  const handleDownloadImage = async () => {
    setIsGeneratingFile(true);
    try {
      await generateReceiptImage('digital-receipt-canvas', receipt.receipt_number, 'png');
      logShareStatus('PNG Downloaded for WhatsApp');
    } catch (err) {
      console.error('Image error:', err);
    } finally {
      setIsGeneratingFile(false);
    }
  };

  // Official WhatsApp Business Cloud API send
  const handleSendCloudApi = async () => {
    setCloudApiLoading(true);
    setCloudApiError(null);
    setCloudApiSuccess(null);

    try {
      const res = await fetch('/api/whatsapp/send-cloud', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          receiptId: receipt.id,
          phoneNumber: receipt.customer_phone,
          messageText,
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        setCloudApiError(data.error || 'Cloud API send failed');
      } else {
        setCloudApiSuccess('Message dispatched via official WhatsApp Business API!');
        if (onStatusUpdated) onStatusUpdated();
      }
    } catch (err: any) {
      setCloudApiError(err.message || 'Network error');
    } finally {
      setCloudApiLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-fadeIn">
      <div className="bg-white rounded-2xl shadow-2xl max-w-xl w-full max-h-[92vh] flex flex-col overflow-hidden border border-slate-100">
        {/* Header */}
        <div className="bg-emerald-600 text-white p-4 sm:p-5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center text-white backdrop-blur-sm">
              <MessageSquare className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-lg font-bold">Share Receipt on WhatsApp</h2>
              <p className="text-xs text-emerald-100">
                To: <span className="font-semibold text-white">{receipt.customer_name}</span> ({receipt.customer_phone})
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body Content */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-4 text-sm">
          {/* Recipient summary banner */}
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5 flex items-center justify-between">
            <div>
              <span className="text-xs text-slate-500 font-medium block">Verified WhatsApp Target</span>
              <span className="text-sm font-bold text-slate-800 font-mono">
                +{cleanPhone}
              </span>
            </div>
            <span className="bg-emerald-100 text-emerald-800 text-xs px-2.5 py-1 rounded-full font-semibold flex items-center gap-1">
              <Check className="w-3.5 h-3.5" /> Ready to Send
            </span>
          </div>

          {/* Template Selectors */}
          <div>
            <label className="text-xs font-semibold text-slate-600 uppercase tracking-wider block mb-1.5">
              Choose Message Template
            </label>
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => setActiveTemplate('standard')}
                className={`py-2 px-3 text-xs rounded-lg font-medium border transition-all text-center ${
                  activeTemplate === 'standard'
                    ? 'bg-emerald-50 border-emerald-500 text-emerald-800 font-bold shadow-sm'
                    : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                }`}
              >
                Standard Receipt
              </button>
              <button
                type="button"
                onClick={() => setActiveTemplate('thankyou')}
                className={`py-2 px-3 text-xs rounded-lg font-medium border transition-all text-center ${
                  activeTemplate === 'thankyou'
                    ? 'bg-emerald-50 border-emerald-500 text-emerald-800 font-bold shadow-sm'
                    : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                }`}
              >
                Payment Thanks
              </button>
              <button
                type="button"
                onClick={() => setActiveTemplate('reminder')}
                className={`py-2 px-3 text-xs rounded-lg font-medium border transition-all text-center ${
                  activeTemplate === 'reminder'
                    ? 'bg-emerald-50 border-emerald-500 text-emerald-800 font-bold shadow-sm'
                    : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                }`}
              >
                Balance Reminder
              </button>
            </div>
          </div>

          {/* Additional Note input */}
          <div>
            <label className="text-xs font-semibold text-slate-600 block mb-1">
              Add Personal Note / Payment Details
            </label>
            <input
              type="text"
              value={additionalNote}
              onChange={(e) => setAdditionalNote(e.target.value)}
              placeholder="e.g. Warranty valid for 1 year. Thank you for visiting!"
              className="w-full text-xs sm:text-sm px-3.5 py-2.5 rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-500/30 focus:border-emerald-500"
            />
          </div>

          {/* Editable WhatsApp Message Preview */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="text-xs font-semibold text-slate-600 uppercase tracking-wider">
                Review & Edit Message
              </label>
              <button
                type="button"
                onClick={handleCopyMessage}
                className="text-xs text-emerald-600 hover:text-emerald-700 font-medium flex items-center gap-1"
              >
                {copied ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-600" /> Copied!
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" /> Copy Text
                  </>
                )}
              </button>
            </div>
            <textarea
              rows={8}
              value={messageText}
              onChange={(e) => setMessageText(e.target.value)}
              className="w-full font-mono text-xs sm:text-sm p-3 rounded-xl border border-slate-300 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500/30 focus:border-emerald-500 leading-relaxed"
            />
          </div>

          {/* Receipt File Downloads for manual attachment */}
          <div className="bg-emerald-50/60 border border-emerald-100 rounded-xl p-3.5">
            <span className="text-xs font-semibold text-emerald-950 block mb-2">
              📎 Attach Receipt File (PDF or Image)
            </span>
            <div className="flex flex-wrap gap-2">
              <button
                type="button"
                onClick={handleDownloadPdf}
                disabled={isGeneratingFile}
                className="flex-1 py-2 px-3 rounded-lg bg-white border border-emerald-200 text-emerald-800 text-xs font-semibold hover:bg-emerald-100/50 flex items-center justify-center gap-1.5 transition-colors shadow-sm disabled:opacity-50"
              >
                <FileText className="w-4 h-4 text-emerald-600" />
                Download PDF
              </button>
              <button
                type="button"
                onClick={handleDownloadImage}
                disabled={isGeneratingFile}
                className="flex-1 py-2 px-3 rounded-lg bg-white border border-emerald-200 text-emerald-800 text-xs font-semibold hover:bg-emerald-100/50 flex items-center justify-center gap-1.5 transition-colors shadow-sm disabled:opacity-50"
              >
                <ImageIcon className="w-4 h-4 text-emerald-600" />
                Download Image
              </button>
            </div>
          </div>

          {/* Cloud API status notices if used */}
          {cloudApiSuccess && (
            <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs rounded-lg flex items-center gap-2">
              <Check className="w-4 h-4 text-emerald-600" />
              <span>{cloudApiSuccess}</span>
            </div>
          )}
          {cloudApiError && (
            <div className="p-3 bg-amber-50 border border-amber-200 text-amber-800 text-xs rounded-lg flex items-start gap-2">
              <AlertCircle className="w-4 h-4 text-amber-600 flex-shrink-0 mt-0.5" />
              <div className="space-y-1">
                <span>{cloudApiError}</span>
                <span className="block text-[11px] text-amber-600">
                  Tip: Use the big "Open in WhatsApp" button below to chat immediately without API keys!
                </span>
              </div>
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="bg-slate-50 p-4 border-t border-slate-200 flex flex-col sm:flex-row gap-2.5">
          {/* Native Web Share API button */}
          {'share' in navigator && (
            <button
              type="button"
              onClick={handleNativeShare}
              disabled={isGeneratingFile}
              className="py-2.5 px-4 rounded-xl bg-slate-800 text-white hover:bg-slate-900 text-xs sm:text-sm font-semibold flex items-center justify-center gap-2 shadow-sm transition-all"
            >
              <Share2 className="w-4 h-4" />
              Direct Share (Mobile)
            </button>
          )}

          {/* Primary Open WhatsApp Button */}
          <button
            type="button"
            onClick={handleOpenWhatsApp}
            className="flex-1 py-3 px-5 rounded-xl bg-emerald-600 hover:bg-emerald-700 active:scale-[0.99] text-white text-sm font-bold flex items-center justify-center gap-2 shadow-md shadow-emerald-600/20 transition-all"
          >
            <Send className="w-4 h-4" />
            Open in WhatsApp
            <ExternalLink className="w-3.5 h-3.5 opacity-80" />
          </button>

          {/* Cloud API Option */}
          {settings.whatsapp_cloud_api_token && (
            <button
              type="button"
              onClick={handleSendCloudApi}
              disabled={cloudApiLoading}
              className="py-2.5 px-4 rounded-xl bg-blue-600 text-white hover:bg-blue-700 text-xs font-semibold flex items-center justify-center gap-1.5 shadow-sm transition-all disabled:opacity-50"
            >
              {cloudApiLoading ? 'Dispatching...' : 'Send via Cloud API'}
            </button>
          )}
        </div>
      </div>
    </div>
  );
};


import React, { useState, useEffect } from 'react';
import {
  X,
  User,
  Phone,
  Mail,
  GraduationCap,
  Calendar,
  CheckCircle,
  Clock,
  AlertTriangle,
  FileText,
  Download,
  Eye,
  Check,
  Flag,
  Share2,
  RefreshCw,
  Search,
} from 'lucide-react';
import { Receipt, Settings, PaymentRecord } from '../types';
import { generateReceiptPdf } from '../utils/pdfGenerator';

interface Props {
  isOpen: boolean;
  studentId: string | null;
  settings: Partial<Settings>;
  onClose: () => void;
  onViewReceipt: (receipt: Receipt) => void;
  onReceiptUpdated?: () => void;
}

export const StudentDetailReportModal: React.FC<Props> = ({
  isOpen,
  studentId,
  settings,
  onClose,
  onViewReceipt,
  onReceiptUpdated,
}) => {
  const currency = settings.currency_symbol || '₹';
  const token = localStorage.getItem('receipt_auth_token');

  const [student, setStudent] = useState<any>(null);
  const [stats, setStats] = useState<any>(null);
  const [payments, setPayments] = useState<PaymentRecord[]>([]);
  const [receipts, setReceipts] = useState<Receipt[]>([]);
  const [loading, setLoading] = useState<boolean>(true);

  const [startDate, setStartDate] = useState<string>('');
  const [endDate, setEndDate] = useState<string>('');
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [verifyingId, setVerifyingId] = useState<number | null>(null);
  const [actionSuccess, setActionSuccess] = useState<string | null>(null);

  const fetchStudentDetails = async () => {
    if (!studentId) return;
    setLoading(true);
    try {
      let url = `/api/payments/student/${encodeURIComponent(studentId)}`;
      const params = new URLSearchParams();
      if (startDate) params.append('startDate', startDate);
      if (endDate) params.append('endDate', endDate);
      if (params.toString()) url += `?${params.toString()}`;

      const res = await fetch(url, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      const data = await res.json();
      if (res.ok) {
        setStudent(data.student);
        setStats(data.stats);
        setPayments(data.payments || []);
        setReceipts(data.receipts || []);
      }
    } catch (err) {
      console.error('Failed to load student detail report:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen && studentId) {
      fetchStudentDetails();
    }
  }, [isOpen, studentId, startDate, endDate]);

  const handleVerifyPayment = async (paymentId: number, status: 'Admin Verified' | 'Flagged') => {
    setVerifyingId(paymentId);
    try {
      const res = await fetch(`/api/payments/${paymentId}/verify`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          status,
          remarks: status === 'Admin Verified' ? 'Verified by Administrator' : 'Flagged for audit review',
        }),
      });

      if (res.ok) {
        setActionSuccess(`Payment #${paymentId} marked as ${status}`);
        setTimeout(() => setActionSuccess(null), 3000);
        fetchStudentDetails();
        if (onReceiptUpdated) onReceiptUpdated();
      }
    } catch (err) {
      console.error('Failed to update verification status:', err);
    } finally {
      setVerifyingId(null);
    }
  };

  const handleDownloadPdf = async (receiptNumber: string) => {
    const matched = receipts.find((r) => r.receipt_number === receiptNumber);
    if (matched) {
      onViewReceipt(matched);
      setTimeout(async () => {
        await generateReceiptPdf('preview-receipt-container', matched.receipt_number);
      }, 300);
    }
  };

  if (!isOpen) return null;

  const filteredPayments = payments.filter((p) => {
    const term = searchTerm.toLowerCase();
    return (
      p.receipt_number.toLowerCase().includes(term) ||
      p.payer_name.toLowerCase().includes(term) ||
      p.payer_phone.includes(term) ||
      p.payment_purpose.toLowerCase().includes(term) ||
      (p.transaction_ref && p.transaction_ref.toLowerCase().includes(term))
    );
  });

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-3 sm:p-5">
      <div className="bg-white rounded-3xl shadow-2xl border border-slate-200 w-full max-w-5xl max-h-[92vh] flex flex-col overflow-hidden animate-scaleUp">
        {/* Top Header */}
        <div className="bg-gradient-to-r from-blue-900 via-indigo-900 to-purple-900 text-white p-5 sm:p-6 flex items-start justify-between flex-shrink-0">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-2xl bg-white/10 backdrop-blur-md border border-white/20 flex items-center justify-center font-bold text-2xl text-white shadow-inner flex-shrink-0">
              <GraduationCap className="w-7 h-7 text-purple-300" />
            </div>
            <div>
              <div className="flex items-center gap-2.5">
                <h2 className="text-xl font-extrabold text-white">
                  {student?.name || 'Student Details'}
                </h2>
                <span className="bg-purple-400/20 text-purple-200 border border-purple-400/30 text-[11px] font-mono px-2.5 py-0.5 rounded-full font-bold">
                  {student?.student_id || studentId}
                </span>
              </div>
              <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-purple-200/90 mt-1">
                <span>{student?.class_name || 'MDSA Collector'}</span>
                {student?.phone && (
                  <span className="flex items-center gap-1">
                    <Phone className="w-3 h-3 text-purple-300" /> {student.phone}
                  </span>
                )}
                {student?.email && (
                  <span className="flex items-center gap-1">
                    <Mail className="w-3 h-3 text-purple-300" /> {student.email}
                  </span>
                )}
              </div>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="w-9 h-9 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Success toast notification inside modal */}
        {actionSuccess && (
          <div className="bg-emerald-600 text-white px-5 py-2.5 text-xs font-bold flex items-center justify-between">
            <span className="flex items-center gap-1.5">
              <Check className="w-4 h-4" /> {actionSuccess}
            </span>
            <button onClick={() => setActionSuccess(null)} className="text-white/80 hover:text-white">
              <X className="w-4 h-4" />
            </button>
          </div>
        )}

        {/* Modal Scrollable Body */}
        <div className="p-5 sm:p-6 overflow-y-auto space-y-6 flex-1 bg-slate-50">
          {/* 4 Summary Metric Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3.5">
            <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-sm">
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-1">
                Today's Collection
              </span>
              <div className="text-xl sm:text-2xl font-black font-mono text-purple-700">
                {currency} {Number(stats?.todayCollection || 0).toLocaleString()}
              </div>
              <span className="text-[10px] text-slate-500 mt-1 block">
                {stats?.todayPayments || 0} collections today
              </span>
            </div>

            <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-sm">
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-1">
                Today's Transactions
              </span>
              <div className="text-xl sm:text-2xl font-black font-mono text-slate-900">
                {stats?.todayPayments || 0}
              </div>
              <span className="text-[10px] text-slate-500 mt-1 block">
                Recorded today
              </span>
            </div>

            <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-sm">
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-1">
                Overall Collection
              </span>
              <div className="text-xl sm:text-2xl font-black font-mono text-emerald-700">
                {currency} {Number(stats?.overallCollection || 0).toLocaleString()}
              </div>
              <span className="text-[10px] text-slate-500 mt-1 block">
                Lifetime collection
              </span>
            </div>

            <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-sm">
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-1">
                Total Receipts
              </span>
              <div className="text-xl sm:text-2xl font-black font-mono text-indigo-700">
                {stats?.totalPayments || 0}
              </div>
              <span className="text-[10px] text-slate-500 mt-1 block">
                Issued receipts
              </span>
            </div>
          </div>

          {/* Filter & Search Toolbar */}
          <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
            <div className="flex-1 relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search payer, phone, receipt # or purpose..."
                className="w-full pl-9 pr-3 py-1.5 rounded-xl border border-slate-300 text-xs font-medium focus:outline-none focus:ring-1 focus:ring-purple-600"
              />
            </div>

            <div className="flex items-center gap-2">
              <div className="flex items-center gap-1.5 text-xs text-slate-600">
                <span className="text-[11px] font-bold text-slate-400 uppercase">From:</span>
                <input
                  type="date"
                  value={startDate}
                  onChange={(e) => setStartDate(e.target.value)}
                  className="px-2.5 py-1.5 rounded-xl border border-slate-300 text-xs font-medium focus:outline-none focus:ring-1 focus:ring-purple-600"
                />
              </div>

              <div className="flex items-center gap-1.5 text-xs text-slate-600">
                <span className="text-[11px] font-bold text-slate-400 uppercase">To:</span>
                <input
                  type="date"
                  value={endDate}
                  onChange={(e) => setEndDate(e.target.value)}
                  className="px-2.5 py-1.5 rounded-xl border border-slate-300 text-xs font-medium focus:outline-none focus:ring-1 focus:ring-purple-600"
                />
              </div>

              {(startDate || endDate) && (
                <button
                  type="button"
                  onClick={() => {
                    setStartDate('');
                    setEndDate('');
                  }}
                  className="px-2.5 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-600 text-xs font-bold"
                >
                  Clear
                </button>
              )}
            </div>
          </div>

          {/* Collection Receipts Table */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="p-4 border-b border-slate-200 bg-slate-50/60 flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-slate-900">
                  Payments Collected by {student?.name}
                </h3>
                <p className="text-xs text-slate-500">
                  Audit student collections, verify payments, and manage receipts
                </p>
              </div>
              <span className="text-xs font-bold bg-purple-100 text-purple-800 px-3 py-1 rounded-full">
                {filteredPayments.length} Payments
              </span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="bg-slate-50 text-slate-500 font-semibold border-b border-slate-200 uppercase tracking-wider">
                    <th className="py-3 px-4">Receipt No</th>
                    <th className="py-3 px-4">Date</th>
                    <th className="py-3 px-4">Payer Details</th>
                    <th className="py-3 px-4">Purpose</th>
                    <th className="py-3 px-4">Method & Ref</th>
                    <th className="py-3 px-4 text-right">Amount</th>
                    <th className="py-3 px-4 text-center">Verification Status</th>
                    <th className="py-3 px-4 text-center">WhatsApp</th>
                    <th className="py-3 px-4 text-right">Admin Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {loading ? (
                    <tr>
                      <td colSpan={9} className="py-12 text-center text-slate-400 text-xs">
                        Loading student collection records...
                      </td>
                    </tr>
                  ) : filteredPayments.length === 0 ? (
                    <tr>
                      <td colSpan={9} className="py-12 text-center text-slate-400 text-xs">
                        No payments found for this filter criteria.
                      </td>
                    </tr>
                  ) : (
                    filteredPayments.map((p) => {
                      const matchedReceipt = receipts.find(
                        (r) => r.receipt_number === p.receipt_number
                      );
                      const isSelfReported =
                        p.verification_status === 'Self-Reported' || !p.verification_status;
                      const isVerified = p.verification_status === 'Admin Verified';
                      const isFlagged = p.verification_status === 'Flagged';

                      return (
                        <tr key={p.id} className="hover:bg-slate-50/70 transition-colors">
                          <td className="py-3 px-4 font-mono font-bold text-purple-900 whitespace-nowrap">
                            {p.receipt_number}
                          </td>
                          <td className="py-3 px-4 text-slate-500 whitespace-nowrap">
                            {p.payment_date}
                          </td>
                          <td className="py-3 px-4">
                            <span className="font-bold text-slate-900 block">{p.payer_name}</span>
                            <span className="text-[11px] text-slate-500 font-mono">
                              {p.payer_phone}
                            </span>
                          </td>
                          <td className="py-3 px-4 font-medium text-slate-700 max-w-xs">
                            {p.payment_purpose}
                            {p.remarks && (
                              <span className="block text-[10px] text-slate-400 italic">
                                Note: {p.remarks}
                              </span>
                            )}
                          </td>
                          <td className="py-3 px-4 whitespace-nowrap">
                            <span className="font-semibold text-slate-800 block">
                              {p.payment_method}
                            </span>
                            {p.transaction_ref ? (
                              <span className="text-[10px] text-slate-400 font-mono block">
                                Ref: {p.transaction_ref}
                              </span>
                            ) : (
                              <span className="text-[10px] text-slate-400 italic">No ref</span>
                            )}
                          </td>
                          <td className="py-3 px-4 text-right font-mono font-bold text-slate-900 whitespace-nowrap">
                            {currency} {Number(p.amount).toLocaleString()}
                          </td>
                          <td className="py-3 px-4 text-center whitespace-nowrap">
                            <span
                              className={`inline-block px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                                isVerified
                                  ? 'bg-emerald-100 text-emerald-800'
                                  : isFlagged
                                  ? 'bg-rose-100 text-rose-800'
                                  : 'bg-amber-100 text-amber-800'
                              }`}
                            >
                              {p.verification_status || 'Self-Reported'}
                            </span>
                            {p.verified_by && (
                              <span className="block text-[9px] text-slate-400 mt-0.5">
                                by {p.verified_by}
                              </span>
                            )}
                          </td>
                          <td className="py-3 px-4 text-center whitespace-nowrap">
                            <span
                              className={`inline-block px-2 py-0.5 rounded-full text-[10px] font-bold ${
                                matchedReceipt?.whatsapp_status === 'Sent'
                                  ? 'bg-emerald-100 text-emerald-800'
                                  : matchedReceipt?.whatsapp_status === 'Delivered'
                                  ? 'bg-blue-100 text-blue-800'
                                  : matchedReceipt?.whatsapp_status === 'Failed'
                                  ? 'bg-rose-100 text-rose-800'
                                  : 'bg-amber-100 text-amber-800'
                              }`}
                            >
                              {matchedReceipt?.whatsapp_status || 'Generated'}
                            </span>
                          </td>
                          <td className="py-3 px-4 text-right whitespace-nowrap">
                            <div className="flex items-center justify-end gap-1.5">
                              {/* 1-Click Admin Verify button */}
                              {!isVerified && (
                                <button
                                  type="button"
                                  onClick={() => handleVerifyPayment(p.id, 'Admin Verified')}
                                  disabled={verifyingId === p.id}
                                  title="Verify and clear this student payment"
                                  className="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-[11px] font-bold flex items-center gap-1 transition-colors disabled:opacity-50"
                                >
                                  <Check className="w-3 h-3" />
                                  Verify
                                </button>
                              )}

                              {/* Flag button */}
                              {!isFlagged && (
                                <button
                                  type="button"
                                  onClick={() => handleVerifyPayment(p.id, 'Flagged')}
                                  disabled={verifyingId === p.id}
                                  title="Flag this payment for discrepancy"
                                  className="px-2 py-1 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-700 text-[11px] font-bold flex items-center gap-1 transition-colors disabled:opacity-50"
                                >
                                  <Flag className="w-3 h-3" />
                                  Flag
                                </button>
                              )}

                              {/* View Receipt */}
                              {matchedReceipt && (
                                <button
                                  type="button"
                                  onClick={() => onViewReceipt(matchedReceipt)}
                                  title="View full receipt"
                                  className="p-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors"
                                >
                                  <Eye className="w-3.5 h-3.5" />
                                </button>
                              )}

                              {/* PDF */}
                              {matchedReceipt && (
                                <button
                                  type="button"
                                  onClick={() => handleDownloadPdf(matchedReceipt.receipt_number)}
                                  title="Download receipt PDF"
                                  className="p-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors"
                                >
                                  <Download className="w-3.5 h-3.5" />
                                </button>
                              )}
                            </div>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="p-4 bg-white border-t border-slate-200 flex items-center justify-between flex-shrink-0">
          <div className="text-xs text-slate-500">
            Note: All student collections remain tagged as <span className="font-bold text-amber-700">Self-Reported</span> until an authorized Administrator audits and verifies them.
          </div>
          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs transition-colors"
          >
            Close Report
          </button>
        </div>
      </div>
    </div>
  );
};


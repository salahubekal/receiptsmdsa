import { Router, Response } from 'express';
import { db } from '../db/index.js';
import { AuthRequest, authenticateToken } from './auth.js';
import { broadcastPaymentEvent } from './realtime.js';

const router = Router();

// GET /api/payments/next-number - Generate unique next receipt number
router.get('/next-number', (req, res) => {
  try {
    const prefixRow = db.prepare("SELECT value FROM settings WHERE key = 'receipt_prefix'").get() as { value: string } | undefined;
    const prefix = prefixRow?.value || 'MDSA';
    const year = new Date().getFullYear();

    const last = db.prepare(`
      SELECT receipt_number FROM receipts 
      WHERE receipt_number LIKE ? 
      ORDER BY id DESC LIMIT 1
    `).get(`${prefix}-${year}-%`) as { receipt_number: string } | undefined;

    let nextSeq = 1001;
    if (last) {
      const parts = last.receipt_number.split('-');
      const num = parseInt(parts[parts.length - 1], 10);
      if (!isNaN(num)) nextSeq = num + 1;
    }

    res.json({ nextNumber: `${prefix}-${year}-${nextSeq}` });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/payments - Student or Admin records a payment collection
router.post('/', authenticateToken, async (req: AuthRequest, res: Response) => {
  const {
    payer_name,
    payer_phone,
    amount,
    payment_purpose,
    payment_method,
    transaction_ref = '',
    payment_date,
    remarks = '',
    custom_receipt_number,
  } = req.body;

  if (!payer_name || !payer_phone || !amount || !payment_purpose || !payment_method) {
    return res.status(400).json({
      error: 'Payer Name, WhatsApp Number, Amount, Purpose, and Payment Method are required.',
    });
  }

  const cleanAmount = parseFloat(amount);
  if (isNaN(cleanAmount) || cleanAmount <= 0) {
    return res.status(400).json({ error: 'Payment amount must be greater than zero.' });
  }

  // Identify collecting student from session
  const currentUser = req.user;
  const isStudent = currentUser?.role === 'student';
  const studentId = isStudent ? currentUser.student_id || 'STD-2026-001' : (req.body.student_id || 'MDSA-OFFICE');
  const studentName = isStudent ? currentUser.full_name || currentUser.username : (req.body.student_name || 'MDSA Administration');

  try {
    // Generate unique receipt number
    const year = new Date().getFullYear();
    const prefixRow = db.prepare("SELECT value FROM settings WHERE key = 'receipt_prefix'").get() as { value: string } | undefined;
    const prefix = prefixRow?.value || 'MDSA';

    let receiptNumber = custom_receipt_number ? custom_receipt_number.trim() : '';
    if (!receiptNumber) {
      const last = db.prepare(`SELECT receipt_number FROM receipts WHERE receipt_number LIKE ? ORDER BY id DESC LIMIT 1`).get(`${prefix}-${year}-%`) as any;
      let nextSeq = 1001;
      if (last) {
        const parts = last.receipt_number.split('-');
        const num = parseInt(parts[parts.length - 1], 10);
        if (!isNaN(num)) nextSeq = num + 1;
      }
      receiptNumber = `${prefix}-${year}-${nextSeq}`;
    }

    // Check duplicate receipt number
    const dupReceipt = db.prepare('SELECT id FROM receipts WHERE receipt_number = ?').get(receiptNumber);
    if (dupReceipt) {
      return res.status(400).json({ error: `Receipt number "${receiptNumber}" already exists.` });
    }

    // Check duplicate transaction ref if provided
    if (transaction_ref && transaction_ref.trim() !== '') {
      const dupTx = db.prepare('SELECT id FROM payments WHERE transaction_ref = ?').get(transaction_ref.trim());
      if (dupTx) {
        return res.status(400).json({
          error: `Transaction reference "${transaction_ref}" has already been recorded in previous payment ID #${dupTx.id}.`,
        });
      }
    }

    // Identify collecting student and group/location from session or body
    const currentUser = req.user;
    const isStudent = currentUser?.role === 'student';
    const studentId = isStudent ? currentUser.student_id || 'STD-2026-001' : (req.body.student_id || 'MDSA-OFFICE');
    const studentName = isStudent ? currentUser.full_name || currentUser.username : (req.body.student_name || 'MDSA Administration');

    // Retrieve student's default location and group assignment if not overridden
    const studentRow = db.prepare('SELECT * FROM students WHERE student_id = ?').get(studentId) as any;
    const locationId = req.body.location_id !== undefined ? req.body.location_id : (studentRow?.location_id || null);
    let locationName = req.body.location_name || studentRow?.location_name || '';
    if (locationId && !locationName) {
      const loc = db.prepare('SELECT name FROM locations WHERE id = ?').get(locationId) as any;
      if (loc) locationName = loc.name;
    }

    const groupId = req.body.group_id !== undefined ? req.body.group_id : (studentRow?.group_id || '');
    let groupName = req.body.group_name || studentRow?.group_name || '';
    if (groupId && !groupName) {
      const grp = db.prepare('SELECT group_name FROM groups WHERE group_id = ?').get(groupId) as any;
      if (grp) groupName = grp.group_name;
    }

    // Actual collecting member (Requirement 11)
    const collectingMemberName = (req.body.collecting_member_name || studentName).trim();
    const collectingMemberPhone = (req.body.collecting_member_phone || studentRow?.phone || '').trim();

    const payDate = payment_date || new Date().toISOString().split('T')[0];
    const initialVerificationStatus = 'Self-Reported'; // Requirement 9: Initially self-reported until admin verified

    // Insert into payments table
    const paymentInsert = db.prepare(`
      INSERT INTO payments (
        receipt_number, student_id, student_name, group_id, group_name,
        collecting_member_name, collecting_member_phone, location_id, location_name,
        payer_name, payer_phone, amount, payment_purpose, payment_method,
        transaction_ref, payment_date, verification_status, verified_by, remarks
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, '', ?)
    `).run(
      receiptNumber,
      studentId,
      studentName,
      groupId,
      groupName,
      collectingMemberName,
      collectingMemberPhone,
      locationId || null,
      locationName,
      payer_name.trim(),
      payer_phone.trim(),
      cleanAmount,
      payment_purpose.trim(),
      payment_method,
      transaction_ref ? transaction_ref.trim() : '',
      payDate,
      initialVerificationStatus,
      remarks ? remarks.trim() : ''
    );

    const paymentId = Number(paymentInsert.lastInsertRowid);

    // Link or create customer record
    let customerId: number | null = null;
    const existingCust = db.prepare('SELECT id FROM customers WHERE phone = ?').get(payer_phone.trim()) as any;
    if (existingCust) {
      customerId = existingCust.id;
    } else {
      const newCust = db.prepare(`
        INSERT INTO customers (name, phone, student_id, notes) 
        VALUES (?, ?, ?, ?)
      `).run(payer_name.trim(), payer_phone.trim(), studentId, `Payer enrolled by ${studentName}`);
      customerId = Number(newCust.lastInsertRowid);
    }

    // Insert into receipts table
    const receiptInsert = db.prepare(`
      INSERT INTO receipts (
        receipt_number, receipt_date, customer_id, customer_name, customer_phone,
        student_id, student_name, group_id, group_name, collecting_member_name, collecting_member_phone,
        location_id, location_name, description, amount, payment_method, transaction_id,
        payment_status, verification_status, paid_amount, balance_amount, remarks,
        items_json, whatsapp_status
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Paid', ?, ?, 0, ?, ?, 'Generated')
    `).run(
      receiptNumber,
      payDate,
      customerId,
      payer_name.trim(),
      payer_phone.trim(),
      studentId,
      studentName,
      groupId,
      groupName,
      collectingMemberName,
      collectingMemberPhone,
      locationId || null,
      locationName,
      payment_purpose.trim(),
      cleanAmount,
      payment_method,
      transaction_ref ? transaction_ref.trim() : '',
      initialVerificationStatus,
      cleanAmount,
      remarks ? remarks.trim() : '',
      JSON.stringify([{ description: payment_purpose.trim(), quantity: 1, rate: cleanAmount, amount: cleanAmount }])
    );

    const receiptId = Number(receiptInsert.lastInsertRowid);

    // Update receipt_id in payments
    db.prepare('UPDATE payments SET receipt_id = ? WHERE id = ?').run(receiptId, paymentId);

    // Update total_collected in students table
    db.prepare(`
      UPDATE students 
      SET total_collected = (SELECT COALESCE(SUM(amount), 0) FROM payments WHERE student_id = ?)
      WHERE student_id = ?
    `).run(studentId, studentId);

    // Update total_collected in groups table if group assigned
    if (groupId) {
      db.prepare(`
        UPDATE groups 
        SET total_collected = (SELECT COALESCE(SUM(amount), 0) FROM payments WHERE group_id = ?)
        WHERE group_id = ?
      `).run(groupId, groupId);
    }

    // Create WhatsApp message entry
    let waStatus = 'Generated';
    let waMessageId = '';

    // Check if WhatsApp Cloud API is configured for automatic dispatch
    const phoneIdRow = db.prepare("SELECT value FROM settings WHERE key = 'whatsapp_cloud_api_phone_id'").get() as any;
    const tokenRow = db.prepare("SELECT value FROM settings WHERE key = 'whatsapp_cloud_api_token'").get() as any;
    const phoneId = phoneIdRow?.value;
    const accessToken = tokenRow?.value;

    const currencySymbol = '₹';
    const personalizedMsg = `Dear ${payer_name.trim()},

Thank you for your payment to MDSA.

Please find your official digital payment receipt details below:

📄 *Receipt No:* ${receiptNumber}
📅 *Date:* ${payDate}
💰 *Amount Received:* ${currencySymbol}${cleanAmount.toLocaleString()}
💳 *Payment Method:* ${payment_method}
📝 *Purpose:* ${payment_purpose.trim()}
👨‍🎓 *Collected By:* ${studentName} (ID: ${studentId})
📊 *Status:* Paid (Self-Reported)

${remarks ? `Additional Note:\n${remarks.trim()}\n\n` : ''}Thank you!
*MDSA Digital Receipt Management Portal*
_Smart Solutions for a Digital Tomorrow_`;

    if (phoneId && accessToken) {
      try {
        const cleanToPhone = payer_phone.replace(/[^0-9]/g, '');
        const waRes = await fetch(`https://graph.facebook.com/v18.0/${phoneId}/messages`, {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${accessToken}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            messaging_product: 'whatsapp',
            recipient_type: 'individual',
            to: cleanToPhone,
            type: 'text',
            text: { body: personalizedMsg },
          }),
        });

        const waData = await waRes.json() as any;
        if (waRes.ok && waData.messages?.[0]?.id) {
          waStatus = 'Sent';
          waMessageId = waData.messages[0].id;
        } else {
          waStatus = 'Failed';
        }
      } catch (e) {
        waStatus = 'Failed';
      }
    } else {
      waStatus = 'Queued';
    }

    // Insert into whatsapp_messages
    db.prepare(`
      INSERT INTO whatsapp_messages (
        receipt_id, receipt_number, payer_phone, payer_name, message_text,
        message_id, status
      ) VALUES (?, ?, ?, ?, ?, ?, ?)
    `).run(receiptId, receiptNumber, payer_phone.trim(), payer_name.trim(), personalizedMsg, waMessageId, waStatus);

    // Update receipt's whatsapp status
    db.prepare(`
      UPDATE receipts 
      SET whatsapp_status = ?, whatsapp_message_id = ?, whatsapp_sent_at = CURRENT_TIMESTAMP 
      WHERE id = ?
    `).run(waStatus, waMessageId, receiptId);

    // Record audit log
    db.prepare(`
      INSERT INTO receipt_audit_logs (receipt_id, receipt_number, action, changed_fields, performed_by)
      VALUES (?, ?, 'CREATED', ?, ?)
    `).run(receiptId, receiptNumber, `Payment collection recorded by ${studentName} (${studentId})`, studentName);

    // Fetch full created receipt
    const createdReceipt = db.prepare('SELECT * FROM receipts WHERE id = ?').get(receiptId);
    const createdPayment = db.prepare('SELECT * FROM payments WHERE id = ?').get(paymentId);

    // BROADCAST LIVE EVENT TO ALL CONNECTED ADMIN DASHBOARDS VIA SSE
    broadcastPaymentEvent({
      type: 'NEW_PAYMENT',
      payment: createdPayment,
      receipt: createdReceipt,
      studentName,
      studentId,
      amount: cleanAmount,
      timestamp: new Date().toISOString(),
    });

    res.status(201).json({
      success: true,
      payment: createdPayment,
      receipt: createdReceipt,
      whatsappStatus: waStatus,
      whatsappMessageId: waMessageId,
      message: `Payment of ${cleanAmount} recorded successfully under ${receiptNumber}.`,
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/payments/student-collections - Admin table of all student collections
router.get('/student-collections', authenticateToken, (req: AuthRequest, res) => {
  try {
    const today = new Date().toISOString().split('T')[0];

    const studentStats = db.prepare(`
      SELECT 
        s.id,
        s.student_id,
        s.name,
        s.phone,
        s.email,
        s.class_name,
        COALESCE(SUM(p.amount), 0) as overall_collection,
        COUNT(p.id) as total_transactions,
        COALESCE(SUM(CASE WHEN p.payment_date = ? THEN p.amount ELSE 0 END), 0) as today_collection,
        COUNT(CASE WHEN p.payment_date = ? THEN p.id ELSE NULL END) as today_transactions,
        MAX(p.created_at) as last_payment_time
      FROM students s
      LEFT JOIN payments p ON s.student_id = p.student_id
      GROUP BY s.student_id
      ORDER BY today_collection DESC, overall_collection DESC
    `).all(today, today);

    res.json(studentStats);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/payments/daily-report - Daily / Weekly / Monthly collection report
router.get('/daily-report', authenticateToken, (req: AuthRequest, res) => {
  const { date, startDate, endDate, reportType = 'daily' } = req.query;

  try {
    const today = new Date().toISOString().split('T')[0];
    let start = (startDate as string) || (date as string) || today;
    let end = (endDate as string) || (date as string) || today;

    if (reportType === 'weekly') {
      const now = new Date();
      const first = now.getDate() - now.getDay();
      start = new Date(now.setDate(first)).toISOString().split('T')[0];
      end = today;
    } else if (reportType === 'monthly') {
      start = today.substring(0, 8) + '01';
      end = today;
    }

    // Student collection breakdown for the selected range
    const breakdown = db.prepare(`
      SELECT 
        p.student_id,
        p.student_name,
        COUNT(p.id) as payment_count,
        COALESCE(SUM(p.amount), 0) as total_collected,
        MIN(p.created_at) as first_payment_time,
        MAX(p.created_at) as last_payment_time,
        s.class_name
      FROM payments p
      LEFT JOIN students s ON p.student_id = s.student_id
      WHERE p.payment_date >= ? AND p.payment_date <= ?
      GROUP BY p.student_id
      ORDER BY total_collected DESC
    `).all(start, end);

    // Granular transaction list for this report
    const transactions = db.prepare(`
      SELECT * FROM payments 
      WHERE payment_date >= ? AND payment_date <= ?
      ORDER BY created_at DESC
    `).all(start, end);

    // Calculate grand total from all students
    const totalCollected = breakdown.reduce((acc, row: any) => acc + (Number(row.total_collected) || 0), 0);
    const totalPayments = breakdown.reduce((acc, row: any) => acc + (Number(row.payment_count) || 0), 0);

    res.json({
      startDate: start,
      endDate: end,
      reportType,
      summary: {
        totalCollected,
        totalPayments,
        totalStudentsActive: breakdown.length,
      },
      breakdown,
      transactions,
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/payments/student/:studentId - Individual Student Detailed Report
router.get('/student/:studentId', authenticateToken, (req: AuthRequest, res) => {
  const { studentId } = req.params;
  const { startDate, endDate } = req.query;

  try {
    const student = db.prepare('SELECT * FROM students WHERE student_id = ?').get(studentId) as any;
    if (!student) {
      return res.status(404).json({ error: 'Student record not found' });
    }

    const today = new Date().toISOString().split('T')[0];

    // Student metrics
    const stats = db.prepare(`
      SELECT 
        COALESCE(SUM(amount), 0) as overall_collection,
        COUNT(id) as total_payments,
        COALESCE(SUM(CASE WHEN payment_date = ? THEN amount ELSE 0 END), 0) as today_collection,
        COUNT(CASE WHEN payment_date = ? THEN id ELSE NULL END) as today_payments
      FROM payments
      WHERE student_id = ?
    `).get(today, today, studentId) as any;

    // Filterable payments query
    let whereSql = 'student_id = ?';
    let params: any[] = [studentId];

    if (startDate) {
      whereSql += ' AND payment_date >= ?';
      params.push(startDate);
    }
    if (endDate) {
      whereSql += ' AND payment_date <= ?';
      params.push(endDate);
    }

    const payments = db.prepare(`
      SELECT * FROM payments 
      WHERE ${whereSql}
      ORDER BY created_at DESC
    `).all(...params);

    const receipts = db.prepare(`
      SELECT * FROM receipts 
      WHERE student_id = ?
      ORDER BY created_at DESC
    `).all(studentId);

    res.json({
      student,
      stats: {
        todayCollection: stats.today_collection || 0,
        todayPayments: stats.today_payments || 0,
        overallCollection: stats.overall_collection || 0,
        totalPayments: stats.total_payments || 0,
      },
      payments,
      receipts,
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// POST & PUT /api/payments/:id/verify - Admin verifies or flags a student collection
const handleVerifyPayment = (req: AuthRequest, res: any) => {
  const { id } = req.params;
  const { status = 'Admin Verified', remarks = '' } = req.body;
  const adminName = req.user?.full_name || 'MDSA Chief Administrator';

  try {
    const payment = db.prepare('SELECT * FROM payments WHERE id = ?').get(id) as any;
    if (!payment) {
      return res.status(404).json({ error: 'Payment record not found' });
    }

    const now = new Date().toISOString();

    db.prepare(`
      UPDATE payments 
      SET verification_status = ?, verified_by = ?, verified_at = ?
      WHERE id = ?
    `).run(status, adminName, now, id);

    // Also update receipt
    db.prepare(`
      UPDATE receipts 
      SET verification_status = ?
      WHERE receipt_number = ?
    `).run(status, payment.receipt_number);

    // Audit log
    db.prepare(`
      INSERT INTO receipt_audit_logs (receipt_id, receipt_number, action, changed_fields, performed_by)
      VALUES (?, ?, 'VERIFIED', ?, ?)
    `).run(
      payment.receipt_id || null,
      payment.receipt_number,
      `Verification status updated from "${payment.verification_status}" to "${status}" by ${adminName}. ${remarks}`,
      adminName
    );

    // Broadcast live verification event to all connected devices (Chrome, Edge, mobile, tablets)
    broadcastPaymentEvent({
      type: 'PAYMENT_VERIFIED',
      paymentId: id,
      receiptNumber: payment.receipt_number,
      studentId: payment.student_id,
      studentName: payment.student_name,
      amount: payment.amount,
      verificationStatus: status,
      verifiedBy: adminName,
      timestamp: now,
    });

    res.json({
      success: true,
      paymentId: id,
      verification_status: status,
      verified_by: adminName,
      verified_at: now,
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
};

router.post('/:id/verify', authenticateToken, handleVerifyPayment);
router.put('/:id/verify', authenticateToken, handleVerifyPayment);

export default router;


import React, { useState } from 'react';
import {
  Shield,
  ShieldAlert,
  Mail,
  Copy,
  Check,
  CheckCircle2,
  ExternalLink,
  Code2,
  Cpu,
  Lock,
  Sparkles,
  Zap,
} from 'lucide-react';

interface Props {
  mode?: 'admin' | 'student';
}

export const UltraProFooter: React.FC<Props> = ({ mode = 'admin' }) => {
  const [copied, setCopied] = useState(false);
  const developerEmail = 'salahubekal@gmail.com';

  const handleCopyEmail = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    navigator.clipboard.writeText(developerEmail);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <footer className="mt-12 pt-6 pb-2 text-slate-400 select-none">
      {/* EXECUTIVE GLASSPHORIC NEBULA CONTAINER */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-[#0F172A] via-[#1E1B4B] to-[#0B0F19] text-white p-6 sm:p-8 lg:p-10 border border-purple-500/30 shadow-2xl shadow-indigo-950/50">
        
        {/* Ambient Glow Orbs */}
        <div className="absolute -top-24 -left-24 w-80 h-80 bg-purple-600/20 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-24 -right-24 w-80 h-80 bg-blue-600/20 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full h-full bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-indigo-500/5 via-transparent to-transparent pointer-events-none" />

        <div className="relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* ======================================================== */}
          {/* COLUMN 1: BRAND, OFFICIAL COPYRIGHT & BANNED WARNING    */}
          {/* ======================================================== */}
          <div className="lg:col-span-6 space-y-4 text-center lg:text-left">
            
            {/* Top Official Seals Row */}
            <div className="flex flex-wrap items-center justify-center lg:justify-start gap-2.5">
              {/* Banned Warning Badge */}
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-red-500/15 border border-red-500/40 text-red-300 text-[10px] sm:text-[11px] font-black tracking-wide uppercase shadow-sm shadow-red-950/40">
                <ShieldAlert className="w-3.5 h-3.5 text-red-400 flex-shrink-0 animate-pulse" />
                <span>LEGAL WARNING: COPYING STRICTLY BANNED</span>
              </div>

              {/* Verified Enterprise System Badge */}
              <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-[10px] sm:text-[11px] font-bold">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                <span>Verified Enterprise System</span>
              </div>
            </div>

            {/* Portal Title & Branding */}
            <div>
              <h3 className="text-base sm:text-xl font-black text-white tracking-tight flex items-center justify-center lg:justify-start gap-2">
                <span>MDSA Digital Receipt Management Portal</span>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-purple-500/25 text-purple-300 border border-purple-400/30">
                  PRO v2.5
                </span>
              </h3>
              <p className="text-xs sm:text-sm text-slate-300 font-medium mt-1">
                Paperless Digital Transaction & Squad Collection Architecture
              </p>
            </div>

            {/* Comprehensive Legal / Copyright Text */}
            <div className="p-3.5 rounded-2xl bg-white/[0.04] border border-white/10 text-[11px] text-slate-300 leading-relaxed text-left space-y-1.5">
              <div className="flex items-center gap-1.5 text-slate-200 font-bold">
                <Lock className="w-3.5 h-3.5 text-purple-400" />
                <span>© 2026 MDSA. All Rights Reserved.</span>
              </div>
              <p className="text-slate-400">
                This software portal, visual receipt layouts, Three.js 3D animation pipeline, and realtime synchronization protocols are proprietary intellectual property. Unauthorized duplication, reverse engineering, redistribution, scraping, or commercial plagiarism is <strong className="text-red-300 font-semibold uppercase">strictly banned and legally actionable</strong> under applicable digital copyright and international intellectual property laws.
              </p>
            </div>

            {/* System Trust Pillars */}
            <div className="flex flex-wrap items-center justify-center lg:justify-start gap-4 pt-1 text-[11px] text-slate-400">
              <span className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
                <span className="text-emerald-300 font-semibold">Real-Time Sync Online</span>
              </span>
              <span>•</span>
              <span className="flex items-center gap-1 text-slate-300">
                <Lock className="w-3 h-3 text-indigo-400" /> 256-Bit SSL Secured
              </span>
              <span>•</span>
              <span className="text-slate-300">100% Paperless</span>
            </div>
          </div>

          {/* ======================================================== */}
          {/* COLUMN 2: ULTRA PRO DEVELOPER SUPPORT CARD               */}
          {/* ======================================================== */}
          <div className="lg:col-span-6 flex flex-col justify-between h-full space-y-4">
            
            <div className="p-5 sm:p-6 rounded-2xl bg-gradient-to-br from-white/[0.08] to-white/[0.02] border border-white/15 backdrop-blur-xl shadow-xl relative overflow-hidden group hover:border-purple-400/40 transition-all">
              <div className="absolute top-0 right-0 w-32 h-32 bg-purple-500/10 rounded-full blur-2xl group-hover:bg-purple-500/20 transition-all pointer-events-none" />

              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                {/* Developer Avatar & Details */}
                <div className="flex items-center gap-3.5">
                  <div className="relative">
                    <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-purple-600 via-indigo-600 to-cyan-500 p-0.5 shadow-lg shadow-purple-600/30">
                      <div className="w-full h-full rounded-[14px] bg-[#0F172A] flex items-center justify-center text-white font-black text-sm">
                        <Code2 className="w-5 h-5 text-purple-300" />
                      </div>
                    </div>
                    <span className="w-3.5 h-3.5 rounded-full bg-emerald-500 ring-2 ring-[#0F172A] absolute -bottom-0.5 -right-0.5 flex items-center justify-center">
                      <span className="w-1.5 h-1.5 rounded-full bg-white animate-pulse" />
                    </span>
                  </div>

                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className="text-sm sm:text-base font-extrabold text-white">
                        Lead System Developer
                      </h4>
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-indigo-500/30 text-indigo-200 border border-indigo-400/30">
                        Author
                      </span>
                    </div>
                    <p className="text-xs text-purple-300 font-semibold mt-0.5">
                      Architecture & Full-Stack Engineering
                    </p>
                  </div>
                </div>

                {/* Priority Status Badge */}
                <div className="text-left sm:text-right">
                  <span className="inline-block px-2.5 py-1 rounded-lg bg-purple-500/20 text-purple-200 text-[10px] font-extrabold tracking-wider uppercase border border-purple-400/20">
                    24/7 Tech Support
                  </span>
                </div>
              </div>

              {/* Developer Email & Interactive Actions */}
              <div className="mt-4 pt-4 border-t border-white/10 space-y-3">
                <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2.5 bg-black/30 p-2 sm:p-2.5 rounded-xl border border-white/10">
                  <div className="flex items-center gap-2 px-2 overflow-hidden">
                    <Mail className="w-4 h-4 text-purple-400 flex-shrink-0" />
                    <span className="font-mono text-xs sm:text-sm font-bold text-white truncate selection:bg-purple-500">
                      {developerEmail}
                    </span>
                  </div>

                  <div className="flex items-center gap-1.5 justify-end">
                    {/* Copy Button */}
                    <button
                      type="button"
                      onClick={handleCopyEmail}
                      title="Copy Developer Email"
                      className="px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 active:scale-95 text-xs font-bold text-slate-200 flex items-center gap-1.5 transition-all cursor-pointer"
                    >
                      {copied ? (
                        <>
                          <Check className="w-3.5 h-3.5 text-emerald-400" />
                          <span className="text-emerald-300 text-[11px]">Copied!</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3.5 h-3.5 text-slate-300" />
                          <span className="text-[11px]">Copy</span>
                        </>
                      )}
                    </button>

                    {/* Mailto Contact Button */}
                    <a
                      href={`mailto:${developerEmail}?subject=MDSA%20Portal%20Support%20Request`}
                      className="px-3.5 py-1.5 rounded-lg bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 active:scale-95 text-white text-xs font-extrabold flex items-center gap-1.5 shadow-md shadow-indigo-600/30 transition-all cursor-pointer"
                    >
                      <span>Email Support</span>
                      <ExternalLink className="w-3 h-3 text-purple-200" />
                    </a>
                  </div>
                </div>

                {/* Subtext info */}
                <div className="flex items-center justify-between text-[11px] text-slate-400 font-medium px-1">
                  <span>Contact for modifications, bug reports or upgrades</span>
                  <span className="text-purple-300 font-semibold">Response SLA &lt; 2h</span>
                </div>
              </div>
            </div>

            {/* Architecture Telemetry Snippet */}
            <div className="flex flex-wrap items-center justify-between gap-2 px-2 text-[10px] text-slate-400 font-mono">
              <span className="flex items-center gap-1.5">
                <Cpu className="w-3 h-3 text-purple-400" /> Engine: Node.js 20 LTS • SQLite WAL
              </span>
              <span>Client: React 18 + Vite 5 + Tailwind</span>
            </div>

          </div>

        </div>

      </div>
    </footer>
  );
};


import React, { useState } from 'react';
import { motion } from 'framer-motion';
import {
  FileText,
  Zap,
  Send,
  ShieldCheck,
  ChevronRight,
  ChevronDown,
  TrendingUp,
  Minus,
  Plus,
  Users,
  MapPin,
  Calendar,
  Share2,
  DollarSign,
  CheckCircle2,
  Sparkles,
  ArrowUpRight,
  Sliders,
  ExternalLink,
} from 'lucide-react';
import { DashboardStats as StatsType, Settings, StudentStats, Receipt } from '../types';
import { NavTab } from './Sidebar';

interface Props {
  stats: StatsType | null;
  settings: Partial<Settings>;
  studentCollections: StudentStats[];
  recentReceipts: Receipt[];
  user: any;
  onNavigate: (tab: NavTab) => void;
  onNewReceipt: () => void;
  onViewReceipt: (receipt: Receipt) => void;
  onWhatsAppReceipt: (receipt: Receipt) => void;
}

export const MDSAHomeModelDashboard: React.FC<Props> = ({
  stats,
  settings,
  studentCollections,
  recentReceipts,
  user,
  onNavigate,
  onNewReceipt,
  onViewReceipt,
  onWhatsAppReceipt,
}) => {
  const currency = settings.currency_symbol || '₹';

  // Interactive Target Goal Dial state (matching temperature dial in model)
  const [targetGoal, setTargetGoal] = useState<number>(50000);
  const [selectedLocation, setSelectedLocation] = useState<string>('Main Campus North Gate');
  const [selectedTrendPeriod, setSelectedTrendPeriod] = useState<'Month' | 'Week'>('Month');

  // Toggle switch states (matching the 4 devices in model)
  const [toggleCounter, setToggleCounter] = useState<boolean>(true);
  const [toggleSquads, setToggleSquads] = useState<boolean>(true);
  const [toggleWhatsApp, setToggleWhatsApp] = useState<boolean>(true);
  const [toggleAudit, setToggleAudit] = useState<boolean>(false);
  const [toggleMeter, setToggleMeter] = useState<boolean>(true);

  // Quick Action Toggles
  const [toggleQuickReceipt, setToggleQuickReceipt] = useState<boolean>(true);
  const [toggleQuickWhatsApp, setToggleQuickWhatsApp] = useState<boolean>(true);
  const [toggleQuickSquads, setToggleQuickSquads] = useState<boolean>(true);
  const [toggleQuickReports, setToggleQuickReports] = useState<boolean>(true);

  // Calculations
  const todayAmount = stats?.todayAmountCollected || 0;
  const todayCount = stats?.todayReceiptsCount || 0;
  const totalAmount = stats?.totalAmountCollected || 0;
  const totalReceipts = stats?.totalReceipts || 0;
  const pendingAmount = stats?.pendingAmount || 0;
  const pendingCount = stats?.pendingCount || 0;

  // Target fulfilment percentage
  const goalPercent = Math.min(100, Math.round((todayAmount / (targetGoal || 1)) * 100));

  // Circular gauge SVG calculations
  const radius = 70;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (goalPercent / 100) * circumference;

  // Increment / Decrement target goal
  const handleIncreaseGoal = () => setTargetGoal((prev) => Math.min(200000, prev + 5000));
  const handleDecreaseGoal = () => setTargetGoal((prev) => Math.max(10000, prev - 5000));

  // Active student avatars for "Members" section
  const topCollectors = studentCollections.slice(0, 5);
  const defaultMembers = [
    { name: 'Rizwan', role: 'Leader', color: 'border-purple-500 bg-purple-50 text-purple-700' },
    { name: 'Amina', role: 'Squad A', color: 'border-amber-500 bg-amber-50 text-amber-700' },
    { name: 'Bilal', role: 'Squad B', color: 'border-rose-500 bg-rose-50 text-rose-700' },
    { name: 'Fatima', role: 'North Gate', color: 'border-blue-500 bg-blue-50 text-blue-700' },
    { name: 'Zubair', role: 'Collector', color: 'border-emerald-500 bg-emerald-50 text-emerald-700' },
  ];

  return (
    <div className="space-y-6">
      {/* 2-COLUMN MAIN DASHBOARD (MATCHING THE UPLOADED MODEL) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* ========================================================= */}
        {/* LEFT COLUMN: HERO WELCOME + 4 TOGGLE CARDS + CIRCULAR METER */}
        {/* ========================================================= */}
        <div className="lg:col-span-7 space-y-6">
          
          {/* 1. TOP WARM GREETING BANNER (Peach / Amber Pastel) */}
          <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-[#FFF4E4] via-[#FFEED9] to-[#FEDECA] p-5 sm:p-7 border border-[#FDE3CD] shadow-sm flex flex-col sm:flex-row items-center justify-between gap-4 sm:gap-6">
            <div className="space-y-2 z-10 max-w-sm text-center sm:text-left">
              <h2 className="text-xl sm:text-3xl font-extrabold text-[#7A3E1D] tracking-tight">
                Hello, {user?.full_name ? user.full_name.split(' ')[0] : 'Administrator'}!
              </h2>
              <p className="text-xs sm:text-sm text-[#A05C35] font-medium leading-relaxed">
                Welcome back! All collection counters, venues and student squads are active and synchronized with the database.
              </p>
              
              {/* Weather / Status Pills */}
              <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2 sm:gap-3 pt-2 text-xs font-semibold text-[#8C4B25]">
                <div className="flex items-center gap-1.5 bg-white/80 backdrop-blur-sm px-2.5 sm:px-3 py-1.5 rounded-full shadow-xs">
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                  <span>{currency}{Number(todayAmount).toLocaleString()} collected today</span>
                </div>
                <div className="flex items-center gap-1.5 bg-white/80 backdrop-blur-sm px-2.5 sm:px-3 py-1.5 rounded-full shadow-xs">
                  <span>📄 {todayCount} receipts generated</span>
                </div>
              </div>
            </div>

            {/* Illustration on Right (Matching the reference model character) */}
            <div className="relative w-28 h-28 sm:w-36 sm:h-36 flex-shrink-0 flex items-center justify-center">
              <svg viewBox="0 0 200 200" className="w-full h-full drop-shadow-md">
                {/* Sun / Warm backdrop */}
                <circle cx="100" cy="100" r="70" fill="#FDE68A" opacity="0.6" />
                <circle cx="100" cy="100" r="50" fill="#FBBF24" opacity="0.4" />
                {/* Cute Character & Receipt Graphic */}
                <path d="M 60 140 C 60 110, 80 90, 100 90 C 120 90, 140 110, 140 140 Z" fill="#4F46E5" />
                <circle cx="100" cy="70" r="20" fill="#FBCFE8" />
                <circle cx="95" cy="68" r="3" fill="#1E1B4B" />
                <circle cx="105" cy="68" r="3" fill="#1E1B4B" />
                <path d="M 96 76 Q 100 80 104 76" stroke="#1E1B4B" strokeWidth="2" fill="none" />
                {/* Floating digital receipt in hand */}
                <rect x="120" y="80" width="36" height="48" rx="6" fill="#FFFFFF" stroke="#6366F1" strokeWidth="2" />
                <line x1="126" y1="92" x2="148" y2="92" stroke="#6366F1" strokeWidth="2" strokeLinecap="round" />
                <line x1="126" y1="100" x2="142" y2="100" stroke="#94A3B8" strokeWidth="2" strokeLinecap="round" />
                <line x1="126" y1="108" x2="150" y2="108" stroke="#10B981" strokeWidth="2" strokeLinecap="round" />
                {/* Dog companion in model */}
                <path d="M 40 140 C 40 130, 50 125, 60 130 C 65 135, 65 145, 60 150 L 40 150 Z" fill="#D97706" />
                <circle cx="45" cy="125" r="8" fill="#B45309" />
              </svg>
            </div>
          </div>

          {/* 2. SECTION: COLLECTION CHANNELS ("Scarlett's Home" in model) */}
          <div className="space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <h3 className="text-lg font-extrabold text-slate-800 tracking-tight">
                Collection Channels
              </h3>
              
              {/* Right-side inline tags & Location dropdown */}
              <div className="flex items-center gap-2 text-xs font-semibold text-slate-600">
                <span className="flex items-center gap-1 bg-slate-100 px-2.5 py-1 rounded-lg">
                  💧 <span>{goalPercent}% Target</span>
                </span>
                <span className="flex items-center gap-1 bg-slate-100 px-2.5 py-1 rounded-lg">
                  🎯 <span>{currency}{targetGoal.toLocaleString()}</span>
                </span>

                <div className="relative">
                  <select
                    value={selectedLocation}
                    onChange={(e) => setSelectedLocation(e.target.value)}
                    className="appearance-none bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold py-1 pl-2.5 pr-6 rounded-lg cursor-pointer focus:outline-none transition-colors"
                  >
                    <option value="Main Campus North Gate">North Gate Venue</option>
                    <option value="Auditorium Central Desk">Auditorium Desk</option>
                    <option value="Commercial Complex Desk">Commercial Hub</option>
                    <option value="All Locations">All Hubs</option>
                  </select>
                  <ChevronDown className="w-3.5 h-3.5 text-slate-500 absolute right-1.5 top-2 pointer-events-none" />
                </div>
              </div>
            </div>

            {/* 4 ROUNDED TOGGLE CARDS (MATCHING THE MODEL) */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4">
              
              {/* CARD 1: Counter Receipts (White Card) */}
              <div className="bg-white rounded-2xl p-4 border border-slate-100 shadow-sm hover:shadow-md transition-all flex flex-col justify-between h-36">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                    {toggleCounter ? 'ON' : 'OFF'}
                  </span>
                  <button
                    type="button"
                    onClick={() => setToggleCounter(!toggleCounter)}
                    className={`w-9 h-5 rounded-full transition-colors relative p-0.5 ${
                      toggleCounter ? 'bg-purple-600' : 'bg-slate-200'
                    }`}
                  >
                    <div
                      className={`w-4 h-4 rounded-full bg-white shadow-sm transition-transform ${
                        toggleCounter ? 'translate-x-4' : 'translate-x-0'
                      }`}
                    />
                  </button>
                </div>
                <div>
                  <div className="w-8 h-8 rounded-xl bg-slate-50 flex items-center justify-center text-slate-600 mb-2">
                    <FileText className="w-4 h-4" />
                  </div>
                  <h4 className="text-xs font-bold text-slate-800 leading-tight">Counter Receipts</h4>
                  <p className="text-[10px] text-slate-400 font-medium">
                    {toggleCounter ? `${currency}${Number(totalAmount).toLocaleString()}` : 'Paused'}
                  </p>
                </div>
              </div>

              {/* CARD 2: ACTIVE PURPLE GLOW CARD (Student Squads - Highlights active state in model) */}
              <div className="bg-gradient-to-br from-[#7C3AED] to-[#6366F1] text-white rounded-2xl p-4 shadow-lg shadow-indigo-500/25 transition-all flex flex-col justify-between h-36 relative overflow-hidden">
                <div className="absolute top-0 right-0 w-24 h-24 bg-white/10 rounded-full blur-xl pointer-events-none" />
                <div className="flex items-center justify-between relative z-10">
                  <span className="text-[10px] font-extrabold uppercase tracking-wider text-purple-200">
                    {toggleSquads ? 'ON' : 'OFF'}
                  </span>
                  <button
                    type="button"
                    onClick={() => setToggleSquads(!toggleSquads)}
                    className={`w-9 h-5 rounded-full transition-colors relative p-0.5 ${
                      toggleSquads ? 'bg-white/90' : 'bg-white/30'
                    }`}
                  >
                    <div
                      className={`w-4 h-4 rounded-full shadow-sm transition-transform ${
                        toggleSquads ? 'translate-x-4 bg-purple-700' : 'translate-x-0 bg-white'
                      }`}
                    />
                  </button>
                </div>
                <div className="relative z-10">
                  <div className="w-8 h-8 rounded-xl bg-white/20 backdrop-blur-md flex items-center justify-center text-white mb-2 shadow-xs">
                    <Zap className="w-4 h-4" />
                  </div>
                  <h4 className="text-xs font-extrabold text-white leading-tight">Student Squads</h4>
                  <p className="text-[10px] text-purple-200 font-medium">
                    {toggleSquads ? `${studentCollections.length || 4} Squads Active` : 'Offline'}
                  </p>
                </div>
              </div>

              {/* CARD 3: WhatsApp Dispatch (White Card) */}
              <div className="bg-white rounded-2xl p-4 border border-slate-100 shadow-sm hover:shadow-md transition-all flex flex-col justify-between h-36">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                    {toggleWhatsApp ? 'ON' : 'OFF'}
                  </span>
                  <button
                    type="button"
                    onClick={() => setToggleWhatsApp(!toggleWhatsApp)}
                    className={`w-9 h-5 rounded-full transition-colors relative p-0.5 ${
                      toggleWhatsApp ? 'bg-emerald-500' : 'bg-slate-200'
                    }`}
                  >
                    <div
                      className={`w-4 h-4 rounded-full bg-white shadow-sm transition-transform ${
                        toggleWhatsApp ? 'translate-x-4' : 'translate-x-0'
                      }`}
                    />
                  </button>
                </div>
                <div>
                  <div className="w-8 h-8 rounded-xl bg-slate-50 flex items-center justify-center text-emerald-600 mb-2">
                    <Send className="w-4 h-4" />
                  </div>
                  <h4 className="text-xs font-bold text-slate-800 leading-tight">WhatsApp Blast</h4>
                  <p className="text-[10px] text-slate-400 font-medium">
                    {toggleWhatsApp ? '98.8% Sent' : 'Queued'}
                  </p>
                </div>
              </div>

              {/* CARD 4: Audit & Verify (White Card) */}
              <div className="bg-white rounded-2xl p-4 border border-slate-100 shadow-sm hover:shadow-md transition-all flex flex-col justify-between h-36">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                    {toggleAudit ? 'ON' : 'OFF'}
                  </span>
                  <button
                    type="button"
                    onClick={() => setToggleAudit(!toggleAudit)}
                    className={`w-9 h-5 rounded-full transition-colors relative p-0.5 ${
                      toggleAudit ? 'bg-amber-500' : 'bg-slate-200'
                    }`}
                  >
                    <div
                      className={`w-4 h-4 rounded-full bg-white shadow-sm transition-transform ${
                        toggleAudit ? 'translate-x-4' : 'translate-x-0'
                      }`}
                    />
                  </button>
                </div>
                <div>
                  <div className="w-8 h-8 rounded-xl bg-slate-50 flex items-center justify-center text-amber-500 mb-2">
                    <ShieldCheck className="w-4 h-4" />
                  </div>
                  <h4 className="text-xs font-bold text-slate-800 leading-tight">Bank Audit</h4>
                  <p className="text-[10px] text-slate-400 font-medium">
                    {pendingCount > 0 ? `${pendingCount} Pending` : 'All Cleared'}
                  </p>
                </div>
              </div>

            </div>
          </div>

          {/* 3. CARD: CIRCULAR TARGET DIAL METER ("Living Room Temperature" in model) */}
          <div className="bg-white rounded-3xl p-6 sm:p-7 border border-slate-100 shadow-sm space-y-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center">
                  <Zap className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-sm sm:text-base font-extrabold text-slate-800">
                    Daily Collection Target & Efficiency
                  </h4>
                  <p className="text-[11px] text-slate-400">
                    Interactive target goal adjuster & fulfilment speedometer
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <span className="text-[10px] font-bold text-slate-400 uppercase">
                  {toggleMeter ? 'ON' : 'OFF'}
                </span>
                <button
                  type="button"
                  onClick={() => setToggleMeter(!toggleMeter)}
                  className={`w-9 h-5 rounded-full transition-colors relative p-0.5 ${
                    toggleMeter ? 'bg-purple-600' : 'bg-slate-200'
                  }`}
                >
                  <div
                    className={`w-4 h-4 rounded-full bg-white shadow-sm transition-transform ${
                      toggleMeter ? 'translate-x-4' : 'translate-x-0'
                    }`}
                  />
                </button>
              </div>
            </div>

            {/* CIRCULAR DIAL SPEEDOMETER (MATCHING MODEL WITH MINUS AND PLUS BUTTONS) */}
            <div className="flex items-center justify-center gap-3 sm:gap-8 py-2">
              
              {/* Minus Button */}
              <button
                type="button"
                onClick={handleDecreaseGoal}
                title="Decrease Target Goal by 5,000"
                className="w-9 h-9 sm:w-11 sm:h-11 rounded-xl sm:rounded-2xl bg-slate-100 hover:bg-slate-200 text-slate-600 flex items-center justify-center transition-all hover:scale-105 active:scale-95 shadow-xs"
              >
                <Minus className="w-4 h-4" />
              </button>

              <span className="text-xs font-bold text-slate-400 hidden sm:inline">
                0%
              </span>

              {/* Concentric Circular Meter Gauge */}
              <div className="relative w-36 h-36 sm:w-48 sm:h-48 flex items-center justify-center">
                <svg className="w-full h-full transform -rotate-90" viewBox="0 0 160 160">
                  {/* Background Track */}
                  <circle
                    cx="80"
                    cy="80"
                    r={radius}
                    stroke="#F1F5F9"
                    strokeWidth="10"
                    fill="transparent"
                  />
                  {/* Gradient Progress Stroke */}
                  <circle
                    cx="80"
                    cy="80"
                    r={radius}
                    stroke="url(#purplePinkGradient)"
                    strokeWidth="10"
                    strokeDasharray={circumference}
                    strokeDashoffset={strokeDashoffset}
                    strokeLinecap="round"
                    fill="transparent"
                    className="transition-all duration-700 ease-out"
                  />
                  <defs>
                    <linearGradient id="purplePinkGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                      <stop offset="0%" stopColor="#8B5CF6" />
                      <stop offset="60%" stopColor="#EC4899" />
                      <stop offset="100%" stopColor="#F43F5E" />
                    </linearGradient>
                  </defs>
                </svg>

                {/* Inner White Glowing Circle with Center Value */}
                <div className="absolute inset-3 sm:inset-5 rounded-full bg-white shadow-[0_8px_24px_rgba(124,58,237,0.12)] border border-slate-100/80 flex flex-col items-center justify-center text-center p-2 sm:p-3">
                  <span className="text-xl sm:text-3xl font-black text-slate-800 tracking-tight">
                    {goalPercent}%
                  </span>
                  <span className="text-[9px] sm:text-[11px] font-bold text-purple-600 uppercase tracking-wider">
                    {currency}{Number(todayAmount).toLocaleString()}
                  </span>
                  <span className="text-[8px] sm:text-[9px] text-slate-400 font-medium">
                    Goal: {currency}{targetGoal.toLocaleString()}
                  </span>
                </div>
              </div>

              <span className="text-xs font-bold text-slate-400 hidden sm:inline">
                100%
              </span>

              {/* Plus Button */}
              <button
                type="button"
                onClick={handleIncreaseGoal}
                title="Increase Target Goal by 5,000"
                className="w-9 h-9 sm:w-11 sm:h-11 rounded-xl sm:rounded-2xl bg-purple-600 hover:bg-purple-700 text-white flex items-center justify-center transition-all hover:scale-105 active:scale-95 shadow-md shadow-purple-600/30"
              >
                <Plus className="w-4 h-4" />
              </button>
            </div>

            {/* Performance KPI Footnotes */}
            <div className="grid grid-cols-3 gap-3 pt-4 border-t border-slate-100 text-center">
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">
                  Today Target
                </span>
                <span className="text-xs sm:text-sm font-extrabold text-slate-800">
                  {currency}{targetGoal.toLocaleString()}
                </span>
              </div>
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">
                  Cleared Today
                </span>
                <span className="text-xs sm:text-sm font-extrabold text-emerald-600">
                  {currency}{Number(todayAmount).toLocaleString()}
                </span>
              </div>
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">
                  Remaining
                </span>
                <span className="text-xs sm:text-sm font-extrabold text-purple-700">
                  {currency}{Math.max(0, targetGoal - todayAmount).toLocaleString()}
                </span>
              </div>
            </div>
          </div>

        </div>


        {/* ========================================================= */}
        {/* RIGHT COLUMN: 4 QUICK ACTION CARDS + MEMBERS + AREA CHART */}
        {/* ========================================================= */}
        <div className="lg:col-span-5 space-y-6">

          {/* 1. TOP BLOCK: QUICK ACTION CHANNELS ("My Devices" in model) */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-extrabold text-slate-800 tracking-tight">
                Quick Actions
              </h3>
              <div className="flex items-center gap-2 text-xs font-semibold text-slate-500">
                <span className="hover:text-slate-800 cursor-pointer">ON ▾</span>
                <ChevronRight className="w-4 h-4 cursor-pointer hover:text-slate-800" />
              </div>
            </div>

            {/* 2x2 Grid of Colored Rounded Action Cards (Matching the 4 colored cards in model!) */}
            <div className="grid grid-cols-2 gap-3.5">
              
              {/* Card 1: Purple (New Receipt) */}
              <div
                onClick={onNewReceipt}
                className="bg-[#6D28D9] text-white p-4 rounded-2xl shadow-sm hover:shadow-md transition-all cursor-pointer hover:scale-[1.02] flex flex-col justify-between h-28"
              >
                <div className="flex items-center justify-between">
                  <FileText className="w-5 h-5 text-purple-200" />
                  <span className="text-[9px] font-extrabold bg-white/20 px-1.5 py-0.5 rounded-full">ON</span>
                </div>
                <div>
                  <h5 className="font-extrabold text-xs leading-tight">New Receipt</h5>
                  <p className="text-[10px] text-purple-200">Issue & Print</p>
                </div>
              </div>

              {/* Card 2: Amber / Yellow (WhatsApp Share) */}
              <div
                onClick={() => onNavigate('receipts')}
                className="bg-[#EAB308] text-white p-4 rounded-2xl shadow-sm hover:shadow-md transition-all cursor-pointer hover:scale-[1.02] flex flex-col justify-between h-28"
              >
                <div className="flex items-center justify-between">
                  <Share2 className="w-5 h-5 text-amber-100" />
                  <span className="text-[9px] font-extrabold bg-white/20 px-1.5 py-0.5 rounded-full">ON</span>
                </div>
                <div>
                  <h5 className="font-extrabold text-xs leading-tight">WhatsApp Blast</h5>
                  <p className="text-[10px] text-amber-100">Send Receipt PDF</p>
                </div>
              </div>

              {/* Card 3: Warm Orange (Student Squads) */}
              <div
                onClick={() => onNavigate('groups')}
                className="bg-[#F97316] text-white p-4 rounded-2xl shadow-sm hover:shadow-md transition-all cursor-pointer hover:scale-[1.02] flex flex-col justify-between h-28"
              >
                <div className="flex items-center justify-between">
                  <Users className="w-5 h-5 text-orange-100" />
                  <span className="text-[9px] font-extrabold bg-white/20 px-1.5 py-0.5 rounded-full">ON</span>
                </div>
                <div>
                  <h5 className="font-extrabold text-xs leading-tight">Student Squads</h5>
                  <p className="text-[10px] text-orange-100">Manage Members</p>
                </div>
              </div>

              {/* Card 4: Vibrant Cyan (Daily Reports) */}
              <div
                onClick={() => onNavigate('reports')}
                className="bg-[#06B6D4] text-white p-4 rounded-2xl shadow-sm hover:shadow-md transition-all cursor-pointer hover:scale-[1.02] flex flex-col justify-between h-28"
              >
                <div className="flex items-center justify-between">
                  <TrendingUp className="w-5 h-5 text-cyan-100" />
                  <span className="text-[9px] font-extrabold bg-white/20 px-1.5 py-0.5 rounded-full">ON</span>
                </div>
                <div>
                  <h5 className="font-extrabold text-xs leading-tight">Daily Reports</h5>
                  <p className="text-[10px] text-cyan-100">Export & Audit</p>
                </div>
              </div>

            </div>
          </div>

          {/* 2. MIDDLE BLOCK: ACTIVE COLLECTORS & SQUADS ("Members" in model) */}
          <div className="bg-white rounded-3xl p-5 border border-slate-100 shadow-sm space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-extrabold text-slate-800 tracking-tight">
                Members
              </h3>
              <button
                type="button"
                onClick={() => onNavigate('students')}
                className="text-xs font-semibold text-slate-400 hover:text-slate-800 flex items-center gap-1 transition-colors"
              >
                <span>View All</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>

            {/* Avatar Row (Matching the 5 avatars with colored rings in model) */}
            <div className="grid grid-cols-5 gap-2 pt-1 text-center">
              {defaultMembers.map((m, idx) => {
                const liveStudent = topCollectors[idx];
                const displayName = liveStudent ? liveStudent.name.split(' ')[0] : m.name;
                const roleLabel = liveStudent?.group_name ? liveStudent.group_name.split(' ')[0] : m.role;

                return (
                  <div key={idx} className="flex flex-col items-center gap-1.5 group cursor-pointer" onClick={() => onNavigate('students')}>
                    <div
                      className={`w-11 h-11 rounded-full border-2 ${m.color} flex items-center justify-center font-extrabold text-xs shadow-sm transition-transform group-hover:scale-110`}
                    >
                      {displayName.substring(0, 2).toUpperCase()}
                    </div>
                    <span className="text-[11px] font-bold text-slate-700 truncate max-w-[55px] block">
                      {displayName}
                    </span>
                    <span className="text-[9px] text-slate-400 font-medium truncate max-w-[55px] block">
                      {roleLabel}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* 3. BOTTOM BLOCK: COLLECTION TREND ("Power Consumed" in model) */}
          <div className="bg-white rounded-3xl p-5 sm:p-6 border border-slate-100 shadow-sm space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-extrabold text-slate-800 tracking-tight">
                Collection Trend
              </h3>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setSelectedTrendPeriod(selectedTrendPeriod === 'Month' ? 'Week' : 'Month')}
                  className="bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold py-1 px-2.5 rounded-lg flex items-center gap-1 transition-colors"
                >
                  <span>{selectedTrendPeriod}</span>
                  <ChevronDown className="w-3 h-3 text-slate-500" />
                </button>
                <ChevronRight className="w-4 h-4 text-slate-400 hover:text-slate-800 cursor-pointer" onClick={() => onNavigate('reports')} />
              </div>
            </div>

            {/* Legend & Stats */}
            <div className="flex items-center justify-between text-xs pt-1">
              <div className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-orange-500"></span>
                <span className="text-slate-500 font-semibold text-[11px]">Revenue Collected</span>
              </div>
              <span className="font-extrabold text-purple-700 text-[11px]">
                +28% Target Fulfillment
              </span>
            </div>

            {/* Smooth Spline Area Chart (Matching the exact soft orange curve in model!) */}
            <div className="pt-2">
              <div className="w-full h-28 relative">
                <svg viewBox="0 0 350 120" className="w-full h-full overflow-visible">
                  <defs>
                    <linearGradient id="areaGradient" x1="0%" y1="0%" x2="0%" y2="100%">
                      <stop offset="0%" stopColor="#F97316" stopOpacity="0.45" />
                      <stop offset="60%" stopColor="#FB923C" stopOpacity="0.15" />
                      <stop offset="100%" stopColor="#FED7AA" stopOpacity="0.0" />
                    </linearGradient>
                  </defs>

                  {/* Horizontal dotted guide lines */}
                  <line x1="0" y1="20" x2="350" y2="20" stroke="#F1F5F9" strokeDasharray="3 3" />
                  <line x1="0" y1="60" x2="350" y2="60" stroke="#F1F5F9" strokeDasharray="3 3" />
                  <line x1="0" y1="100" x2="350" y2="100" stroke="#F1F5F9" />

                  {/* Filled Area */}
                  <path
                    d="M 10 95 C 40 85, 70 80, 100 88 C 140 98, 170 82, 210 75 C 250 68, 280 40, 310 35 C 330 30, 340 45, 345 50 L 345 105 L 10 105 Z"
                    fill="url(#areaGradient)"
                  />

                  {/* Smooth Top Line */}
                  <path
                    d="M 10 95 C 40 85, 70 80, 100 88 C 140 98, 170 82, 210 75 C 250 68, 280 40, 310 35 C 330 30, 340 45, 345 50"
                    fill="none"
                    stroke="#F97316"
                    strokeWidth="2.5"
                    strokeLinecap="round"
                  />

                  {/* Peak Marker Dot */}
                  <circle cx="310" cy="35" r="4.5" fill="#EA580C" stroke="#FFFFFF" strokeWidth="2" />
                </svg>
              </div>

              {/* Month / Week Labels underneath */}
              <div className="flex items-center justify-between text-[10px] font-semibold text-slate-400 pt-1">
                <span>Jan</span>
                <span>Feb</span>
                <span>Mar</span>
                <span>Apr</span>
                <span>May</span>
                <span>Jun</span>
                <span>Jul</span>
              </div>
            </div>
          </div>

        </div>

      </div>
    </div>
  );
};

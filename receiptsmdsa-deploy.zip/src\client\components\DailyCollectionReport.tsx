import React, { useState, useEffect } from 'react';
import {
  Calendar,
  FileText,
  Download,
  Printer,
  TrendingUp,
  Users,
  Search,
  Filter,
  ArrowRight,
  CheckCircle,
  FileSpreadsheet,
  MapPin,
  Crown,
  GraduationCap,
} from 'lucide-react';
import { Settings } from '../types';

interface Props {
  settings: Partial<Settings>;
  onSelectStudent?: (studentId: string) => void;
}

export const DailyCollectionReport: React.FC<Props> = ({ settings, onSelectStudent }) => {
  const currency = settings.currency_symbol || '₹';

  const today = new Date().toISOString().split('T')[0];
  const [reportType, setReportType] = useState<'daily' | 'weekly' | 'monthly' | 'custom'>('daily');
  const [selectedDate, setSelectedDate] = useState<string>(today);
  const [startDate, setStartDate] = useState<string>(today);
  const [endDate, setEndDate] = useState<string>(today);

  // Dimension Sub-tabs (Requirement 12: Individual, Group-Wise, and Location-Wise collections)
  const [activeDimension, setActiveDimension] = useState<'individual' | 'group' | 'location'>('individual');

  const [reportData, setReportData] = useState<any>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [search, setSearch] = useState<string>('');

  const fetchReport = async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams({
        period: reportType,
        date: selectedDate,
        startDate: reportType === 'custom' ? startDate : '',
        endDate: reportType === 'custom' ? endDate : '',
      });

      const res = await fetch(`/api/admin/breakdowns?${params.toString()}`, {
        headers: {
          Authorization: `Bearer ${localStorage.getItem('receipt_auth_token')}`,
        },
      });

      const data = await res.json();
      if (res.ok) {
        setReportData(data);
      }
    } catch (err) {
      console.error('Failed to load multi-dimensional collection report:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchReport();
  }, [reportType, selectedDate, startDate, endDate]);

  // Export as CSV (Excel compatible)
  const exportToExcel = () => {
    if (!reportData) return;

    let csv = `MDSA Digital Receipt Portal - Collection Report\n`;
    csv += `Dimension: ${activeDimension.toUpperCase()} BREAKDOWN\n`;
    csv += `Period: ${reportData.startDate} to ${reportData.endDate} (${reportData.period})\n`;
    csv += `Exported: ${new Date().toLocaleString()}\n\n`;

    if (activeDimension === 'individual') {
      csv += `Student ID,Student Name,Batch,Assigned Location,Assigned Group,Payments Count,Total Collected (${currency})\n`;
      (reportData.individuals || []).forEach((r: any) => {
        csv += `"${r.student_id}","${r.student_name}","${r.class_name || ''}","${r.location_name || 'N/A'}","${r.group_name || 'N/A'}",${r.payment_count},${r.total_collected}\n`;
      });
    } else if (activeDimension === 'group') {
      csv += `Group ID,Group Name,Designated Leader,Leader Phone,Location,Members Count,Payments Count,Total Collected (${currency})\n`;
      (reportData.groups || []).forEach((r: any) => {
        csv += `"${r.group_id}","${r.group_name}","${r.leader_name}","${r.leader_phone}","${r.location_name || 'N/A'}",${r.members_count},${r.payment_count},${r.total_collected}\n`;
      });
    } else {
      csv += `Location Code,Location Name,Area / Zone,Assigned Students,Assigned Groups,Payments Count,Total Collected (${currency})\n`;
      (reportData.locations || []).forEach((r: any) => {
        csv += `"${r.location_code}","${r.location_name}","${r.city_or_area || 'General'}",${r.assigned_students},${r.assigned_groups},${r.payment_count},${r.total_collected}\n`;
      });
    }

    csv += `\nGRAND TOTAL SUMMARY,,,Total Collected: ${currency}${reportData.summary?.totalCollected},Total Receipts: ${reportData.summary?.totalPayments}\n`;

    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `MDSA-${activeDimension}-Report-${reportData.startDate}-to-${reportData.endDate}.csv`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const handlePrint = () => {
    window.print();
  };

  // Filtered rows for current active dimension
  const currentItems =
    activeDimension === 'individual'
      ? (reportData?.individuals || []).filter((r: any) =>
          r.student_name.toLowerCase().includes(search.toLowerCase()) ||
          r.student_id.toLowerCase().includes(search.toLowerCase()) ||
          (r.location_name && r.location_name.toLowerCase().includes(search.toLowerCase())) ||
          (r.group_name && r.group_name.toLowerCase().includes(search.toLowerCase()))
        )
      : activeDimension === 'group'
      ? (reportData?.groups || []).filter((r: any) =>
          r.group_name.toLowerCase().includes(search.toLowerCase()) ||
          r.group_id.toLowerCase().includes(search.toLowerCase()) ||
          r.leader_name.toLowerCase().includes(search.toLowerCase())
        )
      : (reportData?.locations || []).filter((r: any) =>
          r.location_name.toLowerCase().includes(search.toLowerCase()) ||
          r.location_code.toLowerCase().includes(search.toLowerCase()) ||
          (r.city_or_area && r.city_or_area.toLowerCase().includes(search.toLowerCase()))
        );

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-extrabold text-slate-900 flex items-center gap-2">
              <TrendingUp className="w-6 h-6 text-purple-600" />
              Daily, Weekly & Monthly Collection Reports
            </h2>
            <span className="bg-purple-100 text-purple-800 text-xs font-bold px-2.5 py-0.5 rounded-full">
              Multi-Dimensional
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Review live collections by individual student collector, squad group, and collection venue.
          </p>
        </div>

        {/* Export Buttons */}
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={exportToExcel}
            className="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center gap-1.5 shadow transition-colors"
          >
            <FileSpreadsheet className="w-4 h-4" />
            <span>Excel / CSV</span>
          </button>
          <button
            type="button"
            onClick={handlePrint}
            className="px-3.5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs flex items-center gap-1.5 transition-colors"
          >
            <Printer className="w-4 h-4" />
            <span>Print Report</span>
          </button>
        </div>
      </div>

      {/* Date Range Selector Toolbar (Requirement 13) */}
      <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-sm space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          {/* Quick Period Buttons */}
          <div className="flex flex-wrap items-center gap-1.5 bg-slate-100 p-1 rounded-2xl">
            <button
              type="button"
              onClick={() => setReportType('daily')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                reportType === 'daily'
                  ? 'bg-purple-600 text-white shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Daily Report
            </button>
            <button
              type="button"
              onClick={() => setReportType('weekly')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                reportType === 'weekly'
                  ? 'bg-purple-600 text-white shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Weekly Summary
            </button>
            <button
              type="button"
              onClick={() => setReportType('monthly')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                reportType === 'monthly'
                  ? 'bg-purple-600 text-white shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Monthly Report
            </button>
            <button
              type="button"
              onClick={() => setReportType('custom')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                reportType === 'custom'
                  ? 'bg-purple-600 text-white shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Custom Date Range
            </button>
          </div>

          {/* Date Pickers */}
          <div className="flex items-center gap-2">
            {reportType === 'daily' && (
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-slate-500 uppercase">Select Date:</span>
                <input
                  type="date"
                  value={selectedDate}
                  onChange={(e) => setSelectedDate(e.target.value)}
                  className="px-3 py-1.5 rounded-xl border border-slate-300 text-xs font-medium focus:outline-none focus:ring-1 focus:ring-purple-600"
                />
              </div>
            )}

            {reportType === 'custom' && (
              <div className="flex items-center gap-2">
                <input
                  type="date"
                  value={startDate}
                  onChange={(e) => setStartDate(e.target.value)}
                  className="px-2.5 py-1.5 rounded-xl border border-slate-300 text-xs font-medium focus:outline-none focus:ring-1 focus:ring-purple-600"
                />
                <span className="text-xs text-slate-400">to</span>
                <input
                  type="date"
                  value={endDate}
                  onChange={(e) => setEndDate(e.target.value)}
                  className="px-2.5 py-1.5 rounded-xl border border-slate-300 text-xs font-medium focus:outline-none focus:ring-1 focus:ring-purple-600"
                />
              </div>
            )}
          </div>
        </div>

        {/* Active Dimension Switcher (Requirement 12: Individual, Group-Wise, Location-Wise) */}
        <div className="flex border-b border-slate-200 gap-6 pt-2">
          <button
            type="button"
            onClick={() => setActiveDimension('individual')}
            className={`pb-2.5 text-xs font-bold flex items-center gap-2 border-b-2 transition-all ${
              activeDimension === 'individual'
                ? 'border-purple-600 text-purple-700'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <GraduationCap className="w-4 h-4" />
            <span>Individual Collectors ({reportData?.individuals?.length || 0})</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveDimension('group')}
            className={`pb-2.5 text-xs font-bold flex items-center gap-2 border-b-2 transition-all ${
              activeDimension === 'group'
                ? 'border-indigo-600 text-indigo-700'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Users className="w-4 h-4" />
            <span>Group-Wise Squads ({reportData?.groups?.length || 0})</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveDimension('location')}
            className={`pb-2.5 text-xs font-bold flex items-center gap-2 border-b-2 transition-all ${
              activeDimension === 'location'
                ? 'border-emerald-600 text-emerald-700'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <MapPin className="w-4 h-4" />
            <span>Location-Wise Hubs ({reportData?.locations?.length || 0})</span>
          </button>
        </div>
      </div>

      {/* 3 Summary Aggregate Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm">
          <span className="text-[11px] font-bold uppercase tracking-wider text-purple-600 block mb-1">
            Period Total Collection
          </span>
          <div className="text-2xl sm:text-3xl font-black font-mono text-purple-950">
            {currency} {Number(reportData?.summary?.totalCollected || 0).toLocaleString()}
          </div>
          <span className="text-[11px] text-slate-500 mt-1 block">
            {reportData?.startDate} to {reportData?.endDate}
          </span>
        </div>

        <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm">
          <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-600 block mb-1">
            Total Receipts Issued
          </span>
          <div className="text-2xl sm:text-3xl font-black font-mono text-emerald-700">
            {reportData?.summary?.totalPayments || 0}
          </div>
          <span className="text-[11px] text-emerald-600 font-semibold mt-1 flex items-center gap-1">
            <CheckCircle className="w-3.5 h-3.5" /> Cleared transactions
          </span>
        </div>

        <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm">
          <span className="text-[11px] font-bold uppercase tracking-wider text-indigo-600 block mb-1">
            Active Participating Units
          </span>
          <div className="text-2xl sm:text-3xl font-black font-mono text-indigo-700">
            {activeDimension === 'individual'
              ? `${reportData?.summary?.activeStudents || 0} Students`
              : activeDimension === 'group'
              ? `${reportData?.summary?.activeGroups || 0} Squads`
              : `${reportData?.summary?.activeLocations || 0} Venues`}
          </div>
          <span className="text-[11px] text-slate-500 mt-1 block">Units recording payments</span>
        </div>
      </div>

      {/* Main Table for the Active Dimension */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-4 sm:p-5 border-b border-slate-200 bg-slate-50/50 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
          <div className="relative flex-1 max-w-md">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder={`Search in ${activeDimension} collection breakdown...`}
              className="w-full pl-9 pr-3 py-1.5 rounded-xl border border-slate-300 text-xs font-medium focus:outline-none focus:ring-1 focus:ring-purple-600"
            />
          </div>

          <span className="text-xs text-slate-500 font-semibold">
            {currentItems.length} records in this view
          </span>
        </div>

        <div className="overflow-x-auto">
          {/* TAB 1: INDIVIDUAL STUDENTS TABLE */}
          {activeDimension === 'individual' && (
            <table className="w-full text-left text-xs sm:text-sm">
              <thead>
                <tr className="bg-slate-50 text-slate-500 font-semibold border-b border-slate-200 text-xs uppercase tracking-wider">
                  <th className="py-3.5 px-5">Student Collector</th>
                  <th className="py-3.5 px-5">Student ID</th>
                  <th className="py-3.5 px-5">Assigned Location</th>
                  <th className="py-3.5 px-5">Assigned Group</th>
                  <th className="py-3.5 px-5 text-center">Receipts Count</th>
                  <th className="py-3.5 px-5 text-right">Total Amount</th>
                  <th className="py-3.5 px-5 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {loading ? (
                  <tr>
                    <td colSpan={7} className="py-12 text-center text-slate-400 text-xs">
                      Loading individual student collection report...
                    </td>
                  </tr>
                ) : currentItems.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="py-12 text-center text-slate-400 text-xs">
                      No collections recorded for this period.
                    </td>
                  </tr>
                ) : (
                  currentItems.map((r: any) => (
                    <tr key={r.student_id} className="hover:bg-slate-50/70 transition-colors">
                      <td className="py-4 px-5">
                        <span className="font-bold text-slate-900 block">{r.student_name}</span>
                        <span className="text-[11px] text-slate-400">{r.class_name}</span>
                      </td>
                      <td className="py-4 px-5 font-mono font-bold text-purple-900">
                        {r.student_id}
                      </td>
                      <td className="py-4 px-5">
                        {r.location_name ? (
                          <span className="inline-flex items-center gap-1 bg-emerald-50 text-emerald-800 text-[10px] font-semibold px-2 py-0.5 rounded-full border border-emerald-200">
                            <MapPin className="w-2.5 h-2.5 text-emerald-600" />
                            {r.location_name}
                          </span>
                        ) : (
                          <span className="text-slate-400 text-[11px] italic">Unassigned</span>
                        )}
                      </td>
                      <td className="py-4 px-5">
                        {r.group_name ? (
                          <span className="inline-flex items-center gap-1 bg-indigo-50 text-indigo-800 text-[10px] font-semibold px-2 py-0.5 rounded-full border border-indigo-200">
                            <Users className="w-2.5 h-2.5 text-indigo-600" />
                            {r.group_name}
                          </span>
                        ) : (
                          <span className="text-slate-400 text-[11px] italic">Individual</span>
                        )}
                      </td>
                      <td className="py-4 px-5 text-center font-mono font-bold text-slate-700">
                        {r.payment_count || 0}
                      </td>
                      <td className="py-4 px-5 text-right font-mono font-black text-purple-950">
                        {currency} {Number(r.total_collected || 0).toLocaleString()}
                      </td>
                      <td className="py-4 px-5 text-right">
                        {onSelectStudent && (
                          <button
                            type="button"
                            onClick={() => onSelectStudent(r.student_id)}
                            className="px-2.5 py-1 rounded-xl bg-purple-50 hover:bg-purple-100 text-purple-800 text-xs font-bold inline-flex items-center gap-1"
                          >
                            <span>Profile</span>
                            <ArrowRight className="w-3 h-3" />
                          </button>
                        )}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          )}

          {/* TAB 2: GROUP-WISE TABLE */}
          {activeDimension === 'group' && (
            <table className="w-full text-left text-xs sm:text-sm">
              <thead>
                <tr className="bg-slate-50 text-slate-500 font-semibold border-b border-slate-200 text-xs uppercase tracking-wider">
                  <th className="py-3.5 px-5">Group Name</th>
                  <th className="py-3.5 px-5">Group ID</th>
                  <th className="py-3.5 px-5">Designated Leader</th>
                  <th className="py-3.5 px-5">Assigned Location</th>
                  <th className="py-3.5 px-5 text-center">Members</th>
                  <th className="py-3.5 px-5 text-center">Receipts Count</th>
                  <th className="py-3.5 px-5 text-right">Total Amount</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {loading ? (
                  <tr>
                    <td colSpan={7} className="py-12 text-center text-slate-400 text-xs">
                      Loading squad collection breakdown...
                    </td>
                  </tr>
                ) : currentItems.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="py-12 text-center text-slate-400 text-xs">
                      No group collections recorded in this period.
                    </td>
                  </tr>
                ) : (
                  currentItems.map((g: any) => (
                    <tr key={g.group_id} className="hover:bg-slate-50/70 transition-colors">
                      <td className="py-4 px-5 font-bold text-slate-900">
                        {g.group_name}
                      </td>
                      <td className="py-4 px-5 font-mono font-bold text-indigo-900">
                        {g.group_id}
                      </td>
                      <td className="py-4 px-5">
                        <span className="font-bold text-slate-800 flex items-center gap-1">
                          <Crown className="w-3.5 h-3.5 text-amber-500" />
                          {g.leader_name}
                        </span>
                        <span className="text-[10px] text-slate-400 font-mono">📱 {g.leader_phone}</span>
                      </td>
                      <td className="py-4 px-5">
                        <span className="text-slate-700 font-medium">
                          {g.location_name || 'General Area'}
                        </span>
                      </td>
                      <td className="py-4 px-5 text-center font-mono font-bold text-slate-700">
                        {g.members_count || 0}
                      </td>
                      <td className="py-4 px-5 text-center font-mono font-bold text-slate-700">
                        {g.payment_count || 0}
                      </td>
                      <td className="py-4 px-5 text-right font-mono font-black text-indigo-950">
                        {currency} {Number(g.total_collected || 0).toLocaleString()}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          )}

          {/* TAB 3: LOCATION-WISE TABLE */}
          {activeDimension === 'location' && (
            <table className="w-full text-left text-xs sm:text-sm">
              <thead>
                <tr className="bg-slate-50 text-slate-500 font-semibold border-b border-slate-200 text-xs uppercase tracking-wider">
                  <th className="py-3.5 px-5">Location Name</th>
                  <th className="py-3.5 px-5">Code</th>
                  <th className="py-3.5 px-5">Area / Zone</th>
                  <th className="py-3.5 px-5 text-center">Assigned Collectors</th>
                  <th className="py-3.5 px-5 text-center">Assigned Squads</th>
                  <th className="py-3.5 px-5 text-center">Receipts Count</th>
                  <th className="py-3.5 px-5 text-right">Total Amount</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {loading ? (
                  <tr>
                    <td colSpan={7} className="py-12 text-center text-slate-400 text-xs">
                      Loading venue collection breakdown...
                    </td>
                  </tr>
                ) : currentItems.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="py-12 text-center text-slate-400 text-xs">
                      No venue collections recorded in this period.
                    </td>
                  </tr>
                ) : (
                  currentItems.map((loc: any) => (
                    <tr key={loc.location_code} className="hover:bg-slate-50/70 transition-colors">
                      <td className="py-4 px-5 font-bold text-slate-900 flex items-center gap-2">
                        <MapPin className="w-4 h-4 text-emerald-600" />
                        <span>{loc.location_name}</span>
                      </td>
                      <td className="py-4 px-5 font-mono font-bold text-emerald-900">
                        {loc.location_code}
                      </td>
                      <td className="py-4 px-5 font-medium text-slate-700">
                        {loc.city_or_area || 'General Zone'}
                      </td>
                      <td className="py-4 px-5 text-center font-mono font-bold text-purple-700">
                        {loc.assigned_students || 0}
                      </td>
                      <td className="py-4 px-5 text-center font-mono font-bold text-indigo-700">
                        {loc.assigned_groups || 0}
                      </td>
                      <td className="py-4 px-5 text-center font-mono font-bold text-slate-700">
                        {loc.payment_count || 0}
                      </td>
                      <td className="py-4 px-5 text-right font-mono font-black text-emerald-950">
                        {currency} {Number(loc.total_collected || 0).toLocaleString()}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          )}

          {/* Grand Total Footer */}
          <tfoot className="bg-slate-50/90 font-extrabold border-t-2 border-slate-200 text-xs sm:text-sm">
            <tr>
              <td className="py-4 px-5 uppercase tracking-wider text-slate-800">
                Grand Total ({activeDimension.toUpperCase()} VIEW)
              </td>
              <td className="py-4 px-5" colSpan={activeDimension === 'individual' ? 3 : activeDimension === 'group' ? 3 : 4}></td>
              <td className="py-4 px-5 text-center font-mono font-black text-slate-900">
                {reportData?.summary?.totalPayments || 0} Receipts
              </td>
              <td className="py-4 px-5 text-right font-mono font-black text-purple-950 text-base">
                {currency} {Number(reportData?.summary?.totalCollected || 0).toLocaleString()}
              </td>
              {activeDimension === 'individual' && <td className="py-4 px-5"></td>}
            </tr>
          </tfoot>
        </div>
      </div>
    </div>
  );
};

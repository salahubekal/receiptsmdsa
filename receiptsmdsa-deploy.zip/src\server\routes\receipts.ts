import { Router } from 'express';
import { db } from '../db/index.js';
import { broadcastEvent } from './realtime.js';

const router = Router();

// GET /api/receipts/next-number - Generate unique next receipt number
router.get('/next-number', (req, res) => {
  try {
    const prefixRow = db.prepare("SELECT value FROM settings WHERE key = 'receipt_prefix'").get() as { value: string } | undefined;
    const prefix = prefixRow?.value || 'REC';
    const year = new Date().getFullYear();

    // Find the highest number for this prefix and year
    const lastReceipt = db.prepare(`
      SELECT receipt_number FROM receipts 
      WHERE receipt_number LIKE ? 
      ORDER BY id DESC LIMIT 1
    `).get(`${prefix}-${year}-%`) as { receipt_number: string } | undefined;

    let nextSeq = 1001;
    if (lastReceipt) {
      const parts = lastReceipt.receipt_number.split('-');
      const numPart = parseInt(parts[parts.length - 1], 10);
      if (!isNaN(numPart)) {
        nextSeq = numPart + 1;
      }
    }

    const nextNumber = `${prefix}-${year}-${nextSeq}`;
    res.json({ nextNumber });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/receipts/stats - Dashboard analytics
router.get('/stats', (req, res) => {
  try {
    const today = new Date().toISOString().split('T')[0];
    const currentMonth = today.substring(0, 7); // 'YYYY-MM'

    // Total Receipts and Total Collected
    const totals = db.prepare(`
      SELECT 
        COUNT(*) as total_receipts,
        COALESCE(SUM(paid_amount), 0) as total_amount_collected,
        COALESCE(SUM(balance_amount), 0) as total_pending_amount
      FROM receipts
    `).get() as any;

    // Today's Receipts
    const todayStats = db.prepare(`
      SELECT 
        COUNT(*) as count,
        COALESCE(SUM(paid_amount), 0) as amount
      FROM receipts
      WHERE receipt_date = ?
    `).get(today) as any;

    // Monthly Collection
    const monthStats = db.prepare(`
      SELECT 
        COUNT(*) as count,
        COALESCE(SUM(paid_amount), 0) as amount
      FROM receipts
      WHERE receipt_date LIKE ?
    `).get(`${currentMonth}%`) as any;

    // Pending Payments count
    const pendingStats = db.prepare(`
      SELECT 
        COUNT(*) as count,
        COALESCE(SUM(balance_amount), 0) as amount
      FROM receipts
      WHERE payment_status IN ('Pending', 'Partially Paid')
    `).get() as any;

    // Payment method breakdown
    const paymentMethods = db.prepare(`
      SELECT 
        payment_method,
        COUNT(*) as count,
        COALESCE(SUM(paid_amount), 0) as total
      FROM receipts
      GROUP BY payment_method
    `).all();

    // 7-day collection trend
    const recentDaysTrend = db.prepare(`
      SELECT 
        receipt_date,
        COUNT(*) as count,
        COALESCE(SUM(paid_amount), 0) as total
      FROM receipts
      WHERE receipt_date >= date('now', '-7 days')
      GROUP BY receipt_date
      ORDER BY receipt_date ASC
    `).all();

    res.json({
      totalReceipts: totals.total_receipts || 0,
      totalAmountCollected: totals.total_amount_collected || 0,
      totalPendingAmount: totals.total_pending_amount || 0,
      todayReceiptsCount: todayStats.count || 0,
      todayAmountCollected: todayStats.amount || 0,
      monthlyReceiptsCount: monthStats.count || 0,
      monthlyAmountCollected: monthStats.amount || 0,
      pendingCount: pendingStats.count || 0,
      pendingAmount: pendingStats.amount || 0,
      paymentMethods,
      recentDaysTrend,
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/receipts - Filterable list with pagination
router.get('/', (req, res) => {
  const {
    search,
    status,
    method,
    startDate,
    endDate,
    customerId,
    limit = 50,
    offset = 0,
  } = req.query;

  try {
    let whereClauses: string[] = ['1=1'];
    let params: any[] = [];

    if (search) {
      whereClauses.push(`(
        receipt_number LIKE ? OR 
        customer_name LIKE ? OR 
        customer_phone LIKE ? OR 
        description LIKE ? OR 
        transaction_id LIKE ?
      )`);
      const term = `%${search}%`;
      params.push(term, term, term, term, term);
    }

    if (status && status !== 'All') {
      whereClauses.push('payment_status = ?');
      params.push(status);
    }

    if (method && method !== 'All') {
      whereClauses.push('payment_method = ?');
      params.push(method);
    }

    if (startDate) {
      whereClauses.push('receipt_date >= ?');
      params.push(startDate);
    }

    if (endDate) {
      whereClauses.push('receipt_date <= ?');
      params.push(endDate);
    }

    if (customerId) {
      whereClauses.push('customer_id = ?');
      params.push(customerId);
    }

    const whereSql = whereClauses.join(' AND ');

    const countRow = db.prepare(`SELECT COUNT(*) as total FROM receipts WHERE ${whereSql}`).get(...params) as any;
    const total = countRow ? countRow.total : 0;

    const receipts = db.prepare(`
      SELECT * FROM receipts 
      WHERE ${whereSql}
      ORDER BY receipt_date DESC, id DESC
      LIMIT ? OFFSET ?
    `).all(...params, Number(limit), Number(offset));

    res.json({ receipts, total });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/receipts/:id - Single receipt with audit history
router.get('/:id', (req, res) => {
  const { id } = req.params;

  try {
    const receipt = db.prepare('SELECT * FROM receipts WHERE id = ? OR receipt_number = ?').get(id, id) as any;
    if (!receipt) {
      return res.status(404).json({ error: 'Receipt not found' });
    }

    const auditLogs = db.prepare(`
      SELECT * FROM receipt_audit_logs 
      WHERE receipt_id = ? 
      ORDER BY id DESC
    `).all(receipt.id);

    res.json({ receipt, auditLogs });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/receipts - Create new digital receipt
router.post('/', (req, res) => {
  const {
    receipt_number,
    receipt_date,
    customer_id,
    customer_name,
    customer_phone,
    customer_address = '',
    description,
    amount,
    payment_method,
    transaction_id = '',
    payment_status = 'Paid',
    paid_amount,
    balance_amount,
    remarks = '',
    items = [],
  } = req.body;

  if (!customer_name || !customer_phone || !amount || !payment_method) {
    return res.status(400).json({ error: 'Customer Name, WhatsApp Phone, Amount, and Payment Method are required.' });
  }

  const cleanAmount = parseFloat(amount) || 0;
  let finalPaidAmount = paid_amount !== undefined ? parseFloat(paid_amount) : cleanAmount;
  let finalBalanceAmount = balance_amount !== undefined ? parseFloat(balance_amount) : 0;

  if (payment_status === 'Paid') {
    finalPaidAmount = cleanAmount;
    finalBalanceAmount = 0;
  } else if (payment_status === 'Pending') {
    finalPaidAmount = 0;
    finalBalanceAmount = cleanAmount;
  }

  try {
    // Generate or ensure receipt number
    let finalReceiptNumber = receipt_number ? receipt_number.trim() : '';
    if (!finalReceiptNumber) {
      const year = new Date().getFullYear();
      const prefixRow = db.prepare("SELECT value FROM settings WHERE key = 'receipt_prefix'").get() as { value: string } | undefined;
      const prefix = prefixRow?.value || 'REC';
      const last = db.prepare(`SELECT receipt_number FROM receipts WHERE receipt_number LIKE ? ORDER BY id DESC LIMIT 1`).get(`${prefix}-${year}-%`) as any;
      let nextSeq = 1001;
      if (last) {
        const parts = last.receipt_number.split('-');
        const num = parseInt(parts[parts.length - 1], 10);
        if (!isNaN(num)) nextSeq = num + 1;
      }
      finalReceiptNumber = `${prefix}-${year}-${nextSeq}`;
    } else {
      // Check duplicate
      const duplicate = db.prepare('SELECT id FROM receipts WHERE receipt_number = ?').get(finalReceiptNumber);
      if (duplicate) {
        return res.status(400).json({ error: `Receipt number "${finalReceiptNumber}" already exists. Please choose a unique number.` });
      }
    }

    // Auto find or create customer
    let linkedCustomerId = customer_id ? parseInt(customer_id, 10) : null;
    const cleanPhone = customer_phone.trim();
    const cleanCustName = customer_name.trim();

    if (!linkedCustomerId) {
      const existingCust = db.prepare('SELECT id FROM customers WHERE phone = ?').get(cleanPhone) as any;
      if (existingCust) {
        linkedCustomerId = existingCust.id;
        // Optionally update address if was empty
        if (customer_address) {
          db.prepare('UPDATE customers SET address = ? WHERE id = ? AND (address = "" OR address IS NULL)').run(customer_address.trim(), linkedCustomerId);
        }
      } else {
        const newCustRes = db.prepare(`
          INSERT INTO customers (name, phone, address, notes, updated_at) 
          VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP)
        `).run(cleanCustName, cleanPhone, customer_address.trim(), 'Auto-created from receipt ' + finalReceiptNumber);
        linkedCustomerId = Number(newCustRes.lastInsertRowid);
      }
    }

    const itemsJson = JSON.stringify(Array.isArray(items) && items.length > 0 ? items : [
      { description: description.trim(), quantity: 1, rate: cleanAmount, amount: cleanAmount }
    ]);

    const result = db.prepare(`
      INSERT INTO receipts (
        receipt_number, receipt_date, customer_id, customer_name, customer_phone,
        customer_address, description, amount, payment_method, transaction_id,
        payment_status, paid_amount, balance_amount, remarks, items_json, whatsapp_status, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Not Sent', CURRENT_TIMESTAMP)
    `).run(
      finalReceiptNumber,
      receipt_date || new Date().toISOString().split('T')[0],
      linkedCustomerId,
      cleanCustName,
      cleanPhone,
      customer_address ? customer_address.trim() : '',
      description ? description.trim() : 'Payment Received',
      cleanAmount,
      payment_method,
      transaction_id ? transaction_id.trim() : '',
      payment_status,
      finalPaidAmount,
      finalBalanceAmount,
      remarks ? remarks.trim() : '',
      itemsJson
    );

    const newReceiptId = Number(result.lastInsertRowid);
    const newReceipt = db.prepare('SELECT * FROM receipts WHERE id = ?').get(newReceiptId) as any;

    // Record audit trail
    db.prepare(`
      INSERT INTO receipt_audit_logs (receipt_id, receipt_number, action, changed_fields, new_data, performed_by)
      VALUES (?, ?, 'CREATED', 'Initial creation', ?, 'Admin')
    `).run(newReceiptId, finalReceiptNumber, JSON.stringify(newReceipt));

    // Live broadcast to all connected devices & browsers
    broadcastEvent({
      type: 'NEW_RECEIPT',
      receipt: newReceipt,
      receiptNumber: finalReceiptNumber,
      amount: newReceipt.amount,
      customerName: newReceipt.customer_name,
      timestamp: new Date().toISOString(),
    });

    res.status(201).json(newReceipt);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// PUT /api/receipts/:id - Update receipt details with full audit tracking
router.put('/:id', (req, res) => {
  const { id } = req.params;
  const {
    receipt_date,
    customer_name,
    customer_phone,
    customer_address,
    description,
    amount,
    payment_method,
    transaction_id,
    payment_status,
    paid_amount,
    balance_amount,
    remarks,
    items,
    edited_by = 'Admin',
  } = req.body;

  try {
    const existing = db.prepare('SELECT * FROM receipts WHERE id = ?').get(id) as any;
    if (!existing) {
      return res.status(404).json({ error: 'Receipt not found' });
    }

    const cleanAmount = amount !== undefined ? parseFloat(amount) : existing.amount;
    let finalPaidAmount = paid_amount !== undefined ? parseFloat(paid_amount) : existing.paid_amount;
    let finalBalanceAmount = balance_amount !== undefined ? parseFloat(balance_amount) : existing.balance_amount;

    if (payment_status === 'Paid') {
      finalPaidAmount = cleanAmount;
      finalBalanceAmount = 0;
    } else if (payment_status === 'Pending') {
      finalPaidAmount = 0;
      finalBalanceAmount = cleanAmount;
    }

    const itemsJson = items !== undefined ? JSON.stringify(items) : existing.items_json;

    // Compute changed fields for audit log
    const changedFields: Record<string, { from: any; to: any }> = {};
    const checkFields: Record<string, any> = {
      receipt_date,
      customer_name,
      customer_phone,
      customer_address,
      description,
      amount: cleanAmount,
      payment_method,
      transaction_id,
      payment_status,
      paid_amount: finalPaidAmount,
      balance_amount: finalBalanceAmount,
      remarks,
    };

    for (const [k, v] of Object.entries(checkFields)) {
      if (v !== undefined && String(v) !== String(existing[k])) {
        changedFields[k] = { from: existing[k], to: v };
      }
    }

    db.prepare(`
      UPDATE receipts SET
        receipt_date = COALESCE(?, receipt_date),
        customer_name = COALESCE(?, customer_name),
        customer_phone = COALESCE(?, customer_phone),
        customer_address = COALESCE(?, customer_address),
        description = COALESCE(?, description),
        amount = COALESCE(?, amount),
        payment_method = COALESCE(?, payment_method),
        transaction_id = COALESCE(?, transaction_id),
        payment_status = COALESCE(?, payment_status),
        paid_amount = COALESCE(?, paid_amount),
        balance_amount = COALESCE(?, balance_amount),
        remarks = COALESCE(?, remarks),
        items_json = COALESCE(?, items_json),
        updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `).run(
      receipt_date,
      customer_name,
      customer_phone,
      customer_address,
      description,
      cleanAmount,
      payment_method,
      transaction_id,
      payment_status,
      finalPaidAmount,
      finalBalanceAmount,
      remarks,
      itemsJson,
      id
    );

    const updated = db.prepare('SELECT * FROM receipts WHERE id = ?').get(id) as any;

    // Save audit log
    db.prepare(`
      INSERT INTO receipt_audit_logs (receipt_id, receipt_number, action, changed_fields, previous_data, new_data, performed_by)
      VALUES (?, ?, 'UPDATED', ?, ?, ?, ?)
    `).run(
      existing.id,
      existing.receipt_number,
      JSON.stringify(changedFields),
      JSON.stringify(existing),
      JSON.stringify(updated),
      edited_by
    );

    res.json(updated);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/receipts/:id/whatsapp-status - Update WhatsApp sharing status
router.post('/:id/whatsapp-status', (req, res) => {
  const { id } = req.params;
  const { status, method = 'Click-to-Chat' } = req.body;

  try {
    const existing = db.prepare('SELECT * FROM receipts WHERE id = ?').get(id) as any;
    if (!existing) {
      return res.status(404).json({ error: 'Receipt not found' });
    }

    const now = new Date().toISOString();
    db.prepare(`
      UPDATE receipts 
      SET whatsapp_status = ?, whatsapp_sent_at = ?, updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `).run(status, now, id);

    // Record audit log
    db.prepare(`
      INSERT INTO receipt_audit_logs (receipt_id, receipt_number, action, changed_fields, performed_by)
      VALUES (?, ?, 'WHATSAPP_SHARED', ?, 'Admin')
    `).run(
      existing.id,
      existing.receipt_number,
      `Receipt shared via WhatsApp (${method}) at ${now}`
    );

    res.json({ success: true, status, sentAt: now });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// DELETE /api/receipts/:id
router.delete('/:id', (req, res) => {
  const { id } = req.params;

  try {
    const receipt = db.prepare('SELECT * FROM receipts WHERE id = ?').get(id) as any;
    if (!receipt) {
      return res.status(404).json({ error: 'Receipt not found' });
    }

    // Delete audit logs then receipt
    db.prepare('DELETE FROM receipt_audit_logs WHERE receipt_id = ?').run(id);
    db.prepare('DELETE FROM receipts WHERE id = ?').run(id);

    // Live broadcast to all connected devices & browsers
    broadcastEvent({
      type: 'RECEIPT_DELETED',
      receiptId: id,
      receiptNumber: receipt.receipt_number,
      timestamp: new Date().toISOString(),
    });

    res.json({ success: true, message: `Receipt ${receipt.receipt_number} deleted successfully` });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

export default router;


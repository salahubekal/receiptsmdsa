import React, { useEffect, useState } from 'react';
import QRCode from 'qrcode';
import { Receipt, Settings, LineItem } from '../types';
import { numberToWords } from '../utils/numberToWords';

interface Props {
  receipt: Partial<Receipt>;
  settings: Partial<Settings>;
  elementId?: string;
  isPrintMode?: boolean;
}

export const DigitalReceiptTemplate: React.FC<Props> = ({
  receipt,
  settings,
  elementId = 'digital-receipt-canvas',
  isPrintMode = false,
}) => {
  const [qrCodeDataUrl, setQrCodeDataUrl] = useState<string>('');

  const currency = settings.currency_symbol || '₹';
  const orgName = settings.org_name || 'AL AMEEN ENTERPRISES';
  const orgTagline = settings.org_tagline || 'Wholesale & Retail Trading Services';
  const orgAddress = settings.org_address || 'Commercial Avenue, City Center';
  const orgPhone = settings.org_phone || '+91 98765 43210';
  const orgEmail = settings.org_email || 'receipts@alameen.com';
  const orgTaxId = settings.org_tax_id || 'GSTIN: 32ABCDE1234F1Z5';
  const orgRegNo = settings.org_reg_no || 'REG-2024/KL/8892';
  const primaryColor = settings.primary_color || '#059669';
  const signatoryName = settings.signatory_name || 'Authorized Signatory';
  const signatoryTitle = settings.signatory_title || 'Accounts Department';
  const terms = settings.terms_and_conditions || '1. This is a computer-generated digital receipt.\n2. Goods once sold will be accepted under warranty policy only.\n3. Keep this digital receipt for all future correspondence.';

  // Parse line items
  let lineItems: LineItem[] = [];
  if (receipt.items_json) {
    try {
      lineItems = JSON.parse(receipt.items_json);
    } catch {
      lineItems = [];
    }
  }
  if (lineItems.length === 0 && receipt.description) {
    lineItems = [
      {
        description: receipt.description,
        quantity: 1,
        rate: receipt.amount || 0,
        amount: receipt.amount || 0,
      },
    ];
  }

  const amount = Number(receipt.amount || 0);
  const paidAmount = Number(receipt.paid_amount || 0);
  const balanceAmount = Number(receipt.balance_amount || 0);
  const amountWords = numberToWords(amount, settings.currency_code === 'USD' ? 'Dollars' : 'Rupees');

  // Generate QR Code with receipt verification details
  useEffect(() => {
    const verifyPayload = JSON.stringify({
      receiptNo: receipt.receipt_number,
      date: receipt.receipt_date,
      customer: receipt.customer_name,
      amount: `${currency} ${amount.toLocaleString()}`,
      status: receipt.payment_status,
      org: orgName,
      txId: receipt.transaction_id || 'N/A',
    });

    QRCode.toDataURL(verifyPayload, {
      width: 140,
      margin: 1,
      color: {
        dark: primaryColor || '#059669',
        light: '#ffffff',
      },
    })
      .then(url => setQrCodeDataUrl(url))
      .catch(err => console.error('QR code generation error:', err));
  }, [receipt.receipt_number, receipt.amount, receipt.payment_status, primaryColor, orgName]);

  // Status stamp configuration
  const statusColorMap = {
    'Paid': {
      border: 'border-emerald-600',
      text: 'text-emerald-700',
      bg: 'bg-emerald-50/80',
      label: 'PAID IN FULL',
    },
    'Partially Paid': {
      border: 'border-amber-600',
      text: 'text-amber-700',
      bg: 'bg-amber-50/80',
      label: 'PARTIALLY PAID',
    },
    'Pending': {
      border: 'border-rose-600',
      text: 'text-rose-700',
      bg: 'bg-rose-50/80',
      label: 'PAYMENT PENDING',
    },
  };

  const statusConfig = statusColorMap[receipt.payment_status as keyof typeof statusColorMap] || statusColorMap['Paid'];

  return (
    <div
      id={elementId}
      className={`bg-white text-slate-800 shadow-xl border border-slate-200 mx-auto relative overflow-hidden ${
        isPrintMode ? 'p-6 w-full' : 'p-6 sm:p-8 max-w-3xl rounded-xl'
      }`}
      style={{ fontFamily: "'Inter', sans-serif" }}
    >
      {/* Background Watermark */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none select-none opacity-[0.035]">
        <div className="text-center transform -rotate-12">
          <span className="text-7xl font-extrabold uppercase tracking-widest text-slate-900 block font-serif">
            {orgName}
          </span>
          <span className="text-4xl font-semibold tracking-wider text-slate-700 mt-2 block">
            OFFICIAL RECEIPT
          </span>
        </div>
      </div>

      {/* Security Guilloche-style double border container */}
      <div
        className="border-2 rounded-lg p-5 sm:p-7 relative"
        style={{ borderColor: primaryColor }}
      >
        {/* Inner thin security border */}
        <div
          className="absolute inset-1.5 border border-dashed rounded pointer-events-none opacity-40"
          style={{ borderColor: primaryColor }}
        />

        {/* TOP HEADER: Organization branding */}
        <div className="relative flex flex-col sm:flex-row items-center sm:items-start justify-between gap-4 border-b pb-5 mb-5 border-slate-200">
          <div className="flex items-center sm:items-start gap-4 text-center sm:text-left">
            {/* Logo */}
            {settings.logo_image ? (
              <img
                src={settings.logo_image}
                alt={orgName}
                className="w-16 h-16 sm:w-20 sm:h-20 object-contain rounded-lg border border-slate-100 p-1 bg-white shadow-sm flex-shrink-0"
              />
            ) : (
              <div
                className="w-16 h-16 sm:w-20 sm:h-20 rounded-xl flex flex-col items-center justify-center text-white font-bold shadow-md flex-shrink-0"
                style={{ backgroundColor: primaryColor }}
              >
                <span className="text-2xl sm:text-3xl font-serif">
                  {orgName.charAt(0) || 'R'}
                </span>
                <span className="text-[9px] tracking-widest uppercase opacity-90">Official</span>
              </div>
            )}

            <div>
              <h1
                className="text-xl sm:text-2xl font-extrabold tracking-tight uppercase"
                style={{ color: primaryColor }}
              >
                {orgName}
              </h1>
              {orgTagline && (
                <p className="text-xs sm:text-sm font-medium text-slate-600 mt-0.5">
                  {orgTagline}
                </p>
              )}
              <p className="text-xs text-slate-500 mt-1 max-w-sm leading-relaxed">
                {orgAddress}
              </p>
              <div className="flex flex-wrap items-center justify-center sm:justify-start gap-x-3 gap-y-1 text-[11px] text-slate-600 mt-1.5 font-medium">
                {orgPhone && <span>📞 {orgPhone}</span>}
                {orgEmail && <span>✉️ {orgEmail}</span>}
                {orgTaxId && <span className="bg-slate-100 px-1.5 py-0.5 rounded text-slate-700">{orgTaxId}</span>}
              </div>
            </div>
          </div>

          {/* Receipt Badge and Date */}
          <div className="text-center sm:text-right flex-shrink-0">
            <div
              className="inline-block px-3 py-1 rounded text-white text-xs font-bold uppercase tracking-wider mb-2 shadow-sm"
              style={{ backgroundColor: primaryColor }}
            >
              Money Receipt
            </div>
            <div className="bg-slate-50 border border-slate-200 rounded-lg p-2.5 shadow-inner">
              <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                Receipt Number
              </div>
              <div className="text-sm sm:text-base font-mono font-bold text-slate-900">
                {receipt.receipt_number || 'REC-XXXX-XXXX'}
              </div>
              <div className="text-[11px] text-slate-500 mt-1 font-medium">
                Date: <span className="font-semibold text-slate-700">{receipt.receipt_date || new Date().toISOString().split('T')[0]}</span>
              </div>
            </div>
          </div>
        </div>

        {/* PAYMENT STATUS RUBBER STAMP */}
        <div className="absolute top-28 sm:top-24 right-6 sm:right-10 pointer-events-none transform rotate-12 select-none z-10">
          <div
            className={`border-4 border-dashed rounded-lg px-3 py-1 sm:px-4 sm:py-1.5 text-center font-extrabold text-sm sm:text-base uppercase tracking-widest shadow-sm ${statusConfig.border} ${statusConfig.text} ${statusConfig.bg}`}
          >
            {statusConfig.label}
          </div>
        </div>

        {/* CUSTOMER DETAILS ROW: "Received with thanks from" */}
        <div className="bg-gradient-to-r from-slate-50 to-white border border-slate-200 rounded-lg p-3.5 sm:p-4 mb-5">
          <div className="flex items-center gap-2 mb-2">
            <span
              className="w-2.5 h-2.5 rounded-full inline-block"
              style={{ backgroundColor: primaryColor }}
            />
            <span className="text-xs font-bold uppercase tracking-wider text-slate-600">
              Received with thanks from
            </span>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 sm:gap-4">
            <div className="sm:col-span-2">
              <div className="text-base sm:text-lg font-bold text-slate-900">
                {receipt.customer_name || 'Customer Name'}
              </div>
              {receipt.customer_address && (
                <div className="text-xs text-slate-600 mt-0.5">
                  📍 {receipt.customer_address}
                </div>
              )}
            </div>
            <div className="text-left sm:text-right">
              <div className="text-xs text-slate-500 font-medium">Contact / WhatsApp</div>
              <div className="text-xs sm:text-sm font-semibold font-mono text-slate-800">
                📱 {receipt.customer_phone || 'N/A'}
              </div>
            </div>
          </div>

          {/* Student Collector Details & Verification Status */}
          {receipt.student_name && (
            <div className="mt-3 pt-2.5 border-t border-slate-200/80 flex flex-wrap items-center justify-between gap-2 text-xs">
              <div className="flex items-center gap-1.5 text-slate-700">
                <span className="font-semibold text-slate-500">Collected By:</span>
                <span className="font-bold text-slate-900">{receipt.student_name}</span>
                {receipt.student_id && (
                  <span className="font-mono bg-purple-50 text-purple-700 px-1.5 py-0.5 rounded text-[11px] font-bold border border-purple-200">
                    ID: {receipt.student_id}
                  </span>
                )}
              </div>

              <div className="flex items-center gap-1.5">
                <span className="text-[11px] text-slate-500">Verification:</span>
                <span
                  className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                    receipt.verification_status === 'Admin Verified'
                      ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                      : 'bg-amber-100 text-amber-800 border border-amber-300'
                  }`}
                >
                  {receipt.verification_status || 'Self-Reported'}
                </span>
              </div>
            </div>
          )}

          {/* Collection Location & Group Squad Information (Requirements 10 & 11) */}
          {(receipt.location_name || receipt.group_name || receipt.collecting_member_name) && (
            <div className="mt-2 pt-2 border-t border-dashed border-slate-200 flex flex-wrap items-center justify-between gap-2 text-[11px] text-slate-600">
              {receipt.location_name && (
                <div className="flex items-center gap-1">
                  <span className="font-semibold text-slate-500">Venue:</span>
                  <span className="font-bold text-slate-800">📍 {receipt.location_name}</span>
                </div>
              )}
              {receipt.group_name && (
                <div className="flex items-center gap-1">
                  <span className="font-semibold text-slate-500">Squad Group:</span>
                  <span className="font-bold text-indigo-700">👥 {receipt.group_name}</span>
                  {receipt.collecting_member_name && receipt.collecting_member_name !== receipt.student_name && (
                    <span className="text-slate-500">(Collected by: {receipt.collecting_member_name})</span>
                  )}
                </div>
              )}
            </div>
          )}
        </div>

        {/* PARTICULARS / LINE ITEMS TABLE */}
        <div className="mb-5 overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs sm:text-sm">
            <thead>
              <tr
                className="text-white text-xs uppercase tracking-wider"
                style={{ backgroundColor: primaryColor }}
              >
                <th className="py-2.5 px-3 rounded-tl-md w-12 text-center">#</th>
                <th className="py-2.5 px-3">Description / Purpose of Payment</th>
                <th className="py-2.5 px-3 w-16 text-center">Qty</th>
                <th className="py-2.5 px-3 w-24 text-right">Rate</th>
                <th className="py-2.5 px-3 rounded-tr-md w-28 text-right">Amount ({currency})</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 border-x border-b border-slate-200">
              {lineItems.map((item, idx) => (
                <tr key={idx} className={idx % 2 === 0 ? 'bg-white' : 'bg-slate-50/50'}>
                  <td className="py-2.5 px-3 text-center font-medium text-slate-400">{idx + 1}</td>
                  <td className="py-2.5 px-3 font-medium text-slate-800">
                    {item.description}
                  </td>
                  <td className="py-2.5 px-3 text-center text-slate-600">{item.quantity || 1}</td>
                  <td className="py-2.5 px-3 text-right font-mono text-slate-600">
                    {Number(item.rate || 0).toLocaleString()}
                  </td>
                  <td className="py-2.5 px-3 text-right font-mono font-semibold text-slate-900">
                    {Number(item.amount || (item.quantity * item.rate) || 0).toLocaleString()}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* AMOUNT SUMMARY & WORDS SECTION */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-5 items-stretch">
          {/* Amount in words & payment details */}
          <div className="bg-slate-50 border border-slate-200 rounded-lg p-3.5 flex flex-col justify-between">
            <div>
              <div className="text-[11px] font-bold uppercase tracking-wider text-slate-500 mb-1">
                Amount in Words
              </div>
              <div className="text-xs sm:text-sm font-serif italic text-slate-800 leading-snug">
                "{amountWords}"
              </div>
            </div>

            <div className="mt-3 pt-3 border-t border-slate-200 grid grid-cols-2 gap-2 text-xs">
              <div>
                <span className="text-slate-400 block text-[10px] uppercase font-semibold">Method</span>
                <span className="font-semibold text-slate-800 bg-white border border-slate-200 px-2 py-0.5 rounded inline-block mt-0.5">
                  {receipt.payment_method || 'Cash'}
                </span>
              </div>
              <div>
                <span className="text-slate-400 block text-[10px] uppercase font-semibold">Txn Reference</span>
                <span className="font-mono text-slate-700 text-[11px] truncate block mt-0.5">
                  {receipt.transaction_id || 'Direct Payment'}
                </span>
              </div>
            </div>
          </div>

          {/* Amount Breakdown Box */}
          <div className="border border-slate-200 rounded-lg p-3.5 bg-white flex flex-col justify-between">
            <div className="space-y-1.5 text-xs">
              <div className="flex justify-between text-slate-600">
                <span>Total Bill Amount:</span>
                <span className="font-mono font-semibold">{currency} {amount.toLocaleString()}</span>
              </div>
              <div className="flex justify-between text-emerald-700">
                <span>Amount Paid:</span>
                <span className="font-mono font-bold">{currency} {paidAmount.toLocaleString()}</span>
              </div>
              {balanceAmount > 0 && (
                <div className="flex justify-between text-rose-600 font-medium">
                  <span>Balance Due:</span>
                  <span className="font-mono font-bold">{currency} {balanceAmount.toLocaleString()}</span>
                </div>
              )}
            </div>

            <div
              className="mt-3 pt-3 border-t-2 flex items-center justify-between"
              style={{ borderColor: primaryColor }}
            >
              <span className="text-xs sm:text-sm font-bold uppercase text-slate-800">
                Net Received
              </span>
              <span
                className="text-lg sm:text-2xl font-extrabold font-mono"
                style={{ color: primaryColor }}
              >
                {currency} {paidAmount.toLocaleString()}
              </span>
            </div>
          </div>
        </div>

        {/* REMARKS (if provided) */}
        {receipt.remarks && (
          <div className="mb-5 bg-amber-50/60 border border-amber-200/80 rounded-md p-2.5 text-xs text-amber-900">
            <span className="font-bold">Remarks / Instructions: </span>
            <span>{receipt.remarks}</span>
          </div>
        )}

        {/* BOTTOM AUTHENTICATION & SIGNATURE ROW */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 items-end pt-3 border-t border-slate-200">
          {/* Verification QR Code */}
          {settings.show_qr_code !== 'false' && qrCodeDataUrl && (
            <div className="flex items-center gap-2.5 sm:col-span-1">
              <img
                src={qrCodeDataUrl}
                alt="Receipt Verification QR"
                className="w-16 h-16 rounded border border-slate-200 p-0.5 bg-white shadow-sm flex-shrink-0"
              />
              <div className="text-[10px] text-slate-500 leading-tight">
                <span className="font-bold text-slate-700 block">Digital Verification</span>
                Scan QR with smartphone to verify authentic receipt authenticity.
              </div>
            </div>
          )}

          {/* Terms & Conditions Snippet */}
          <div className="sm:col-span-1 text-[9px] text-slate-400 leading-tight whitespace-pre-line hidden sm:block">
            {terms}
          </div>

          {/* Authorized Signatory section */}
          {settings.show_signature !== 'false' && (
            <div className="text-center sm:text-right flex flex-col items-center sm:items-end sm:col-span-1">
              <div className="h-12 flex items-end justify-center sm:justify-end mb-1">
                {settings.signature_image ? (
                  <img
                    src={settings.signature_image}
                    alt="Authorized Signature"
                    className="max-h-12 object-contain"
                  />
                ) : (
                  <span className="font-serif italic text-lg text-slate-700 font-semibold tracking-wide">
                    {signatoryName}
                  </span>
                )}
              </div>
              <div className="w-36 border-t border-slate-400 pt-1 text-center sm:text-right">
                <div className="text-[11px] font-bold text-slate-800">{signatoryName}</div>
                <div className="text-[10px] text-slate-500">{signatoryTitle}</div>
              </div>
            </div>
          )}
        </div>

        {/* Bottom footer text & Copyright / Developer Support */}
        <div className="text-[9px] sm:text-[10px] text-slate-400 mt-4 pt-2.5 border-t border-slate-100 flex flex-col sm:flex-row items-center justify-between gap-1 text-center sm:text-left">
          <div className="flex items-center gap-1.5">
            <span className="font-bold text-slate-600">© 2026 MDSA.</span>
            <span>All rights reserved. Duplication strictly banned.</span>
          </div>
          <div className="flex items-center gap-1.5 text-slate-500 font-medium">
            <span>Dev Support: <strong className="text-slate-700">salahubekal@gmail.com</strong></span>
            <span>•</span>
            <span>Issued on {receipt.receipt_date || new Date().toISOString().split('T')[0]}</span>
          </div>
        </div>
      </div>
    </div>
  );
};


import { Router, Response } from 'express';

const router = Router();

// Store active SSE client response objects across all devices & browsers
const clients: Set<Response> = new Set();

export function broadcastEvent(data: any) {
  const payload = `data: ${JSON.stringify(data)}\n\n`;
  for (const client of clients) {
    try {
      client.write(payload);
    } catch (err) {
      clients.delete(client);
    }
  }
}

export const broadcastPaymentEvent = broadcastEvent;

// GET /api/realtime/stream - Unified Live Realtime Event Stream
router.get('/stream', (req, res) => {
  res.writeHead(200, {
    'Content-Type': 'text/event-stream',
    'Cache-Control': 'no-cache, no-transform',
    'Connection': 'keep-alive',
    'Access-Control-Allow-Origin': '*',
    'X-Accel-Buffering': 'no',
  });

  res.write(`data: ${JSON.stringify({ type: 'CONNECTED', message: 'MDSA Live Stream Connected', timestamp: new Date().toISOString() })}\n\n`);

  clients.add(res);

  // Keep connection alive with periodic comment ping every 15 seconds
  const interval = setInterval(() => {
    try {
      res.write(': ping\n\n');
    } catch {
      clearInterval(interval);
      clients.delete(res);
    }
  }, 15000);

  req.on('close', () => {
    clearInterval(interval);
    clients.delete(res);
  });
});

export default router;

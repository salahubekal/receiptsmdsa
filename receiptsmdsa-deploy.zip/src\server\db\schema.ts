export const SCHEMA_SQL = `
-- Collection Locations / Venues
CREATE TABLE IF NOT EXISTS locations (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  location_code TEXT UNIQUE NOT NULL,
  name TEXT NOT NULL,
  city_or_area TEXT DEFAULT '',
  description TEXT DEFAULT '',
  status TEXT DEFAULT 'Active',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Collection Groups
CREATE TABLE IF NOT EXISTS groups (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  group_id TEXT UNIQUE NOT NULL,
  group_name TEXT NOT NULL UNIQUE,
  leader_student_id TEXT DEFAULT '',
  leader_name TEXT NOT NULL,
  leader_phone TEXT NOT NULL,
  location_id INTEGER,
  location_name TEXT DEFAULT '',
  notes TEXT DEFAULT '',
  total_collected REAL DEFAULT 0,
  status TEXT DEFAULT 'Active',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (location_id) REFERENCES locations(id) ON DELETE SET NULL
);

-- Group Members (unlimited members per group)
CREATE TABLE IF NOT EXISTS group_members (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  group_id INTEGER NOT NULL,
  student_id TEXT DEFAULT '',
  member_name TEXT NOT NULL,
  member_phone TEXT NOT NULL,
  role TEXT DEFAULT 'Member', -- 'Leader' or 'Member'
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (group_id) REFERENCES groups(id) ON DELETE CASCADE
);

-- Students table
CREATE TABLE IF NOT EXISTS students (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER,
  student_id TEXT UNIQUE NOT NULL,
  name TEXT NOT NULL,
  phone TEXT NOT NULL UNIQUE,
  email TEXT DEFAULT '',
  class_name TEXT DEFAULT 'MDSA Batch 2026',
  location_id INTEGER,
  location_name TEXT DEFAULT '',
  group_id TEXT DEFAULT '',
  group_name TEXT DEFAULT '',
  total_collected REAL DEFAULT 0,
  status TEXT DEFAULT 'Active',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (location_id) REFERENCES locations(id) ON DELETE SET NULL
);

-- Customers / Payers table
CREATE TABLE IF NOT EXISTS customers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  phone TEXT NOT NULL UNIQUE,
  email TEXT DEFAULT '',
  address TEXT DEFAULT '',
  student_id TEXT DEFAULT '',
  class_name TEXT DEFAULT 'MDSA Batch 2026',
  notes TEXT DEFAULT '',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Payments collection records
CREATE TABLE IF NOT EXISTS payments (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  receipt_id INTEGER,
  receipt_number TEXT UNIQUE NOT NULL,
  student_id TEXT NOT NULL,
  student_name TEXT NOT NULL,
  group_id TEXT DEFAULT '',
  group_name TEXT DEFAULT '',
  collecting_member_name TEXT DEFAULT '',
  collecting_member_phone TEXT DEFAULT '',
  location_id INTEGER DEFAULT NULL,
  location_name TEXT DEFAULT '',
  payer_name TEXT NOT NULL,
  payer_phone TEXT NOT NULL,
  amount REAL NOT NULL,
  payment_purpose TEXT NOT NULL,
  payment_method TEXT NOT NULL, -- Cash, UPI, Bank Transfer, Other
  transaction_ref TEXT DEFAULT '',
  payment_date TEXT NOT NULL,
  verification_status TEXT DEFAULT 'Self-Reported', -- Self-Reported, Admin Verified, Flagged
  verified_by TEXT DEFAULT '',
  verified_at DATETIME,
  remarks TEXT DEFAULT '',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Receipts table
CREATE TABLE IF NOT EXISTS receipts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  receipt_number TEXT NOT NULL UNIQUE,
  receipt_date TEXT NOT NULL,
  customer_id INTEGER,
  customer_name TEXT NOT NULL,
  customer_phone TEXT NOT NULL,
  customer_address TEXT DEFAULT '',
  student_id TEXT DEFAULT '',
  student_name TEXT DEFAULT '',
  group_id TEXT DEFAULT '',
  group_name TEXT DEFAULT '',
  collecting_member_name TEXT DEFAULT '',
  collecting_member_phone TEXT DEFAULT '',
  location_id INTEGER DEFAULT NULL,
  location_name TEXT DEFAULT '',
  description TEXT NOT NULL,
  amount REAL NOT NULL,
  payment_method TEXT NOT NULL, -- Cash, UPI, Bank Transfer, Other
  transaction_id TEXT DEFAULT '',
  payment_status TEXT NOT NULL DEFAULT 'Paid', -- Paid, Partially Paid, Pending
  verification_status TEXT DEFAULT 'Self-Reported', -- Self-Reported, Admin Verified, Flagged
  paid_amount REAL DEFAULT 0,
  balance_amount REAL DEFAULT 0,
  remarks TEXT DEFAULT '',
  items_json TEXT DEFAULT '[]',
  whatsapp_status TEXT DEFAULT 'Generated', -- Generated, Queued, Sent, Delivered, Read, Failed
  whatsapp_message_id TEXT DEFAULT '',
  whatsapp_sent_at DATETIME,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE SET NULL
);

-- WhatsApp message tracking table
CREATE TABLE IF NOT EXISTS whatsapp_messages (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  receipt_id INTEGER,
  receipt_number TEXT,
  payer_phone TEXT NOT NULL,
  payer_name TEXT NOT NULL,
  message_text TEXT,
  message_id TEXT,
  status TEXT DEFAULT 'Generated', -- Generated, Queued, Sent, Delivered, Read, Failed
  error_message TEXT,
  delivery_timestamp DATETIME,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Receipt audit log
CREATE TABLE IF NOT EXISTS receipt_audit_logs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  receipt_id INTEGER NULL,
  receipt_number TEXT NOT NULL,
  action TEXT NOT NULL,
  changed_fields TEXT,
  previous_data TEXT,
  new_data TEXT,
  performed_by TEXT DEFAULT 'Admin',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (receipt_id) REFERENCES receipts(id) ON DELETE SET NULL
);

-- System Settings & Receipt Template Configuration
CREATE TABLE IF NOT EXISTS settings (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL
);

-- Users / Admin & Student credentials
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'admin', -- 'admin' or 'student'
  full_name TEXT DEFAULT 'Administrator',
  student_id TEXT DEFAULT '',
  customer_id INTEGER DEFAULT NULL,
  must_change_password INTEGER DEFAULT 0,
  password_changed_at DATETIME DEFAULT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_locations_code ON locations(location_code);
CREATE INDEX IF NOT EXISTS idx_groups_id ON groups(group_id);
CREATE INDEX IF NOT EXISTS idx_group_members_group ON group_members(group_id);
CREATE INDEX IF NOT EXISTS idx_payments_student ON payments(student_id);
CREATE INDEX IF NOT EXISTS idx_payments_group ON payments(group_id);
CREATE INDEX IF NOT EXISTS idx_payments_location ON payments(location_id);
CREATE INDEX IF NOT EXISTS idx_payments_date ON payments(payment_date);
CREATE INDEX IF NOT EXISTS idx_receipts_number ON receipts(receipt_number);
CREATE INDEX IF NOT EXISTS idx_receipts_student ON receipts(student_id);
CREATE INDEX IF NOT EXISTS idx_receipts_group ON receipts(group_id);
CREATE INDEX IF NOT EXISTS idx_receipts_location ON receipts(location_id);
CREATE INDEX IF NOT EXISTS idx_receipts_customer ON receipts(customer_name);
CREATE INDEX IF NOT EXISTS idx_receipts_phone ON receipts(customer_phone);
CREATE INDEX IF NOT EXISTS idx_receipts_date ON receipts(receipt_date);
CREATE INDEX IF NOT EXISTS idx_receipts_status ON receipts(payment_status);
CREATE INDEX IF NOT EXISTS idx_customers_phone ON customers(phone);
CREATE INDEX IF NOT EXISTS idx_students_phone ON students(phone);
`;

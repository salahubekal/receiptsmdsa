import React from 'react';
import {
  FileText,
  DollarSign,
  Calendar,
  TrendingUp,
  AlertTriangle,
  ArrowUpRight,
  Wallet,
} from 'lucide-react';
import { DashboardStats as StatsType, Settings } from '../types';

interface Props {
  stats: StatsType | null;
  settings: Partial<Settings>;
  onNewReceiptClick: () => void;
  onViewPendingClick: () => void;
}

export const DashboardStats: React.FC<Props> = ({
  stats,
  settings,
  onNewReceiptClick,
  onViewPendingClick,
}) => {
  const currency = settings.currency_symbol || '₹';

  if (!stats) {
    return (
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4 animate-pulse">
        {[1, 2, 3, 4, 5].map((i) => (
          <div key={i} className="h-28 bg-slate-200 rounded-2xl"></div>
        ))}
      </div>
    );
  }

  const cards = [
    {
      title: 'Total Receipts',
      value: stats.totalReceipts.toLocaleString(),
      subtext: 'Lifetime issued receipts',
      icon: FileText,
      color: 'emerald',
      bgLight: 'bg-emerald-50 text-emerald-700',
    },
    {
      title: 'Total Collected',
      value: `${currency} ${Number(stats.totalAmountCollected).toLocaleString()}`,
      subtext: 'All time payments cleared',
      icon: Wallet,
      color: 'teal',
      bgLight: 'bg-teal-50 text-teal-700',
    },
    {
      title: "Today's Receipts",
      value: `${currency} ${Number(stats.todayAmountCollected).toLocaleString()}`,
      subtext: `${stats.todayReceiptsCount} receipts today`,
      icon: Calendar,
      color: 'blue',
      bgLight: 'bg-blue-50 text-blue-700',
    },
    {
      title: 'Monthly Collection',
      value: `${currency} ${Number(stats.monthlyAmountCollected).toLocaleString()}`,
      subtext: `${stats.monthlyReceiptsCount} receipts this month`,
      icon: TrendingUp,
      color: 'indigo',
      bgLight: 'bg-indigo-50 text-indigo-700',
    },
    {
      title: 'Pending Payments',
      value: `${currency} ${Number(stats.pendingAmount).toLocaleString()}`,
      subtext: `${stats.pendingCount} unpaid / partial receipts`,
      icon: AlertTriangle,
      color: 'rose',
      bgLight: 'bg-rose-50 text-rose-700',
      action: onViewPendingClick,
    },
  ];

  return (
    <div className="space-y-4">
      {/* 5 Key Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3.5 sm:gap-4">
        {cards.map((c, i) => {
          const Icon = c.icon;
          return (
            <div
              key={i}
              onClick={c.action}
              className={`bg-white rounded-2xl p-4 sm:p-5 border border-slate-200 shadow-sm transition-all hover:shadow-md ${
                c.action ? 'cursor-pointer hover:border-rose-300' : ''
              }`}
            >
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
                  {c.title}
                </span>
                <div className={`w-9 h-9 rounded-xl flex items-center justify-center ${c.bgLight}`}>
                  <Icon className="w-5 h-5" />
                </div>
              </div>
              <div className="text-lg sm:text-xl font-extrabold font-mono text-slate-900 tracking-tight truncate">
                {c.value}
              </div>
              <p className="text-[11px] text-slate-500 mt-1 font-medium flex items-center justify-between">
                <span>{c.subtext}</span>
                {c.action && (
                  <span className="text-rose-600 font-bold flex items-center gap-0.5">
                    View <ArrowUpRight className="w-3 h-3" />
                  </span>
                )}
              </p>
            </div>
          );
        })}
      </div>

      {/* Payment methods distribution bar */}
      {stats.paymentMethods && stats.paymentMethods.length > 0 && (
        <div className="bg-white rounded-xl p-3.5 border border-slate-200 flex flex-wrap items-center justify-between gap-3 text-xs">
          <span className="font-bold text-slate-600 uppercase text-[11px] tracking-wider">
            Payment Breakdown:
          </span>
          <div className="flex flex-wrap items-center gap-2">
            {stats.paymentMethods.map((m, idx) => (
              <span
                key={idx}
                className="bg-slate-50 border border-slate-200 px-2.5 py-1 rounded-lg text-slate-700 font-medium flex items-center gap-1.5"
              >
                <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                <span>{m.payment_method}:</span>
                <span className="font-bold font-mono">
                  {currency} {Number(m.total).toLocaleString()}
                </span>
                <span className="text-slate-400 text-[10px]">({m.count})</span>
              </span>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};


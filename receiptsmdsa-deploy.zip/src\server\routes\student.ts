import { Router, Response } from 'express';
import jwt from 'jsonwebtoken';
import { db } from '../db/index.js';
import { AuthRequest } from './auth.js';

const router = Router();
const JWT_SECRET = process.env.JWT_SECRET || 'paperless-receipt-secret-key-2026';

// Middleware to verify student token
export function authenticateStudent(req: AuthRequest, res: Response, next: Function) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ error: 'Authentication required. Please log in.' });
  }

  try {
    const decoded = jwt.verify(token, JWT_SECRET) as any;
    req.user = decoded;
    if (decoded.role !== 'student' && decoded.role !== 'admin') {
      return res.status(403).json({ error: 'Access denied. Student portal only.' });
    }
    next();
  } catch (err) {
    return res.status(403).json({ error: 'Invalid or expired session. Please log in again.' });
  }
}

// GET /api/student/dashboard - Fetch student's personal payment collection metrics & history
router.get('/dashboard', authenticateStudent, (req: AuthRequest, res) => {
  try {
    const userId = req.user?.id;
    const user = db.prepare('SELECT * FROM users WHERE id = ?').get(userId) as any;

    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    const studentId = user.student_id || 'STD-2026-001';
    const student = db.prepare('SELECT * FROM students WHERE student_id = ?').get(studentId) as any || {
      student_id: studentId,
      name: user.full_name,
      phone: '+91 98470 12345',
      class_name: 'MDSA Batch 2026',
    };

    const today = new Date().toISOString().split('T')[0];

    // Student collection metrics
    const stats = db.prepare(`
      SELECT 
        COALESCE(SUM(amount), 0) as total_collection,
        COUNT(id) as total_receipts,
        COALESCE(SUM(CASE WHEN payment_date = ? THEN amount ELSE 0 END), 0) as today_collection,
        COUNT(CASE WHEN payment_date = ? THEN id ELSE NULL END) as today_payments
      FROM payments
      WHERE student_id = ?
    `).get(today, today, studentId) as any;

    // Student's recent payments (only their own records)
    const payments = db.prepare(`
      SELECT * FROM payments 
      WHERE student_id = ? 
      ORDER BY created_at DESC 
      LIMIT 100
    `).all(studentId) as any[];

    // Student's generated receipts
    const receipts = db.prepare(`
      SELECT * FROM receipts 
      WHERE student_id = ? 
      ORDER BY created_at DESC 
      LIMIT 100
    `).all(studentId) as any[];

    // Fetch student's group members if assigned
    let groupMembers: any[] = [];
    if (student.group_id) {
      const grp = db.prepare('SELECT id, group_id, group_name, leader_name, leader_phone, location_name FROM groups WHERE group_id = ?').get(student.group_id) as any;
      if (grp) {
        groupMembers = db.prepare('SELECT id, student_id, member_name, member_phone, role FROM group_members WHERE group_id = ?').all(grp.id);
      }
    }

    res.json({
      student: {
        id: user.id,
        name: user.full_name,
        username: user.username,
        student_id: studentId,
        phone: student.phone,
        email: student.email,
        class_name: student.class_name,
        location_id: student.location_id,
        location_name: student.location_name,
        group_id: student.group_id,
        group_name: student.group_name,
        must_change_password: Boolean(user.must_change_password),
      },
      groupMembers,
      summary: {
        todayCollection: stats.today_collection || 0,
        totalCollection: stats.total_collection || 0,
        todayPayments: stats.today_payments || 0,
        totalReceipts: stats.total_receipts || 0,
      },
      payments,
      receipts,
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

export default router;

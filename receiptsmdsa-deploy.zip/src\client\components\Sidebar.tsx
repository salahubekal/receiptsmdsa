import React from 'react';
import {
  Home,
  LayoutDashboard,
  FileText,
  Users,
  GraduationCap,
  TrendingUp,
  MapPin,
  PlusCircle,
  Palette,
  Database,
  X,
  LogOut,
  Sparkles,
  Shield,
  Lamp,
  Layers,
  Mail,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export type NavTab =
  | 'dashboard'
  | 'reports'
  | 'students'
  | 'groups'
  | 'locations'
  | 'create'
  | 'receipts'
  | 'customers'
  | 'template'
  | 'backup';

interface Props {
  activeTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
  isOpenMobile: boolean;
  onCloseMobile: () => void;
}

export const Sidebar: React.FC<Props> = ({
  activeTab,
  onSelectTab,
  isOpenMobile,
  onCloseMobile,
}) => {
  const { logout } = useAuth();

  // Navigation Items matching the exact icon sequence of the model:
  // Home, Grid/Receipts, Lamp/Venues, Shield/Squads, Pin/Locations, Users/Students, BarChart/Reports
  const navItems = [
    { id: 'dashboard', label: 'Home Dashboard', icon: Home, badge: null },
    { id: 'receipts', label: 'Digital Receipts', icon: Layers, badge: null },
    { id: 'locations', label: 'Collection Venues', icon: Lamp, badge: 'Venues' },
    { id: 'groups', label: 'Squad Groups', icon: Shield, badge: 'Squads' },
    { id: 'students', label: 'Student Collectors', icon: Users, badge: 'Students' },
    { id: 'reports', label: 'Analytics & Reports', icon: TrendingUp, badge: 'Reports' },
    { id: 'create', label: 'Create Receipt', icon: PlusCircle, badge: 'New' },
    { id: 'customers', label: 'Customers', icon: GraduationCap, badge: null },
    { id: 'template', label: 'Template Designer', icon: Palette, badge: null },
    { id: 'backup', label: 'Database Backup', icon: Database, badge: null },
  ];

  const handleNavClick = (id: NavTab) => {
    onSelectTab(id);
    onCloseMobile();
  };

  return (
    <>
      {/* DESKTOP SLEEK VIOLET BAR (MATCHING THE UPLOADED MODEL) */}
      <aside className="hidden md:flex flex-col items-center justify-between py-6 w-20 flex-shrink-0 bg-[#6D28D9] text-white rounded-3xl my-4 ml-4 shadow-xl shadow-purple-900/20 select-none z-20">
        
        {/* Top Branding Mark / Logo Dot */}
        <div className="flex flex-col items-center gap-4 w-full">
          <div className="w-10 h-10 rounded-2xl bg-white/10 backdrop-blur-md flex items-center justify-center font-black text-white text-base shadow-sm">
            M
          </div>

          {/* Navigation Icons Stack */}
          <div className="flex flex-col items-center gap-2.5 w-full px-2 mt-2">
            {navItems.slice(0, 7).map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;

              return (
                <div key={item.id} className="relative group w-full flex justify-center">
                  <button
                    type="button"
                    onClick={() => handleNavClick(item.id as NavTab)}
                    className={`relative w-12 h-12 rounded-2xl flex items-center justify-center transition-all duration-300 ${
                      isActive
                        ? 'bg-white text-[#6D28D9] shadow-lg shadow-purple-950/20 scale-105'
                        : 'text-purple-200 hover:text-white hover:bg-white/10'
                    }`}
                  >
                    <Icon className="w-5 h-5" />
                    
                    {/* Small badge dot if available */}
                    {item.badge && !isActive && (
                      <span className="w-2 h-2 rounded-full bg-amber-400 absolute top-2 right-2 ring-1 ring-[#6D28D9]"></span>
                    )}
                  </button>

                  {/* Sleek Floating Hover Tooltip */}
                  <div className="absolute left-16 top-2.5 z-50 pointer-events-none opacity-0 group-hover:opacity-100 transition-opacity bg-slate-900 text-white text-xs font-bold py-1.5 px-3 rounded-xl whitespace-nowrap shadow-xl">
                    {item.label}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Bottom Actions: Support / Settings / Logout */}
        <div className="flex flex-col items-center gap-3 w-full px-2">
          {/* Developer Support Mail */}
          <a
            href="mailto:salahubekal@gmail.com"
            title="Developer Support: salahubekal@gmail.com"
            className="w-11 h-11 rounded-2xl text-purple-300 hover:text-white hover:bg-white/10 flex items-center justify-center transition-colors"
          >
            <Mail className="w-4 h-4" />
          </a>

          {/* Database Backup */}
          <button
            type="button"
            onClick={() => handleNavClick('backup')}
            title="Database & Storage"
            className={`w-11 h-11 rounded-2xl flex items-center justify-center transition-colors ${
              activeTab === 'backup'
                ? 'bg-white text-[#6D28D9]'
                : 'text-purple-300 hover:text-white hover:bg-white/10'
            }`}
          >
            <Database className="w-4 h-4" />
          </button>

          {/* Logout Button matching model bottom exit icon */}
          <button
            type="button"
            onClick={logout}
            title="Sign Out"
            className="w-11 h-11 rounded-2xl text-purple-300 hover:text-rose-200 hover:bg-rose-500/20 flex items-center justify-center transition-all"
          >
            <LogOut className="w-5 h-5 transform rotate-180" />
          </button>
        </div>
      </aside>

      {/* MOBILE DRAWER */}
      {isOpenMobile && (
        <div className="fixed inset-0 z-50 md:hidden flex">
          <div
            className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm"
            onClick={onCloseMobile}
          />
          <div className="relative w-72 max-w-full bg-[#6D28D9] text-white h-full shadow-2xl flex flex-col justify-between p-5 z-10">
            <div>
              <div className="flex items-center justify-between pb-4 border-b border-purple-500/30 mb-4">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-xl bg-white/20 flex items-center justify-center font-bold">
                    M
                  </div>
                  <span className="font-extrabold text-sm tracking-wide">MDSA Navigation</span>
                </div>
                <button
                  type="button"
                  onClick={onCloseMobile}
                  className="p-1.5 rounded-xl hover:bg-white/10 text-purple-200"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="space-y-1">
                {navItems.map((item) => {
                  const Icon = item.icon;
                  const isActive = activeTab === item.id;
                  return (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => handleNavClick(item.id as NavTab)}
                      className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-bold transition-all ${
                        isActive
                          ? 'bg-white text-[#6D28D9] shadow-md'
                          : 'text-purple-100 hover:bg-white/10'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <Icon className="w-4 h-4" />
                        <span>{item.label}</span>
                      </div>
                      {item.badge && (
                        <span className={`text-[9px] px-1.5 py-0.5 rounded-md ${
                          isActive ? 'bg-purple-100 text-purple-800' : 'bg-purple-800 text-purple-200'
                        }`}>
                          {item.badge}
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Mobile Drawer Footer: Support & Copyright */}
            <div className="pt-4 border-t border-purple-500/30 text-xs text-purple-200 space-y-2.5 my-2">
              <div className="flex items-center gap-1.5 text-[10px] font-bold text-red-300 bg-red-950/40 border border-red-500/30 px-2 py-1 rounded-lg">
                <Shield className="w-3 h-3 text-red-400" />
                <span>Duplication Strictly Banned</span>
              </div>
              <div className="text-[11px] text-purple-200 font-medium">
                © 2026 MDSA. All Rights Reserved.
              </div>
              <a
                href="mailto:salahubekal@gmail.com"
                className="flex items-center gap-2 p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white font-bold text-xs transition-colors"
              >
                <Mail className="w-3.5 h-3.5 text-purple-300" />
                <span>Support: salahubekal@gmail.com</span>
              </a>
            </div>

            <button
              type="button"
              onClick={logout}
              className="w-full flex items-center justify-center gap-2 py-3 rounded-xl bg-rose-600/20 text-rose-200 hover:bg-rose-600 hover:text-white text-xs font-bold transition-all"
            >
              <LogOut className="w-4 h-4" />
              <span>Sign Out</span>
            </button>
          </div>
        </div>
      )}
    </>
  );
};

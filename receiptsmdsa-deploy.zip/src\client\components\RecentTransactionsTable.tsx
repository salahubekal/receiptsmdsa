import React, { useState } from 'react';
import {
  FileText,
  Eye,
  Download,
  Share2,
  CheckCircle,
  Clock,
  AlertCircle,
  ExternalLink,
  Edit2,
  Trash2,
  Search,
  Filter,
} from 'lucide-react';
import { Receipt, Settings } from '../types';
import { generateReceiptPdf } from '../utils/pdfGenerator';
import { generateReceiptImage } from '../utils/imageGenerator';

interface Props {
  receipts: Receipt[];
  settings: Partial<Settings>;
  onViewReceipt: (receipt: Receipt) => void;
  onShareWhatsApp: (receipt: Receipt) => void;
  onEditReceipt?: (receipt: Receipt) => void;
  onDeleteReceipt?: (id: number) => void;
}

export const RecentTransactionsTable: React.FC<Props> = ({
  receipts,
  settings,
  onViewReceipt,
  onShareWhatsApp,
  onEditReceipt,
  onDeleteReceipt,
}) => {
  const currency = settings.currency_symbol || '₹';
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [statusFilter, setStatusFilter] = useState<string>('All');
  const [exportingId, setExportingId] = useState<number | null>(null);

  const filtered = receipts.filter((r) => {
    const matchesSearch =
      r.receipt_number.toLowerCase().includes(searchTerm.toLowerCase()) ||
      r.customer_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      r.customer_phone.includes(searchTerm) ||
      r.description.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesStatus = statusFilter === 'All' || r.payment_status === statusFilter;

    return matchesSearch && matchesStatus;
  });

  const handleDownloadPdf = async (receipt: Receipt, e: React.MouseEvent) => {
    e.stopPropagation();
    setExportingId(receipt.id);
    try {
      // First preview or ensure element is ready
      onViewReceipt(receipt);
      setTimeout(async () => {
        await generateReceiptPdf('preview-receipt-container', receipt.receipt_number);
        setExportingId(null);
      }, 300);
    } catch (err) {
      console.error(err);
      setExportingId(null);
    }
  };

  return (
    <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
      {/* Table Header & Search Filter Bar */}
      <div className="p-4 sm:p-5 border-b border-slate-200 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 bg-slate-50/50">
        <div>
          <h3 className="font-bold text-slate-900 text-base">Recent Transactions</h3>
          <p className="text-xs text-slate-500">
            Showing latest digital receipts and real-time WhatsApp sharing statuses
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* Search box */}
          <div className="relative flex-1 sm:w-64">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search receipt, name, phone..."
              className="w-full pl-9 pr-3 py-1.5 rounded-lg border border-slate-300 text-xs font-medium focus:outline-none focus:ring-1 focus:ring-emerald-500"
            />
          </div>

          {/* Status filter */}
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="py-1.5 px-3 rounded-lg border border-slate-300 text-xs font-medium bg-white text-slate-700 focus:outline-none focus:ring-1 focus:ring-emerald-500"
          >
            <option value="All">All Statuses</option>
            <option value="Paid">Paid Only</option>
            <option value="Partially Paid">Partial Paid</option>
            <option value="Pending">Pending Only</option>
          </select>
        </div>
      </div>

      {/* Table Body */}
      <div className="overflow-x-auto">
        <table className="w-full text-left text-xs sm:text-sm">
          <thead>
            <tr className="bg-slate-50 text-slate-500 font-semibold border-b border-slate-200 text-xs uppercase tracking-wider">
              <th className="py-3 px-4">Receipt No</th>
              <th className="py-3 px-4">Customer</th>
              <th className="py-3 px-4">WhatsApp Phone</th>
              <th className="py-3 px-4 text-right">Amount</th>
              <th className="py-3 px-4">Date</th>
              <th className="py-3 px-4 text-center">Payment Status</th>
              <th className="py-3 px-4 text-center">WhatsApp Status</th>
              <th className="py-3 px-4 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {filtered.length === 0 ? (
              <tr>
                <td colSpan={8} className="py-12 text-center text-slate-400">
                  <FileText className="w-8 h-8 mx-auto mb-2 opacity-40" />
                  <p className="font-semibold text-sm">No receipts match your search filter</p>
                  <p className="text-xs text-slate-400 mt-1">Try clearing your filters or create a new receipt</p>
                </td>
              </tr>
            ) : (
              filtered.map((r) => {
                const isPaid = r.payment_status === 'Paid';
                const isPartial = r.payment_status === 'Partially Paid';

                const isShared = r.whatsapp_status && r.whatsapp_status !== 'Not Sent';

                return (
                  <tr
                    key={r.id}
                    className="hover:bg-slate-50/80 transition-colors cursor-pointer group"
                    onClick={() => onViewReceipt(r)}
                  >
                    {/* Receipt Number */}
                    <td className="py-3.5 px-4 font-mono font-bold text-slate-900 flex items-center gap-1.5">
                      <FileText className="w-4 h-4 text-emerald-600 flex-shrink-0" />
                      <span>{r.receipt_number}</span>
                    </td>

                    {/* Customer */}
                    <td className="py-3.5 px-4 font-semibold text-slate-800">
                      <div>{r.customer_name}</div>
                      {r.description && (
                        <div className="text-[11px] text-slate-400 font-normal truncate max-w-[180px]">
                          {r.description}
                        </div>
                      )}
                    </td>

                    {/* WhatsApp Phone */}
                    <td className="py-3.5 px-4 font-mono text-xs text-slate-600">
                      {r.customer_phone}
                    </td>

                    {/* Amount */}
                    <td className="py-3.5 px-4 text-right font-mono font-bold text-slate-900">
                      <div>
                        {currency} {Number(r.amount).toLocaleString()}
                      </div>
                      {isPartial && r.balance_amount > 0 && (
                        <div className="text-[10px] text-rose-600 font-medium">
                          Due: {currency} {Number(r.balance_amount).toLocaleString()}
                        </div>
                      )}
                    </td>

                    {/* Date */}
                    <td className="py-3.5 px-4 text-xs text-slate-500 whitespace-nowrap">
                      {r.receipt_date}
                    </td>

                    {/* Payment Status Badge */}
                    <td className="py-3.5 px-4 text-center">
                      <span
                        className={`inline-block px-2.5 py-0.5 rounded-full text-[11px] font-bold ${
                          isPaid
                            ? 'bg-emerald-100 text-emerald-800'
                            : isPartial
                            ? 'bg-amber-100 text-amber-800'
                            : 'bg-rose-100 text-rose-800'
                        }`}
                      >
                        {r.payment_status}
                      </span>
                    </td>

                    {/* WhatsApp Status Badge */}
                    <td className="py-3.5 px-4 text-center whitespace-nowrap">
                      <span
                        className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-medium ${
                          isShared
                            ? 'bg-teal-50 text-teal-700 border border-teal-200'
                            : 'bg-slate-100 text-slate-500'
                        }`}
                      >
                        {isShared ? (
                          <>
                            <CheckCircle className="w-3 h-3 text-teal-600" />
                            {r.whatsapp_status}
                          </>
                        ) : (
                          <>
                            <Clock className="w-3 h-3 text-slate-400" />
                            Not Sent
                          </>
                        )}
                      </span>
                    </td>

                    {/* Actions */}
                    <td className="py-3.5 px-4 text-right whitespace-nowrap">
                      <div
                        className="flex items-center justify-end gap-1.5"
                        onClick={(e) => e.stopPropagation()}
                      >
                        {/* View Action */}
                        <button
                          type="button"
                          onClick={() => onViewReceipt(r)}
                          className="p-1.5 rounded-lg text-slate-500 hover:text-slate-900 hover:bg-slate-100 transition-colors"
                          title="View / Print Receipt"
                        >
                          <Eye className="w-4 h-4" />
                        </button>

                        {/* WhatsApp Resend Action */}
                        <button
                          type="button"
                          onClick={() => onShareWhatsApp(r)}
                          className="p-1.5 rounded-lg text-emerald-600 hover:text-emerald-700 hover:bg-emerald-50 transition-colors"
                          title="Share / Resend on WhatsApp"
                        >
                          <Share2 className="w-4 h-4" />
                        </button>

                        {/* Edit Action */}
                        {onEditReceipt && (
                          <button
                            type="button"
                            onClick={() => onEditReceipt(r)}
                            className="p-1.5 rounded-lg text-blue-600 hover:text-blue-700 hover:bg-blue-50 transition-colors"
                            title="Edit Receipt Details"
                          >
                            <Edit2 className="w-4 h-4" />
                          </button>
                        )}

                        {/* Delete Action */}
                        {onDeleteReceipt && (
                          <button
                            type="button"
                            onClick={() => {
                              if (window.confirm(`Are you sure you want to delete receipt ${r.receipt_number}?`)) {
                                onDeleteReceipt(r.id);
                              }
                            }}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors"
                            title="Delete Receipt"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};


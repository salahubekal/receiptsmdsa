import React, { useState, useEffect } from 'react';
import {
  FileText,
  User,
  Phone,
  MapPin,
  Calendar,
  CreditCard,
  Hash,
  CheckCircle,
  Clock,
  Plus,
  Trash2,
  Eye,
  Save,
  Share2,
  RefreshCw,
  Search,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { Receipt, Customer, Settings, LineItem } from '../types';
import { COUNTRY_CODES } from '../utils/whatsappHelper';
import { numberToWords } from '../utils/numberToWords';

interface Props {
  settings: Partial<Settings>;
  onReceiptCreated: (receipt: Receipt) => void;
  onPreviewRequested: (receipt: Partial<Receipt>) => void;
  onShareRequested: (receipt: Receipt) => void;
  initialCustomer?: Customer | null;
}

export const ReceiptForm: React.FC<Props> = ({
  settings,
  onReceiptCreated,
  onPreviewRequested,
  onShareRequested,
  initialCustomer,
}) => {
  const currency = settings.currency_symbol || '₹';

  // Receipt details state
  const [receiptNumber, setReceiptNumber] = useState<string>('');
  const [receiptDate, setReceiptDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [customerName, setCustomerName] = useState<string>('');
  const [countryCode, setCountryCode] = useState<string>('+91');
  const [phoneDigits, setPhoneDigits] = useState<string>('');
  const [customerAddress, setCustomerAddress] = useState<string>('');
  const [description, setDescription] = useState<string>('');
  const [paymentMethod, setPaymentMethod] = useState<string>('Cash');
  const [transactionId, setTransactionId] = useState<string>('');
  const [paymentStatus, setPaymentStatus] = useState<'Paid' | 'Partially Paid' | 'Pending'>('Paid');
  const [amount, setAmount] = useState<string>('0');
  const [paidAmount, setPaidAmount] = useState<string>('0');
  const [balanceAmount, setBalanceAmount] = useState<string>('0');
  const [remarks, setRemarks] = useState<string>('');

  // Line items state
  const [lineItems, setLineItems] = useState<LineItem[]>([
    { description: '', quantity: 1, rate: 0, amount: 0 },
  ]);
  const [useItemized, setUseItemized] = useState<boolean>(false);

  // Customer search & autocomplete
  const [existingCustomers, setExistingCustomers] = useState<Customer[]>([]);
  const [customerSearchQuery, setCustomerSearchQuery] = useState<string>('');
  const [isCustomerDropdownOpen, setIsCustomerDropdownOpen] = useState<boolean>(false);
  const [selectedCustomerId, setSelectedCustomerId] = useState<number | null>(null);

  // UI state
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successReceipt, setSuccessReceipt] = useState<Receipt | null>(null);

  // Fetch next receipt number and customers on mount
  const fetchNextNumber = async () => {
    try {
      const res = await fetch('/api/receipts/next-number');
      const data = await res.json();
      if (data.nextNumber) setReceiptNumber(data.nextNumber);
    } catch (err) {
      console.error('Error fetching next number:', err);
    }
  };

  const fetchCustomers = async () => {
    try {
      const res = await fetch('/api/customers');
      const data = await res.json();
      if (Array.isArray(data)) setExistingCustomers(data);
    } catch (err) {
      console.error('Error fetching customers:', err);
    }
  };

  useEffect(() => {
    fetchNextNumber();
    fetchCustomers();
  }, []);

  // Pre-fill if initial customer is passed
  useEffect(() => {
    if (initialCustomer) {
      setCustomerName(initialCustomer.name);
      setCustomerAddress(initialCustomer.address || '');
      setSelectedCustomerId(initialCustomer.id);

      // parse phone
      const phone = initialCustomer.phone || '';
      for (const c of COUNTRY_CODES) {
        if (phone.startsWith(c.code)) {
          setCountryCode(c.code);
          setPhoneDigits(phone.replace(c.code, '').trim());
          return;
        }
      }
      setPhoneDigits(phone.replace(/[^0-9]/g, ''));
    }
  }, [initialCustomer]);

  // Recalculate amount if itemized lines change
  useEffect(() => {
    if (useItemized) {
      const sum = lineItems.reduce((acc, it) => acc + (Number(it.amount) || 0), 0);
      setAmount(sum.toString());
    }
  }, [lineItems, useItemized]);

  // Update paid and balance amount based on status & total amount
  useEffect(() => {
    const total = parseFloat(amount) || 0;
    if (paymentStatus === 'Paid') {
      setPaidAmount(total.toString());
      setBalanceAmount('0');
    } else if (paymentStatus === 'Pending') {
      setPaidAmount('0');
      setBalanceAmount(total.toString());
    } else if (paymentStatus === 'Partially Paid') {
      const paid = parseFloat(paidAmount) || 0;
      setBalanceAmount(Math.max(0, total - paid).toString());
    }
  }, [amount, paymentStatus]);

  // Handle line item update
  const updateLineItem = (index: number, field: keyof LineItem, val: any) => {
    const updated = [...lineItems];
    const item = { ...updated[index], [field]: val };

    if (field === 'quantity' || field === 'rate') {
      const q = parseFloat(field === 'quantity' ? val : item.quantity) || 0;
      const r = parseFloat(field === 'rate' ? val : item.rate) || 0;
      item.amount = q * r;
    }

    updated[index] = item;
    setLineItems(updated);
  };

  const addLineItem = () => {
    setLineItems([...lineItems, { description: '', quantity: 1, rate: 0, amount: 0 }]);
  };

  const removeLineItem = (index: number) => {
    if (lineItems.length > 1) {
      setLineItems(lineItems.filter((_, idx) => idx !== index));
    }
  };

  // Select customer from autocomplete
  const selectCustomer = (cust: Customer) => {
    setCustomerName(cust.name);
    setCustomerAddress(cust.address || '');
    setSelectedCustomerId(cust.id);

    const phone = cust.phone || '';
    let matched = false;
    for (const c of COUNTRY_CODES) {
      if (phone.startsWith(c.code)) {
        setCountryCode(c.code);
        setPhoneDigits(phone.replace(c.code, '').trim());
        matched = true;
        break;
      }
    }
    if (!matched) {
      setPhoneDigits(phone.replace(/[^0-9]/g, ''));
    }

    setIsCustomerDropdownOpen(false);
  };

  // Build current receipt object for preview or submission
  const getCurrentReceiptObject = (): Partial<Receipt> => {
    const fullPhone = `${countryCode} ${phoneDigits}`.trim();
    const finalAmount = parseFloat(amount) || 0;
    const finalPaid = parseFloat(paidAmount) || 0;
    const finalBalance = parseFloat(balanceAmount) || 0;

    let itemsToSave = lineItems;
    if (!useItemized) {
      itemsToSave = [
        {
          description: description.trim() || 'Payment Received',
          quantity: 1,
          rate: finalAmount,
          amount: finalAmount,
        },
      ];
    }

    return {
      receipt_number: receiptNumber.trim(),
      receipt_date: receiptDate,
      customer_id: selectedCustomerId,
      customer_name: customerName.trim(),
      customer_phone: fullPhone,
      customer_address: customerAddress.trim(),
      description: description.trim() || (lineItems[0]?.description || 'Payment Received'),
      amount: finalAmount,
      payment_method: paymentMethod,
      transaction_id: transactionId.trim(),
      payment_status: paymentStatus,
      paid_amount: finalPaid,
      balance_amount: finalBalance,
      remarks: remarks.trim(),
      items_json: JSON.stringify(itemsToSave),
      whatsapp_status: 'Not Sent',
    };
  };

  // Trigger visual preview modal
  const handlePreview = () => {
    onPreviewRequested(getCurrentReceiptObject());
  };

  // Submit & create receipt in database
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (!customerName.trim()) {
      setErrorMessage('Please enter Customer / Person Name.');
      return;
    }
    if (!phoneDigits.trim()) {
      setErrorMessage('Please enter a WhatsApp Phone Number.');
      return;
    }
    const finalAmount = parseFloat(amount) || 0;
    if (finalAmount <= 0) {
      setErrorMessage('Please enter a valid payment amount greater than zero.');
      return;
    }

    setIsSubmitting(true);
    const payload = getCurrentReceiptObject();

    try {
      const res = await fetch('/api/receipts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to save receipt');
      }

      // Success! Trigger celebratory confetti
      confetti({
        particleCount: 80,
        spread: 60,
        origin: { y: 0.7 },
      });

      setSuccessReceipt(data);
      onReceiptCreated(data);

      // Refresh customers
      fetchCustomers();
    } catch (err: any) {
      setErrorMessage(err.message || 'Error occurred while saving receipt');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Start a fresh new receipt
  const handleCreateAnother = () => {
    setSuccessReceipt(null);
    setCustomerName('');
    setPhoneDigits('');
    setCustomerAddress('');
    setDescription('');
    setTransactionId('');
    setAmount('0');
    setPaidAmount('0');
    setBalanceAmount('0');
    setRemarks('');
    setSelectedCustomerId(null);
    setLineItems([{ description: '', quantity: 1, rate: 0, amount: 0 }]);
    fetchNextNumber();
  };

  const amountInWords = numberToWords(
    parseFloat(amount) || 0,
    settings.currency_code === 'USD' ? 'Dollars' : 'Rupees'
  );

  return (
    <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
      {/* Form Header */}
      <div className="bg-gradient-to-r from-emerald-600 to-teal-700 text-white p-5 sm:p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-white/15 flex items-center justify-center text-white backdrop-blur-sm shadow-inner">
            <FileText className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-lg sm:text-xl font-bold tracking-tight">Create Digital Receipt</h2>
            <p className="text-xs sm:text-sm text-emerald-100">
              Generate paperless receipt, download PDF/PNG, and send to WhatsApp
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={fetchNextNumber}
          className="self-start sm:self-auto px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-xs font-semibold text-white flex items-center gap-1.5 transition-colors border border-white/20"
          title="Regenerate Receipt Number"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          Regenerate No.
        </button>
      </div>

      {/* Success Notification Banner */}
      {successReceipt && (
        <div className="m-5 p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-900 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 animate-fadeIn">
          <div className="flex items-center gap-3">
            <CheckCircle className="w-6 h-6 text-emerald-600 flex-shrink-0" />
            <div>
              <h4 className="font-bold text-sm">Receipt {successReceipt.receipt_number} Created Successfully!</h4>
              <p className="text-xs text-emerald-700">
                Amount: {currency} {Number(successReceipt.amount).toLocaleString()} for {successReceipt.customer_name}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2 w-full sm:w-auto">
            <button
              type="button"
              onClick={() => onShareRequested(successReceipt)}
              className="flex-1 sm:flex-initial px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-lg shadow flex items-center justify-center gap-1.5 transition-all"
            >
              <Share2 className="w-4 h-4" />
              Share on WhatsApp
            </button>
            <button
              type="button"
              onClick={handleCreateAnother}
              className="flex-1 sm:flex-initial px-3 py-2 bg-white border border-emerald-300 text-emerald-800 text-xs font-semibold rounded-lg hover:bg-emerald-100/50 transition-colors"
            >
              + Create Another
            </button>
          </div>
        </div>
      )}

      {/* Error Banner */}
      {errorMessage && (
        <div className="mx-5 mt-5 p-3.5 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs font-medium flex items-center gap-2">
          <span className="font-bold text-sm">⚠️</span>
          <span>{errorMessage}</span>
        </div>
      )}

      {/* Main Receipt Form */}
      <form onSubmit={handleSubmit} className="p-5 sm:p-7 space-y-6">
        {/* ROW 1: Receipt Number & Date */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">
              Receipt Number <span className="text-rose-500">*</span>
            </label>
            <div className="relative">
              <Hash className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
              <input
                type="text"
                required
                value={receiptNumber}
                onChange={(e) => setReceiptNumber(e.target.value)}
                placeholder="e.g. REC-2026-1001"
                className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-300 font-mono font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500/30 focus:border-emerald-500 text-sm bg-slate-50/50"
              />
            </div>
            <span className="text-[11px] text-slate-400 mt-1 block">
              Auto-generated sequentially, editable if needed
            </span>
          </div>

          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">
              Receipt Date <span className="text-rose-500">*</span>
            </label>
            <div className="relative">
              <Calendar className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
              <input
                type="date"
                required
                value={receiptDate}
                onChange={(e) => setReceiptDate(e.target.value)}
                className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-300 font-medium text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500/30 focus:border-emerald-500 text-sm"
              />
            </div>
          </div>
        </div>

        {/* ROW 2: Customer Name with Autocomplete & WhatsApp Number */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {/* Customer Name */}
          <div className="relative">
            <div className="flex items-center justify-between mb-1.5">
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-700">
                Customer / Person Name <span className="text-rose-500">*</span>
              </label>
              {existingCustomers.length > 0 && (
                <button
                  type="button"
                  onClick={() => setIsCustomerDropdownOpen(!isCustomerDropdownOpen)}
                  className="text-[11px] text-emerald-600 hover:text-emerald-700 font-semibold flex items-center gap-1"
                >
                  <Search className="w-3 h-3" /> Select Existing ({existingCustomers.length})
                </button>
              )}
            </div>
            <div className="relative">
              <User className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
              <input
                type="text"
                required
                value={customerName}
                onChange={(e) => {
                  setCustomerName(e.target.value);
                  setCustomerSearchQuery(e.target.value);
                  setIsCustomerDropdownOpen(true);
                }}
                onFocus={() => setIsCustomerDropdownOpen(true)}
                placeholder="e.g. Mohammed Rizwan"
                className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-300 font-medium text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500/30 focus:border-emerald-500 text-sm"
              />
            </div>

            {/* Autocomplete Dropdown */}
            {isCustomerDropdownOpen && existingCustomers.length > 0 && (
              <div className="absolute z-20 left-0 right-0 mt-1 bg-white border border-slate-200 rounded-xl shadow-xl max-h-48 overflow-y-auto">
                <div className="p-2 border-b border-slate-100 flex items-center justify-between text-[11px] text-slate-400 font-semibold px-3">
                  <span>Saved Customers</span>
                  <button
                    type="button"
                    onClick={() => setIsCustomerDropdownOpen(false)}
                    className="hover:text-slate-600"
                  >
                    Close ✕
                  </button>
                </div>
                {existingCustomers
                  .filter((c) =>
                    c.name.toLowerCase().includes(customerName.toLowerCase()) ||
                    c.phone.includes(customerName)
                  )
                  .map((c) => (
                    <button
                      key={c.id}
                      type="button"
                      onClick={() => selectCustomer(c)}
                      className="w-full text-left px-3.5 py-2 hover:bg-emerald-50 flex items-center justify-between text-xs transition-colors border-b border-slate-50 last:border-b-0"
                    >
                      <div>
                        <span className="font-bold text-slate-800 block">{c.name}</span>
                        <span className="text-[11px] text-slate-500 font-mono">{c.phone}</span>
                      </div>
                      <span className="text-[10px] bg-slate-100 px-2 py-0.5 rounded text-slate-600">
                        {c.total_receipts || 0} receipts
                      </span>
                    </button>
                  ))}
              </div>
            )}
          </div>

          {/* WhatsApp Phone with Country Code */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">
              WhatsApp Number <span className="text-rose-500">*</span>
            </label>
            <div className="flex gap-2">
              <select
                value={countryCode}
                onChange={(e) => setCountryCode(e.target.value)}
                className="w-28 py-2.5 px-2 rounded-xl border border-slate-300 text-xs font-semibold text-slate-800 bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/30 focus:border-emerald-500"
              >
                {COUNTRY_CODES.map((c) => (
                  <option key={c.code} value={c.code}>
                    {c.code} {c.country}
                  </option>
                ))}
              </select>

              <div className="relative flex-1">
                <Phone className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
                <input
                  type="tel"
                  required
                  value={phoneDigits}
                  onChange={(e) => setPhoneDigits(e.target.value)}
                  placeholder="e.g. 98470 12345"
                  className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-300 font-mono font-medium text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500/30 focus:border-emerald-500 text-sm"
                />
              </div>
            </div>
            <span className="text-[11px] text-slate-400 mt-1 block">
              Used directly for 1-click WhatsApp receipt dispatch
            </span>
          </div>
        </div>

        {/* ROW 3: Customer Address (Optional) */}
        <div>
          <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">
            Customer Address / Location <span className="text-slate-400 text-[11px] font-normal">(Optional)</span>
          </label>
          <div className="relative">
            <MapPin className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
            <input
              type="text"
              value={customerAddress}
              onChange={(e) => setCustomerAddress(e.target.value)}
              placeholder="e.g. Door No. 14/220, South Bazar, Kozhikode"
              className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-300 font-medium text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500/30 focus:border-emerald-500 text-sm"
            />
          </div>
        </div>

        {/* ROW 4: Description / Line Items Toggle */}
        <div className="border border-slate-200 rounded-xl p-4 bg-slate-50/50">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-700">
              Receipt Purpose / Description <span className="text-rose-500">*</span>
            </span>
            <button
              type="button"
              onClick={() => setUseItemized(!useItemized)}
              className="text-xs font-semibold text-emerald-600 hover:text-emerald-700 flex items-center gap-1"
            >
              {useItemized ? '← Switch to Simple Description' : '+ Use Detailed Itemized Table'}
            </button>
          </div>

          {!useItemized ? (
            <div>
              <textarea
                rows={2}
                required={!useItemized}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="e.g. Annual maintenance & system licensing fee for Q1-Q2"
                className="w-full p-3 rounded-xl border border-slate-300 bg-white font-medium text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500/30 focus:border-emerald-500 text-sm"
              />
            </div>
          ) : (
            <div className="space-y-3">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead>
                    <tr className="text-slate-500 uppercase tracking-wider border-b border-slate-200">
                      <th className="py-1.5 px-2">Item Description</th>
                      <th className="py-1.5 px-2 w-16 text-center">Qty</th>
                      <th className="py-1.5 px-2 w-24 text-right">Rate ({currency})</th>
                      <th className="py-1.5 px-2 w-28 text-right">Total ({currency})</th>
                      <th className="py-1.5 px-2 w-10"></th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {lineItems.map((item, idx) => (
                      <tr key={idx}>
                        <td className="py-1.5 px-2">
                          <input
                            type="text"
                            required
                            value={item.description}
                            onChange={(e) => updateLineItem(idx, 'description', e.target.value)}
                            placeholder="Item description or service"
                            className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 text-xs focus:outline-none focus:ring-1 focus:ring-emerald-500"
                          />
                        </td>
                        <td className="py-1.5 px-2 text-center">
                          <input
                            type="number"
                            min="1"
                            value={item.quantity}
                            onChange={(e) => updateLineItem(idx, 'quantity', e.target.value)}
                            className="w-14 text-center px-1.5 py-1.5 rounded-lg border border-slate-300 text-xs font-mono focus:outline-none focus:ring-1 focus:ring-emerald-500"
                          />
                        </td>
                        <td className="py-1.5 px-2 text-right">
                          <input
                            type="number"
                            min="0"
                            step="any"
                            value={item.rate}
                            onChange={(e) => updateLineItem(idx, 'rate', e.target.value)}
                            className="w-24 text-right px-2 py-1.5 rounded-lg border border-slate-300 text-xs font-mono focus:outline-none focus:ring-1 focus:ring-emerald-500"
                          />
                        </td>
                        <td className="py-1.5 px-2 text-right font-mono font-bold text-slate-800">
                          {currency} {Number(item.amount || 0).toLocaleString()}
                        </td>
                        <td className="py-1.5 px-2 text-center">
                          {lineItems.length > 1 && (
                            <button
                              type="button"
                              onClick={() => removeLineItem(idx)}
                              className="text-slate-400 hover:text-rose-500"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              <button
                type="button"
                onClick={addLineItem}
                className="text-xs font-bold text-emerald-600 hover:text-emerald-700 flex items-center gap-1 mt-2"
              >
                <Plus className="w-3.5 h-3.5" /> Add Another Item
              </button>
            </div>
          )}
        </div>

        {/* ROW 5: Amount and Words */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 items-start">
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">
              Total Payment Amount ({currency}) <span className="text-rose-500">*</span>
            </label>
            <div className="relative">
              <span className="text-base font-bold text-slate-400 absolute left-3.5 top-2.5">
                {currency}
              </span>
              <input
                type="number"
                min="0.01"
                step="any"
                required
                readOnly={useItemized}
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className={`w-full pl-9 pr-4 py-2.5 rounded-xl border border-slate-300 font-mono font-bold text-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500/30 focus:border-emerald-500 ${
                  useItemized ? 'bg-slate-100 cursor-not-allowed' : 'bg-white'
                }`}
              />
            </div>
          </div>

          {/* Amount in English words live conversion */}
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-3">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-0.5">
              Amount in Words
            </span>
            <div className="text-xs sm:text-sm font-serif italic text-emerald-900 font-semibold leading-relaxed">
              "{amountInWords}"
            </div>
          </div>
        </div>

        {/* ROW 6: Payment Method & Transaction ID */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">
              Payment Method <span className="text-rose-500">*</span>
            </label>
            <div className="relative">
              <CreditCard className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
              <select
                value={paymentMethod}
                onChange={(e) => setPaymentMethod(e.target.value)}
                className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-300 font-medium text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500/30 focus:border-emerald-500 text-sm bg-white"
              >
                <option value="Cash">Cash 💵</option>
                <option value="UPI">UPI / GPay / PhonePe / Paytm 📱</option>
                <option value="Bank Transfer">Bank Transfer / NEFT / IMPS 🏦</option>
                <option value="Cheque">Cheque 📝</option>
                <option value="Card">Credit / Debit Card 💳</option>
                <option value="Other">Other</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">
              Transaction ID / Ref <span className="text-slate-400 text-[11px] font-normal">(Optional)</span>
            </label>
            <input
              type="text"
              value={transactionId}
              onChange={(e) => setTransactionId(e.target.value)}
              placeholder="e.g. UPI/261109012398/ICICI or Cheque #98210"
              className="w-full px-4 py-2.5 rounded-xl border border-slate-300 font-mono font-medium text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500/30 focus:border-emerald-500 text-sm"
            />
          </div>
        </div>

        {/* ROW 7: Payment Status & Partial Payments */}
        <div className="border border-slate-200 rounded-xl p-4 bg-slate-50/50 space-y-3">
          <label className="block text-xs font-bold uppercase tracking-wider text-slate-700">
            Payment Status
          </label>
          <div className="grid grid-cols-3 gap-3">
            {[
              { id: 'Paid', label: 'Paid Full', icon: CheckCircle, color: 'emerald' },
              { id: 'Partially Paid', label: 'Partial Paid', icon: Clock, color: 'amber' },
              { id: 'Pending', label: 'Pending', icon: RefreshCw, color: 'rose' },
            ].map((st) => (
              <button
                key={st.id}
                type="button"
                onClick={() => setPaymentStatus(st.id as any)}
                className={`py-2.5 px-3 rounded-xl border text-xs font-bold flex items-center justify-center gap-2 transition-all ${
                  paymentStatus === st.id
                    ? st.id === 'Paid'
                      ? 'bg-emerald-600 text-white border-emerald-600 shadow-sm'
                      : st.id === 'Partially Paid'
                      ? 'bg-amber-600 text-white border-amber-600 shadow-sm'
                      : 'bg-rose-600 text-white border-rose-600 shadow-sm'
                    : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-100'
                }`}
              >
                <st.icon className="w-4 h-4" />
                {st.label}
              </button>
            ))}
          </div>

          {/* If Partially Paid: Paid Amount and Balance Due */}
          {paymentStatus === 'Partially Paid' && (
            <div className="grid grid-cols-2 gap-4 pt-2 border-t border-slate-200 animate-fadeIn">
              <div>
                <label className="text-xs font-bold text-slate-600 block mb-1">
                  Amount Received Now ({currency})
                </label>
                <input
                  type="number"
                  min="0"
                  step="any"
                  value={paidAmount}
                  onChange={(e) => {
                    setPaidAmount(e.target.value);
                    const total = parseFloat(amount) || 0;
                    const paid = parseFloat(e.target.value) || 0;
                    setBalanceAmount(Math.max(0, total - paid).toString());
                  }}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 font-mono text-sm focus:outline-none focus:ring-1 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-rose-600 block mb-1">
                  Remaining Balance Due ({currency})
                </label>
                <input
                  type="number"
                  readOnly
                  value={balanceAmount}
                  className="w-full px-3 py-2 rounded-lg border border-rose-200 bg-rose-50/50 font-mono font-bold text-sm text-rose-700"
                />
              </div>
            </div>
          )}
        </div>

        {/* ROW 8: Remarks / Additional Details */}
        <div>
          <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">
            Additional Details / Remarks <span className="text-slate-400 text-[11px] font-normal">(Optional)</span>
          </label>
          <input
            type="text"
            value={remarks}
            onChange={(e) => setRemarks(e.target.value)}
            placeholder="e.g. 1 year warranty included. Next balance payment due on 15th."
            className="w-full px-4 py-2.5 rounded-xl border border-slate-300 font-medium text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500/30 focus:border-emerald-500 text-sm"
          />
        </div>

        {/* ACTION BUTTONS */}
        <div className="pt-4 border-t border-slate-200 flex flex-wrap items-center justify-end gap-3">
          {/* Preview Button */}
          <button
            type="button"
            onClick={handlePreview}
            className="px-5 py-3 rounded-xl border border-slate-300 bg-white hover:bg-slate-50 text-slate-800 text-xs sm:text-sm font-bold flex items-center gap-2 shadow-sm transition-all"
          >
            <Eye className="w-4 h-4 text-slate-600" />
            Preview Receipt
          </button>

          {/* Save / Generate Receipt Button */}
          <button
            type="submit"
            disabled={isSubmitting}
            className="px-6 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 active:scale-[0.99] text-white text-xs sm:text-sm font-bold flex items-center gap-2 shadow-md shadow-emerald-600/20 transition-all disabled:opacity-50"
          >
            <Save className="w-4 h-4" />
            {isSubmitting ? 'Saving Receipt...' : 'Save & Generate Receipt'}
          </button>
        </div>
      </form>
    </div>
  );
};


import html2canvas from 'html2canvas';

/**
 * Generates and downloads a PNG or JPG from a DOM element
 */
export async function generateReceiptImage(
  elementId: string,
  receiptNumber: string,
  format: 'png' | 'jpeg' = 'png'
): Promise<File> {
  const element = document.getElementById(elementId);
  if (!element) {
    throw new Error(`Element with id "${elementId}" not found`);
  }

  const canvas = await html2canvas(element, {
    scale: 2, // 2x retina crisp quality
    useCORS: true,
    logging: false,
    backgroundColor: '#ffffff',
  });

  const mimeType = format === 'jpeg' ? 'image/jpeg' : 'image/png';
  const extension = format === 'jpeg' ? 'jpg' : 'png';
  const filename = `${receiptNumber}.${extension}`;

  return new Promise((resolve, reject) => {
    canvas.toBlob((blob) => {
      if (!blob) {
        return reject(new Error('Failed to convert canvas to image blob'));
      }

      const file = new File([blob], filename, { type: mimeType });

      // Trigger browser download
      const link = document.createElement('a');
      link.href = URL.createObjectURL(blob);
      link.download = filename;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(link.href);

      resolve(file);
    }, mimeType, 0.95);
  });
}

/**
 * Returns a File without triggering automatic download (useful for Web Share API)
 */
export async function getReceiptImageFile(
  elementId: string,
  receiptNumber: string
): Promise<File> {
  const element = document.getElementById(elementId);
  if (!element) {
    throw new Error(`Element with id "${elementId}" not found`);
  }

  const canvas = await html2canvas(element, {
    scale: 2,
    useCORS: true,
    logging: false,
    backgroundColor: '#ffffff',
  });

  return new Promise((resolve, reject) => {
    canvas.toBlob((blob) => {
      if (!blob) {
        return reject(new Error('Failed to convert canvas to image blob'));
      }
      const file = new File([blob], `${receiptNumber}.png`, { type: 'image/png' });
      resolve(file);
    }, 'image/png', 0.95);
  });
}


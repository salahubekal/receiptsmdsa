import { Router } from 'express';
import { db } from '../db/index.js';

const router = Router();

// GET /api/customers - List all customers with search and computed metrics
router.get('/', (req, res) => {
  const search = req.query.search ? `%${req.query.search}%` : '%';

  const query = `
    SELECT 
      c.*,
      COUNT(r.id) as total_receipts,
      COALESCE(SUM(r.paid_amount), 0) as total_paid,
      COALESCE(SUM(r.balance_amount), 0) as total_balance
    FROM customers c
    LEFT JOIN receipts r ON c.id = r.customer_id
    WHERE c.name LIKE ? OR c.phone LIKE ? OR c.email LIKE ? OR c.address LIKE ?
    GROUP BY c.id
    ORDER BY c.name ASC
  `;

  try {
    const customers = db.prepare(query).all(search, search, search, search);
    res.json(customers);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/customers/:id - Single customer with all receipts
router.get('/:id', (req, res) => {
  const { id } = req.params;

  try {
    const customer = db.prepare(`
      SELECT 
        c.*,
        COUNT(r.id) as total_receipts,
        COALESCE(SUM(r.paid_amount), 0) as total_paid,
        COALESCE(SUM(r.balance_amount), 0) as total_balance
      FROM customers c
      LEFT JOIN receipts r ON c.id = r.customer_id
      WHERE c.id = ?
      GROUP BY c.id
    `).get(id);

    if (!customer) {
      return res.status(404).json({ error: 'Customer not found' });
    }

    const receipts = db.prepare(`
      SELECT * FROM receipts 
      WHERE customer_id = ? 
      ORDER BY receipt_date DESC, id DESC
    `).all(id);

    res.json({ customer, receipts });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/customers - Create customer
router.post('/', (req, res) => {
  const { name, phone, email = '', address = '', notes = '' } = req.body;

  if (!name || !phone) {
    return res.status(400).json({ error: 'Customer name and phone number are required' });
  }

  // Normalize phone string
  const cleanPhone = phone.trim();

  try {
    // Check if phone already exists
    const existing = db.prepare('SELECT id FROM customers WHERE phone = ?').get(cleanPhone);
    if (existing) {
      return res.status(400).json({ error: 'A customer with this phone number already exists' });
    }

    const result = db.prepare(`
      INSERT INTO customers (name, phone, email, address, notes, updated_at)
      VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
    `).run(name.trim(), cleanPhone, email.trim(), address.trim(), notes.trim());

    const newCustomer = db.prepare('SELECT * FROM customers WHERE id = ?').get(result.lastInsertRowid);
    res.status(201).json(newCustomer);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// PUT /api/customers/:id - Update customer
router.put('/:id', (req, res) => {
  const { id } = req.params;
  const { name, phone, email = '', address = '', notes = '' } = req.body;

  if (!name || !phone) {
    return res.status(400).json({ error: 'Customer name and phone number are required' });
  }

  const cleanPhone = phone.trim();

  try {
    // Check if another customer uses this phone
    const existing = db.prepare('SELECT id FROM customers WHERE phone = ? AND id != ?').get(cleanPhone, id);
    if (existing) {
      return res.status(400).json({ error: 'Another customer is already registered with this phone number' });
    }

    db.prepare(`
      UPDATE customers 
      SET name = ?, phone = ?, email = ?, address = ?, notes = ?, updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `).run(name.trim(), cleanPhone, email.trim(), address.trim(), notes.trim(), id);

    // Also update customer name / phone / address on previous receipts for consistency
    db.prepare(`
      UPDATE receipts 
      SET customer_name = ?, customer_phone = ?, customer_address = ?
      WHERE customer_id = ?
    `).run(name.trim(), cleanPhone, address.trim(), id);

    const updated = db.prepare('SELECT * FROM customers WHERE id = ?').get(id);
    res.json(updated);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// DELETE /api/customers/:id
router.delete('/:id', (req, res) => {
  const { id } = req.params;

  try {
    // Unlink receipts first (ON DELETE SET NULL handles this, but explicit is safer)
    db.prepare('UPDATE receipts SET customer_id = NULL WHERE customer_id = ?').run(id);
    db.prepare('DELETE FROM customers WHERE id = ?').run(id);

    res.json({ success: true, message: 'Customer removed successfully' });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

export default router;


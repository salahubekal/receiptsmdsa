import { Router } from 'express';
import { db } from '../db/index.js';

const router = Router();

// POST /api/whatsapp/send-cloud - Official WhatsApp Business Cloud API integration
router.post('/send-cloud', async (req, res) => {
  const { receiptId, phoneNumber, messageText, mediaUrl } = req.body;

  if (!phoneNumber || !messageText) {
    return res.status(400).json({ error: 'Recipient phone number and message are required' });
  }

  // Fetch Cloud API settings from database
  const phoneIdRow = db.prepare("SELECT value FROM settings WHERE key = 'whatsapp_cloud_api_phone_id'").get() as any;
  const tokenRow = db.prepare("SELECT value FROM settings WHERE key = 'whatsapp_cloud_api_token'").get() as any;

  const phoneId = phoneIdRow?.value;
  const accessToken = tokenRow?.value;

  if (!phoneId || !accessToken) {
    return res.status(400).json({
      error: 'WhatsApp Business Cloud API is not configured. Please add your Phone Number ID and System User Access Token in Settings -> WhatsApp Cloud API, or use the direct WhatsApp Click-to-Chat option.',
      notConfigured: true,
    });
  }

  // Clean phone number (strip spaces, symbols, plus sign)
  const cleanToPhone = phoneNumber.replace(/[^0-9]/g, '');

  try {
    const payload: any = {
      messaging_product: 'whatsapp',
      recipient_type: 'individual',
      to: cleanToPhone,
      type: 'text',
      text: { body: messageText },
    };

    const response = await fetch(`https://graph.facebook.com/v18.0/${phoneId}/messages`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(payload),
    });

    const data = await response.json() as any;

    if (!response.ok) {
      return res.status(400).json({
        error: data.error?.message || 'Failed to dispatch via WhatsApp Cloud API',
        details: data,
      });
    }

    // Delivery accepted by Meta Cloud API
    const messageId = data.messages?.[0]?.id;

    if (receiptId) {
      const now = new Date().toISOString();
      db.prepare(`
        UPDATE receipts 
        SET whatsapp_status = 'Sent via Cloud API', whatsapp_sent_at = ?, updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
      `).run(now, receiptId);

      db.prepare(`
        INSERT INTO receipt_audit_logs (receipt_id, receipt_number, action, changed_fields, performed_by)
        SELECT id, receipt_number, 'WHATSAPP_SENT_CLOUD', ?, 'Admin'
        FROM receipts WHERE id = ?
      `).run(`Dispatched via WhatsApp Cloud API (Message ID: ${messageId})`, receiptId);
    }

    res.json({
      success: true,
      messageId,
      status: 'Delivered to Meta API Gateway',
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/whatsapp/log-share - Log manual or Web WhatsApp share
router.post('/log-share', (req, res) => {
  const { receiptId, method = 'Click-to-Chat', details = '' } = req.body;

  if (!receiptId) {
    return res.status(400).json({ error: 'Receipt ID required' });
  }

  try {
    const receipt = db.prepare('SELECT id, receipt_number FROM receipts WHERE id = ?').get(receiptId) as any;
    if (!receipt) {
      return res.status(404).json({ error: 'Receipt not found' });
    }

    const now = new Date().toISOString();
    const statusText = `Shared via ${method}`;

    db.prepare(`
      UPDATE receipts 
      SET whatsapp_status = ?, whatsapp_sent_at = ?, updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `).run(statusText, now, receiptId);

    db.prepare(`
      INSERT INTO receipt_audit_logs (receipt_id, receipt_number, action, changed_fields, performed_by)
      VALUES (?, ?, 'WHATSAPP_SHARED_MANUAL', ?, 'Admin')
    `).run(
      receipt.id,
      receipt.receipt_number,
      `User shared receipt via WhatsApp ${method} at ${now}. Note: Manual sharing does not confirm customer delivery.`
    );

    res.json({ success: true, status: statusText, timestamp: now });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

export default router;


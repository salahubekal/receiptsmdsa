import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  User,
  Lock,
  Eye,
  EyeOff,
  Send,
  Settings,
  GraduationCap,
  FileText,
  TrendingUp,
  CheckCircle2,
  ShieldCheck,
  AlertCircle,
  Mail,
  Shield,
  ShieldAlert,
} from 'lucide-react';
import { MDSA3DCanvas } from './MDSA3DCanvas';
import { useAuth } from '../context/AuthContext';

interface Props {
  onLoginSuccess: (role: 'admin' | 'student') => void;
}

export const MDSALoginPage: React.FC<Props> = ({ onLoginSuccess }) => {
  const { login } = useAuth();

  const [portalType, setPortalType] = useState<'admin' | 'student'>('admin');
  const [username, setUsername] = useState<string>('');
  const [password, setPassword] = useState<string>('');
  const [showPassword, setShowPassword] = useState<boolean>(false);
  const [rememberMe, setRememberMe] = useState<boolean>(true);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Switch role tabs
  const handleTabSwitch = (type: 'admin' | 'student') => {
    setPortalType(type);
    setErrorMessage(null);
    setUsername('');
    setPassword('');
  };

  // Submit login
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (!username.trim() || !password.trim()) {
      setErrorMessage('Please enter your credentials to log in.');
      return;
    }

    setIsLoading(true);

    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          username: username.trim(),
          password: password.trim(),
          portalType,
        }),
      });

      let data: any = {};
      try {
        data = await res.json();
      } catch (e) {
        throw new Error('Connection timeout or proxy glitch. Please retry.');
      }

      if (!res.ok) {
        throw new Error(data.error || 'Authentication failed. Please verify credentials.');
      }

      login(data.token, data.user);
      onLoginSuccess(data.user.role as 'admin' | 'student');
    } catch (err: any) {
      setErrorMessage(err.message || 'Login failed. Please check your credentials.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="relative min-h-screen w-full bg-[#EFF4FE] overflow-hidden flex flex-col justify-between font-sans selection:bg-purple-200 selection:text-purple-900">
      {/* 1. FUTURISTIC 3D BACKGROUND GRADIENT WAVES & ISLAMIC GEOMETRIC ACCENTS */}
      {/* Top-Left Royal Blue & Purple Wave */}
      <div className="absolute -top-32 -left-32 w-[600px] h-[600px] rounded-full bg-gradient-to-br from-blue-700 via-indigo-700 to-purple-800 opacity-90 blur-3xl pointer-events-none transform -rotate-12" />
      
      {/* Top-Left Smooth Curving Silk Ribbon (matching reference) */}
      <svg
        className="absolute top-0 left-0 w-[55vw] max-w-[700px] h-auto pointer-events-none opacity-95 z-0"
        viewBox="0 0 600 450"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <path
          d="M -50 -50 C 150 100, 320 40, 280 260 C 240 400, 100 350, -50 420 Z"
          fill="url(#topSilkGradient)"
        />
        <path
          d="M -30 -20 C 120 70, 240 90, 210 240 C 180 340, 70 320, -30 380 Z"
          fill="url(#innerSilkGradient)"
          opacity="0.8"
        />
        <defs>
          <linearGradient id="topSilkGradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#1E3A8A" />
            <stop offset="45%" stopColor="#2563EB" />
            <stop offset="85%" stopColor="#7C3AED" />
            <stop offset="100%" stopColor="#9333EA" />
          </linearGradient>
          <linearGradient id="innerSilkGradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#3B82F6" />
            <stop offset="50%" stopColor="#6366F1" />
            <stop offset="100%" stopColor="#A855F7" />
          </linearGradient>
        </defs>
      </svg>

      {/* Bottom-Right Deep Blue & Violet Curved Silk Wave */}
      <svg
        className="absolute -bottom-10 -right-10 w-[55vw] max-w-[700px] h-auto pointer-events-none opacity-95 z-0"
        viewBox="0 0 600 350"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <path
          d="M 650 400 C 450 250, 300 320, 180 280 C 60 240, 10 320, -50 380 L 650 400 Z"
          fill="url(#bottomSilkGradient)"
        />
        <path
          d="M 650 360 C 470 270, 350 300, 240 280 C 140 260, 80 300, 0 350 L 650 400 Z"
          fill="#3B82F6"
          opacity="0.5"
        />
        <defs>
          <linearGradient id="bottomSilkGradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#0284C7" />
            <stop offset="40%" stopColor="#4F46E5" />
            <stop offset="100%" stopColor="#7E22CE" />
          </linearGradient>
        </defs>
      </svg>

      {/* Subtle Islamic Geometric Tessellation Watermark (upper center/background) */}
      <div
        className="absolute inset-0 opacity-[0.035] pointer-events-none select-none z-0"
        style={{
          backgroundImage: `radial-gradient(circle at 50% 50%, #4f46e5 1px, transparent 1px), radial-gradient(circle at 0% 0%, #7c3aed 1.5px, transparent 1.5px)`,
          backgroundSize: '32px 32px',
        }}
      />

      {/* Ambient Neon Cyan & Violet Glow Orbs */}
      <div className="absolute top-1/3 left-1/4 w-96 h-96 rounded-full bg-cyan-400/15 blur-3xl pointer-events-none" />
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 rounded-full bg-purple-500/15 blur-3xl pointer-events-none" />

      {/* 2. MAIN TWO-COLUMN CONTENT CONTAINER */}
      <div className="relative z-10 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-10 flex-1 flex flex-col justify-center">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
          
          {/* ======================================================== */}
          {/* LEFT COLUMN: 3D DIGITAL RECEIPT CONTAINER & BADGES       */}
          {/* ======================================================== */}
          <div className="lg:col-span-6 relative flex flex-col items-center justify-center min-h-[220px] sm:min-h-[360px] lg:min-h-[480px]">
            {/* The Interactive Three.js 3D Canvas (Scales responsively across mobile, tablet & PC) */}
            <div className="w-full h-[220px] sm:h-[360px] lg:h-[460px] relative">
              <MDSA3DCanvas />

              {/* Floating Glassy Badge 1: Top-Left (Receipt Document Badge) */}
              <motion.div
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.2 }}
                className="absolute top-8 left-4 sm:left-8 bg-white/70 backdrop-blur-md border border-white/80 p-3 sm:p-3.5 rounded-2xl shadow-lg shadow-indigo-500/10 hover:scale-105 transition-transform"
              >
                <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-white shadow-sm">
                  <FileText className="w-4 h-4" />
                </div>
              </motion.div>

              {/* Floating Glassy Badge 2: Bottom-Left (Analytics Chart Badge) */}
              <motion.div
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.4 }}
                className="absolute bottom-16 left-6 sm:left-12 bg-white/70 backdrop-blur-md border border-white/80 p-3 sm:p-3.5 rounded-2xl shadow-lg shadow-indigo-500/10 hover:scale-105 transition-transform"
              >
                <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center text-white shadow-sm">
                  <TrendingUp className="w-4 h-4" />
                </div>
              </motion.div>

              {/* Floating Glassy Badge 3: Top-Right (Verified Checkmark Badge) */}
              <motion.div
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.3 }}
                className="absolute top-10 right-8 sm:right-16 bg-white/70 backdrop-blur-md border border-white/80 p-3 sm:p-3.5 rounded-2xl shadow-lg shadow-indigo-500/10 hover:scale-105 transition-transform"
              >
                <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center text-white shadow-sm">
                  <CheckCircle2 className="w-4 h-4" />
                </div>
              </motion.div>

              {/* Floating Glassy Badge 4: Bottom-Right (Security Shield Badge) */}
              <motion.div
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.5 }}
                className="absolute bottom-20 right-6 sm:right-10 bg-white/70 backdrop-blur-md border border-white/80 p-3 sm:p-3.5 rounded-2xl shadow-lg shadow-indigo-500/10 hover:scale-105 transition-transform"
              >
                <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center text-white shadow-sm">
                  <ShieldCheck className="w-4 h-4" />
                </div>
              </motion.div>
            </div>
          </div>

          {/* ======================================================== */}
          {/* RIGHT COLUMN: MDSA LOGO & GLASSMORPHISM LOGIN CARD        */}
          {/* ======================================================== */}
          <div className="lg:col-span-6 flex flex-col items-center justify-center w-full max-w-md mx-auto">
            
            {/* MDSA LOGO & BRANDING (EXACTLY MATCHING THE REFERENCE) */}
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7 }}
              className="text-center mb-6 w-full flex flex-col items-center"
            >
              {/* Original Logo Image */}
              <div className="h-16 sm:h-20 flex items-center justify-center">
                <img
                  src="/assets/mdsa-logo.png"
                  alt="MDSA Official Logo"
                  className="max-h-full w-auto object-contain drop-shadow-md"
                  onError={(e) => {
                    // Fallback to SVG if PNG is ever unavailable
                    e.currentTarget.src = '/assets/mdsa-logo.svg';
                  }}
                />
              </div>

              {/* Subtitle with decorative divider lines */}
              <div className="flex items-center justify-center gap-3 w-full mt-2">
                <div className="h-[1.5px] w-12 bg-slate-400/60" />
                <span className="text-[11px] sm:text-xs font-extrabold uppercase tracking-[0.2em] text-slate-800">
                  DIGITAL RECEIPT MANAGEMENT PORTAL
                </span>
                <div className="h-[1.5px] w-12 bg-slate-400/60" />
              </div>
            </motion.div>

            {/* GLASSMORPHISM FLOATING LOGIN CARD */}
            <motion.div
              initial={{ opacity: 0, scale: 0.96, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.15 }}
              className="w-full bg-white/80 backdrop-blur-2xl rounded-3xl p-6 sm:p-8 border border-white/90 shadow-[0_20px_60px_-15px_rgba(79,70,229,0.18),0_0_35px_rgba(168,85,247,0.12)] relative overflow-hidden"
            >
              {/* Subtle card glow overlay */}
              <div className="absolute top-0 right-0 w-32 h-32 bg-purple-400/10 rounded-full blur-2xl pointer-events-none" />
              <div className="absolute bottom-0 left-0 w-32 h-32 bg-blue-400/10 rounded-full blur-2xl pointer-events-none" />

              {/* TOP ROLE TABS: ADMIN & STUDENT */}
              <div className="grid grid-cols-2 gap-3 p-1 bg-slate-100/90 rounded-2xl mb-6 border border-slate-200/60">
                <button
                  type="button"
                  onClick={() => handleTabSwitch('admin')}
                  className={`py-3 px-4 rounded-xl text-xs sm:text-sm font-bold flex items-center justify-center gap-2 transition-all duration-300 relative ${
                    portalType === 'admin'
                      ? 'bg-gradient-to-r from-purple-600 via-indigo-600 to-blue-600 text-white shadow-md shadow-indigo-500/30'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
                  }`}
                >
                  <Settings className="w-4 h-4" />
                  <span>ADMIN</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleTabSwitch('student')}
                  className={`py-3 px-4 rounded-xl text-xs sm:text-sm font-bold flex items-center justify-center gap-2 transition-all duration-300 relative ${
                    portalType === 'student'
                      ? 'bg-gradient-to-r from-purple-600 via-indigo-600 to-blue-600 text-white shadow-md shadow-indigo-500/30'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
                  }`}
                >
                  <GraduationCap className="w-4 h-4" />
                  <span>STUDENT</span>
                </button>
              </div>

              {/* Error Alert */}
              <AnimatePresence>
                {errorMessage && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    className="mb-5 p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs font-semibold flex items-start gap-2.5 shadow-sm"
                  >
                    <AlertCircle className="w-4 h-4 text-rose-600 flex-shrink-0 mt-0.5" />
                    <span>{errorMessage}</span>
                  </motion.div>
                )}
              </AnimatePresence>

              {/* LOGIN FORM */}
              <form onSubmit={handleSubmit} className="space-y-4">
                {/* Username / Student ID Input */}
                <div>
                  <div className="relative">
                    <div className="absolute left-4 top-3.5 text-slate-400">
                      <User className="w-4 h-4" />
                    </div>
                    <input
                      type="text"
                      required
                      value={username}
                      onChange={(e) => setUsername(e.target.value)}
                      placeholder={portalType === 'admin' ? 'Enter your username' : 'Enter your Student ID / username'}
                      className="w-full pl-11 pr-4 py-3 rounded-2xl border border-slate-200/90 bg-white/90 text-slate-800 placeholder-slate-400 text-xs sm:text-sm font-medium focus:outline-none focus:ring-2 focus:ring-purple-500/30 focus:border-purple-500 shadow-sm transition-all"
                    />
                  </div>
                </div>

                {/* Password Input with Visibility Toggle */}
                <div>
                  <div className="relative">
                    <div className="absolute left-4 top-3.5 text-slate-400">
                      <Lock className="w-4 h-4" />
                    </div>
                    <input
                      type={showPassword ? 'text' : 'password'}
                      required
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="Enter your password"
                      className="w-full pl-11 pr-11 py-3 rounded-2xl border border-slate-200/90 bg-white/90 text-slate-800 placeholder-slate-400 text-xs sm:text-sm font-medium focus:outline-none focus:ring-2 focus:ring-purple-500/30 focus:border-purple-500 shadow-sm transition-all"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-4 top-3.5 text-slate-400 hover:text-slate-600 transition-colors"
                      title={showPassword ? 'Hide password' : 'Show password'}
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                {/* Remember Me Row (Forgot password removed) */}
                <div className="flex items-center text-xs pt-1">
                  <label className="flex items-center gap-2 cursor-pointer select-none text-slate-700 font-medium">
                    <input
                      type="checkbox"
                      checked={rememberMe}
                      onChange={(e) => setRememberMe(e.target.checked)}
                      className="w-4 h-4 rounded text-purple-600 border-slate-300 focus:ring-purple-500 cursor-pointer"
                    />
                    <span>Remember me</span>
                  </label>
                </div>

                {/* LOGIN SECURELY SUBMIT BUTTON */}
                <button
                  type="submit"
                  disabled={isLoading}
                  className="w-full mt-2 py-3.5 px-6 rounded-2xl bg-gradient-to-r from-purple-600 via-indigo-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 active:scale-[0.99] text-white text-xs sm:text-sm font-extrabold tracking-wide uppercase shadow-lg shadow-indigo-600/30 flex items-center justify-center gap-2.5 transition-all disabled:opacity-60 cursor-pointer"
                >
                  {isLoading ? (
                    <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  ) : (
                    <>
                      <Send className="w-4 h-4 transform -rotate-12" />
                      <span>LOGIN SECURELY</span>
                    </>
                  )}
                </button>

                {/* DEVELOPER TECHNICAL SUPPORT CARD */}
                <div className="pt-4 border-t border-slate-100/90 mt-2 space-y-2">
                  <div className="flex items-center justify-between gap-2 p-2.5 rounded-2xl bg-gradient-to-r from-purple-50 via-indigo-50/50 to-purple-50 border border-purple-200/60 shadow-xs">
                    <div className="flex items-center gap-2.5 overflow-hidden">
                      <div className="w-8 h-8 rounded-xl bg-purple-600 text-white flex items-center justify-center shadow-xs flex-shrink-0">
                        <Mail className="w-4 h-4 text-purple-100" />
                      </div>
                      <div className="text-left overflow-hidden">
                        <span className="block text-[9px] font-extrabold text-purple-900 uppercase tracking-wider">Developer Support</span>
                        <a href="mailto:salahubekal@gmail.com" className="text-xs font-bold text-purple-700 hover:text-purple-950 transition-colors block truncate">
                          salahubekal@gmail.com
                        </a>
                      </div>
                    </div>
                    <a
                      href="mailto:salahubekal@gmail.com"
                      className="px-3 py-1.5 rounded-xl bg-purple-600 hover:bg-purple-700 text-white text-[11px] font-bold shadow-xs transition-transform active:scale-95 flex-shrink-0"
                    >
                      Support
                    </a>
                  </div>

                  <div className="flex items-center justify-center gap-1.5 text-[10px] font-bold text-red-600 uppercase tracking-wider pt-0.5">
                    <ShieldAlert className="w-3.5 h-3.5 text-red-500 flex-shrink-0" />
                    <span>Protected Portal • Duplication Banned</span>
                  </div>
                </div>
              </form>
            </motion.div>
          </div>
        </div>
      </div>

      {/* 3. ULTRA PRO FOOTER WITH COPYRIGHT & LEGAL BANNED SHIELD */}
      <footer className="relative z-10 w-full px-4 sm:px-8 py-3.5 sm:py-4 flex flex-col md:flex-row items-center justify-between text-xs text-slate-500 border-t border-slate-200/80 bg-white/80 backdrop-blur-md gap-3">
        <div className="flex flex-wrap items-center justify-center md:justify-start gap-2.5 text-center md:text-left">
          <span className="inline-flex items-center gap-1.5 bg-red-500/10 text-red-700 border border-red-500/30 text-[10px] sm:text-[11px] font-black px-3 py-1 rounded-full uppercase tracking-wider shadow-xs">
            <ShieldAlert className="w-3.5 h-3.5 text-red-600 animate-pulse flex-shrink-0" />
            <span>COPYRIGHT WARNING: DUPLICATION STRICTLY BANNED</span>
          </span>
          <span className="text-[11px] sm:text-xs font-bold text-slate-700">
            © 2026 MDSA. All Rights Reserved.
          </span>
        </div>

        <div className="flex flex-wrap items-center justify-center gap-2 sm:gap-3 text-[10px] sm:text-xs font-semibold text-slate-600">
          <a
            href="mailto:salahubekal@gmail.com"
            className="inline-flex items-center gap-1.5 text-purple-800 hover:text-purple-950 bg-purple-100/70 hover:bg-purple-100 px-3 py-1.5 rounded-xl transition-all font-bold border border-purple-300/60 shadow-xs"
          >
            <Mail className="w-3.5 h-3.5 text-purple-600 flex-shrink-0" />
            <span>Developer Support: salahubekal@gmail.com</span>
          </a>
          <span className="hidden md:inline text-slate-300">•</span>
          <span className="text-slate-500 font-medium text-[11px]">Smart Solutions for a Digital Tomorrow</span>
        </div>
      </footer>
    </div>
  );
};


import { Receipt, Settings } from '../types';

export const COUNTRY_CODES = [
  { code: '+91', country: 'India 🇮🇳' },
  { code: '+971', country: 'UAE 🇦🇪' },
  { code: '+966', country: 'Saudi Arabia 🇸🇦' },
  { code: '+1', country: 'USA / Canada 🇺🇸' },
  { code: '+44', country: 'UK 🇬🇧' },
  { code: '+974', country: 'Qatar 🇶🇦' },
  { code: '+968', country: 'Oman 🇴🇲' },
  { code: '+965', country: 'Kuwait 🇰🇼' },
  { code: '+973', country: 'Bahrain 🇧🇭' },
  { code: '+60', country: 'Malaysia 🇲🇾' },
  { code: '+65', country: 'Singapore 🇸🇬' },
  { code: '+61', country: 'Australia 🇦🇺' },
];

/**
 * Clean phone number to digits only with country code
 */
export function formatPhoneNumberForWhatsApp(phone: string): string {
  let cleaned = phone.replace(/[^0-9]/g, '');
  // If user entered 10 digits without country code in India (+91 default)
  if (cleaned.length === 10) {
    cleaned = '91' + cleaned;
  }
  return cleaned;
}

/**
 * Builds personalized WhatsApp message replacing variables
 */
export function composeWhatsAppMessage(
  template: string,
  receipt: Receipt,
  settings: Partial<Settings>,
  additionalMessage: string = ''
): string {
  const currency = settings.currency_symbol || '₹';
  const orgName = settings.org_name || 'Our Company';
  const receiptUrl = `${window.location.origin}/#receipt-${receipt.receipt_number}`;

  let message = template || `Dear [Customer Name],

Thank you for your payment.

Please find your digital receipt attached.

Receipt Number: [Receipt Number]
Date: [Date]
Amount: [Currency][Amount]
Payment Method: [Method]
Description: [Description]

Additional Details:
[Additional Message]

Thank you for your business!
_[Organization Name]_`;

  message = message
    .replace(/\[Customer Name\]/g, receipt.customer_name || 'Valued Customer')
    .replace(/\[Receipt Number\]/g, receipt.receipt_number || '')
    .replace(/\[Date\]/g, receipt.receipt_date || '')
    .replace(/\[Amount\]/g, Number(receipt.amount || 0).toLocaleString())
    .replace(/\[Paid Amount\]/g, Number(receipt.paid_amount || 0).toLocaleString())
    .replace(/\[Balance Amount\]/g, Number(receipt.balance_amount || 0).toLocaleString())
    .replace(/\[Currency\]/g, currency)
    .replace(/\[Method\]/g, receipt.payment_method || 'Cash')
    .replace(/\[Status\]/g, receipt.payment_status || 'Paid')
    .replace(/\[Description\]/g, receipt.description || 'Payment')
    .replace(/\[Transaction ID\]/g, receipt.transaction_id || 'N/A')
    .replace(/\[Organization Name\]/g, orgName)
    .replace(/\[Receipt Link\]/g, receiptUrl)
    .replace(/\[Additional Message\]/g, additionalMessage.trim() || 'Payment successfully acknowledged and credited.');

  return message;
}

/**
 * Generates direct wa.me link
 */
export function getWhatsAppClickToChatUrl(phone: string, text: string): string {
  const cleanPhone = formatPhoneNumberForWhatsApp(phone);
  const encodedText = encodeURIComponent(text);
  return `https://wa.me/${cleanPhone}?text=${encodedText}`;
}

/**
 * Native Web Share API helper (for mobile browsers to share files straight to WhatsApp)
 */
export async function shareViaWebShareApi(data: {
  title: string;
  text: string;
  files?: File[];
}): Promise<boolean> {
  if (navigator.share) {
    try {
      if (data.files && data.files.length > 0 && navigator.canShare && navigator.canShare({ files: data.files })) {
        await navigator.share({
          title: data.title,
          text: data.text,
          files: data.files,
        });
        return true;
      } else {
        await navigator.share({
          title: data.title,
          text: data.text,
        });
        return true;
      }
    } catch (err: any) {
      if (err.name !== 'AbortError') {
        console.warn('Web Share API error:', err);
      }
      return false;
    }
  }
  return false;
}


import React, { useState } from 'react';
import { X, Printer, Download, Share2, FileText, Image as ImageIcon, Loader2 } from 'lucide-react';
import { Receipt, Settings } from '../types';
import { DigitalReceiptTemplate } from './DigitalReceiptTemplate';
import { generateReceiptPdf } from '../utils/pdfGenerator';
import { generateReceiptImage } from '../utils/imageGenerator';

interface Props {
  receipt: Partial<Receipt>;
  settings: Partial<Settings>;
  isOpen: boolean;
  onClose: () => void;
  onShareRequested?: (receipt: Receipt) => void;
}

export const ReceiptPreviewModal: React.FC<Props> = ({
  receipt,
  settings,
  isOpen,
  onClose,
  onShareRequested,
}) => {
  if (!isOpen || !receipt) return null;

  const [isExporting, setIsExporting] = useState<boolean>(false);
  const receiptNo = receipt.receipt_number || 'RECEIPT-PREVIEW';

  const handlePrint = () => {
    window.print();
  };

  const handleDownloadPdf = async () => {
    setIsExporting(true);
    try {
      await generateReceiptPdf('preview-receipt-container', receiptNo);
    } catch (err) {
      console.error('PDF error:', err);
    } finally {
      setIsExporting(false);
    }
  };

  const handleDownloadPng = async () => {
    setIsExporting(true);
    try {
      await generateReceiptImage('preview-receipt-container', receiptNo, 'png');
    } catch (err) {
      console.error('PNG error:', err);
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-900/60 backdrop-blur-sm animate-fadeIn">
      <div className="bg-white rounded-2xl shadow-2xl max-w-4xl w-full max-h-[95vh] flex flex-col overflow-hidden border border-slate-200">
        {/* Top Control Bar */}
        <div className="bg-slate-900 text-white p-3.5 sm:p-4 flex items-center justify-between gap-2 flex-shrink-0">
          <div className="flex items-center gap-2">
            <span className="text-sm font-bold tracking-tight">Receipt Preview</span>
            <span className="text-xs bg-slate-800 text-slate-300 font-mono px-2 py-0.5 rounded">
              {receiptNo}
            </span>
          </div>

          <div className="flex items-center gap-2">
            {/* Share WhatsApp Button */}
            {onShareRequested && receipt.id && (
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onShareRequested(receipt as Receipt);
                }}
                className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold flex items-center gap-1.5 transition-colors shadow-sm"
              >
                <Share2 className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Share on WhatsApp</span>
              </button>
            )}

            {/* Print Button */}
            <button
              type="button"
              onClick={handlePrint}
              className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center gap-1.5 transition-colors"
            >
              <Printer className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Print</span>
            </button>

            {/* Download PDF */}
            <button
              type="button"
              onClick={handleDownloadPdf}
              disabled={isExporting}
              className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center gap-1.5 transition-colors disabled:opacity-50"
            >
              {isExporting ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <FileText className="w-3.5 h-3.5" />}
              <span className="hidden sm:inline">PDF</span>
            </button>

            {/* Download PNG */}
            <button
              type="button"
              onClick={handleDownloadPng}
              disabled={isExporting}
              className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center gap-1.5 transition-colors disabled:opacity-50"
            >
              <ImageIcon className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">PNG</span>
            </button>

            {/* Close Button */}
            <button
              type="button"
              onClick={onClose}
              className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Scrollable Receipt Body */}
        <div className="p-4 sm:p-8 overflow-y-auto bg-slate-100/70 flex justify-center items-start">
          <div className="w-full max-w-3xl transform transition-transform">
            <DigitalReceiptTemplate
              elementId="preview-receipt-container"
              receipt={receipt}
              settings={settings}
            />
          </div>
        </div>
      </div>
    </div>
  );
};


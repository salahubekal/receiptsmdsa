import express from 'express';
import cors from 'cors';
import path from 'path';
import fs from 'fs';
import dotenv from 'dotenv';
import authRoutes from './routes/auth.js';
import customerRoutes from './routes/customers.js';
import receiptRoutes from './routes/receipts.js';
import settingsRoutes from './routes/settings.js';
import whatsappRoutes from './routes/whatsapp.js';
import backupRoutes from './routes/backup.js';
import studentRoutes from './routes/student.js';
import paymentsRoutes from './routes/payments.js';
import realtimeRoutes from './routes/realtime.js';
import adminRoutes from './routes/adminManagement.js';
import { db } from './db/index.js';

dotenv.config();

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

// Enable CORS and JSON parsing (support base64 images)
app.use(cors());
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({
    status: 'online',
    system: 'Paperless Digital Receipt Management System',
    timestamp: new Date().toISOString(),
  });
});

// API Routes
app.use('/api/auth', authRoutes);
app.use('/api/customers', customerRoutes);
app.use('/api/receipts', receiptRoutes);
app.use('/api/settings', settingsRoutes);
app.use('/api/whatsapp', whatsappRoutes);
app.use('/api/backup', backupRoutes);
app.use('/api/student', studentRoutes);
app.use('/api/payments', paymentsRoutes);
app.use('/api/realtime', realtimeRoutes);
app.use('/api/admin', adminRoutes);

// Setup frontend serving: in production serve dist/client, or integrate Vite in dev
async function startServer() {
  const isProduction = process.env.NODE_ENV === 'production';
  const clientDist = path.resolve(process.cwd(), 'dist', 'client');

  if (isProduction && fs.existsSync(clientDist)) {
    console.log(`Serving static production build from ${clientDist}`);
    app.use(express.static(clientDist));
    app.get('*', (req, res) => {
      res.sendFile(path.join(clientDist, 'index.html'));
    });
  } else {
    // Development mode: integrate Vite middleware
    try {
      const { createServer: createViteServer } = await import('vite');
      const vite = await createViteServer({
        server: { middlewareMode: true },
        appType: 'spa',
      });
      app.use(vite.middlewares);
      console.log('Vite development middleware integrated.');
    } catch (err) {
      console.warn('Vite middleware not available, falling back to static files if present.');
      if (fs.existsSync(clientDist)) {
        app.use(express.static(clientDist));
        app.get('*', (req, res) => {
          res.sendFile(path.join(clientDist, 'index.html'));
        });
      }
    }
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`=======================================================`);
    console.log(`🚀 Paperless Digital Receipt Management System is running!`);
    console.log(`👉 Local URL: http://localhost:${PORT}`);
    console.log(`📱 Mobile / Network URL: http://0.0.0.0:${PORT}`);
    console.log(`=======================================================`);
  });
}

startServer().catch(err => {
  console.error('Failed to start server:', err);
});


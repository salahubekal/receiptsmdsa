import { Router, Response } from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { db } from '../db/index.js';
import { AuthRequest } from './auth.js';
import { broadcastEvent } from './realtime.js';

const router = Router();
const JWT_SECRET = process.env.JWT_SECRET || 'paperless-receipt-secret-key-2026';

// Middleware to enforce Admin-only access
export function authenticateAdmin(req: AuthRequest, res: Response, next: Function) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ error: 'Authentication required. Please sign in as Administrator.' });
  }

  try {
    const decoded = jwt.verify(token, JWT_SECRET) as any;
    req.user = decoded;
    if (decoded.role !== 'admin') {
      return res.status(403).json({ error: 'Access denied. Administrator privileges required.' });
    }
    next();
  } catch (err) {
    return res.status(403).json({ error: 'Invalid or expired session. Please sign in again.' });
  }
}

// Apply admin authentication to all routes in this module
router.use(authenticateAdmin);

// ==========================================
// 1. STUDENT REGISTRATION & MANAGEMENT
// ==========================================

// Helper to generate next unique Student ID: STD-YYYY-XXX
function getNextStudentId(): string {
  const year = new Date().getFullYear();
  const prefix = `STD-${year}-`;
  const last = db.prepare(`
    SELECT student_id FROM students 
    WHERE student_id LIKE ? 
    ORDER BY id DESC LIMIT 1
  `).get(`${prefix}%`) as { student_id: string } | undefined;

  let nextSeq = 1;
  if (last) {
    const parts = last.student_id.split('-');
    const num = parseInt(parts[parts.length - 1], 10);
    if (!isNaN(num)) nextSeq = num + 1;
  }
  return `${prefix}${String(nextSeq).padStart(3, '0')}`;
}

// GET /api/admin/students - List all registered students
router.get('/students', (req: AuthRequest, res: Response) => {
  try {
    const today = new Date().toISOString().split('T')[0];

    const students = db.prepare(`
      SELECT 
        s.id,
        s.student_id,
        s.name,
        s.phone,
        s.email,
        s.class_name,
        s.location_id,
        s.location_name,
        s.group_id,
        s.group_name,
        s.status,
        s.created_at,
        u.username,
        u.must_change_password,
        u.password_changed_at,
        COALESCE(SUM(p.amount), 0) as overall_collection,
        COUNT(p.id) as total_transactions,
        COALESCE(SUM(CASE WHEN p.payment_date = ? THEN p.amount ELSE 0 END), 0) as today_collection,
        COUNT(CASE WHEN p.payment_date = ? THEN p.id ELSE NULL END) as today_transactions,
        MAX(p.created_at) as last_payment_time
      FROM students s
      LEFT JOIN users u ON s.student_id = u.student_id
      LEFT JOIN payments p ON s.student_id = p.student_id
      GROUP BY s.student_id
      ORDER BY s.id DESC
    `).all(today, today);

    res.json(students);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/admin/students - Register a new Student (Admin only)
router.post('/students', (req: AuthRequest, res: Response) => {
  const {
    name,
    phone,
    email = '',
    class_name = 'MDSA Batch 2026',
    location_id = null,
    group_id = '',
  } = req.body;

  // Validation: Required fields
  if (!name || !name.trim()) {
    return res.status(400).json({ error: 'Student Name is required.' });
  }
  if (!phone || !phone.trim()) {
    return res.status(400).json({ error: 'Student Mobile Number is required.' });
  }

  const cleanPhone = phone.replace(/[^0-9]/g, '');
  if (cleanPhone.length < 10) {
    return res.status(400).json({
      error: 'Invalid mobile number. Must contain at least 10 digits.',
    });
  }

  // Prevent duplicate student account by phone
  const existingPhone = db.prepare('SELECT id, name, student_id FROM students WHERE phone = ?').get(phone.trim()) as any;
  if (existingPhone) {
    return res.status(400).json({
      error: `A student account with mobile number "${phone}" already exists (${existingPhone.name} - ${existingPhone.student_id}).`,
    });
  }

  // Generate unique Student ID
  const studentId = getNextStudentId();

  // Username must initially be the student's registered name (Requirement 2)
  const registeredName = name.trim();
  let username = registeredName;

  // Check if username already exists in users table, append suffix if duplicate
  const existingUser = db.prepare('SELECT id FROM users WHERE LOWER(username) = LOWER(?)').get(username);
  if (existingUser) {
    username = `${registeredName} (${studentId})`;
  }

  // Initial password must be the registered mobile number (Requirement 3)
  // Use clean 10-digit phone digits for seamless mobile typing
  const initialPassword = cleanPhone.length === 10 ? cleanPhone : cleanPhone.slice(-10);
  const salt = bcrypt.genSaltSync(10);
  const passwordHash = bcrypt.hashSync(initialPassword, salt);

  // Lookup location details if assigned
  let locationName = '';
  if (location_id) {
    const loc = db.prepare('SELECT name FROM locations WHERE id = ?').get(location_id) as any;
    if (loc) locationName = loc.name;
  }

  // Lookup group details if assigned
  let groupName = '';
  if (group_id) {
    const grp = db.prepare('SELECT group_name FROM groups WHERE group_id = ?').get(group_id) as any;
    if (grp) groupName = grp.group_name;
  }

  try {
    // Insert into students table
    const studentInsert = db.prepare(`
      INSERT INTO students (
        student_id, name, phone, email, class_name, location_id, location_name,
        group_id, group_name, total_collected, status
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 0, 'Active')
    `).run(
      studentId,
      registeredName,
      phone.trim(),
      email ? email.trim() : '',
      class_name ? class_name.trim() : 'MDSA Batch 2026',
      location_id || null,
      locationName,
      group_id || '',
      groupName
    );

    const studentDbId = Number(studentInsert.lastInsertRowid);

    // Insert user account with must_change_password = 1 (Requirement 4)
    db.prepare(`
      INSERT INTO users (
        username, password_hash, role, full_name, student_id,
        must_change_password, created_at
      ) VALUES (?, ?, 'student', ?, ?, 1, CURRENT_TIMESTAMP)
    `).run(
      username,
      passwordHash,
      registeredName,
      studentId
    );

    // If group is assigned, add student to group_members if not present
    if (group_id) {
      const grp = db.prepare('SELECT id FROM groups WHERE group_id = ?').get(group_id) as any;
      if (grp) {
        const memExists = db.prepare('SELECT id FROM group_members WHERE group_id = ? AND student_id = ?').get(grp.id, studentId);
        if (!memExists) {
          db.prepare(`
            INSERT INTO group_members (group_id, student_id, member_name, member_phone, role)
            VALUES (?, ?, ?, ?, 'Member')
          `).run(grp.id, studentId, registeredName, phone.trim());
        }
      }
    }

    // Record audit log
    db.prepare(`
      INSERT INTO receipt_audit_logs (receipt_id, receipt_number, action, changed_fields, performed_by)
      VALUES (NULL, 'STUDENT-REG', 'CREATED', ?, ?)
    `).run(
      `Student registered: ${registeredName} (${studentId}) with location "${locationName}" and group "${groupName}"`,
      req.user?.full_name || 'Admin'
    );

    // Live broadcast to all connected platforms
    broadcastEvent({
      type: 'STUDENT_REGISTERED',
      studentId,
      name: registeredName,
      locationName,
      groupName,
      timestamp: new Date().toISOString(),
    });

    res.status(201).json({
      success: true,
      student: {
        id: studentDbId,
        student_id: studentId,
        name: registeredName,
        username,
        phone: phone.trim(),
        email: email.trim(),
        class_name,
        location_id,
        location_name: locationName,
        group_id,
        group_name: groupName,
        initialPassword,
        must_change_password: true,
      },
      message: `Student account created for "${registeredName}". Initial username: "${username}", Initial password: "${initialPassword}". Forced password change will occur on first login.`,
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// PUT /api/admin/students/:id - Update student details
router.put('/students/:id', (req: AuthRequest, res: Response) => {
  const { id } = req.params;
  const { name, phone, email, class_name, location_id, group_id, status } = req.body;

  try {
    const student = db.prepare('SELECT * FROM students WHERE id = ?').get(id) as any;
    if (!student) {
      return res.status(404).json({ error: 'Student record not found.' });
    }

    let locationName = student.location_name;
    if (location_id !== undefined) {
      if (location_id) {
        const loc = db.prepare('SELECT name FROM locations WHERE id = ?').get(location_id) as any;
        locationName = loc ? loc.name : '';
      } else {
        locationName = '';
      }
    }

    let groupName = student.group_name;
    if (group_id !== undefined) {
      if (group_id) {
        const grp = db.prepare('SELECT group_name FROM groups WHERE group_id = ?').get(group_id) as any;
        groupName = grp ? grp.group_name : '';
      } else {
        groupName = '';
      }
    }

    db.prepare(`
      UPDATE students 
      SET name = COALESCE(?, name),
          phone = COALESCE(?, phone),
          email = COALESCE(?, email),
          class_name = COALESCE(?, class_name),
          location_id = ?,
          location_name = ?,
          group_id = ?,
          group_name = ?,
          status = COALESCE(?, status)
      WHERE id = ?
    `).run(
      name ? name.trim() : null,
      phone ? phone.trim() : null,
      email !== undefined ? email.trim() : null,
      class_name !== undefined ? class_name.trim() : null,
      location_id !== undefined ? location_id : student.location_id,
      locationName,
      group_id !== undefined ? group_id : student.group_id,
      groupName,
      status || null,
      id
    );

    // Also update users full_name
    if (name) {
      db.prepare('UPDATE users SET full_name = ? WHERE student_id = ?').run(name.trim(), student.student_id);
    }

    res.json({ success: true, message: 'Student details updated successfully.' });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/admin/students/:id/reset-password - Admin resets student password (Requirement 5)
router.post('/students/:id/reset-password', (req: AuthRequest, res: Response) => {
  const { id } = req.params;
  const { custom_password = '' } = req.body;

  try {
    const student = db.prepare('SELECT * FROM students WHERE id = ?').get(id) as any;
    if (!student) {
      return res.status(404).json({ error: 'Student record not found.' });
    }

    // Default reset password is student's registered mobile number (or custom admin password)
    const cleanPhone = student.phone.replace(/[^0-9]/g, '');
    const defaultPassword = cleanPhone.length === 10 ? cleanPhone : cleanPhone.slice(-10);
    const newPassword = (custom_password || defaultPassword).trim();

    const salt = bcrypt.genSaltSync(10);
    const hash = bcrypt.hashSync(newPassword, salt);

    // Reset password and set must_change_password = 1 (Force change on next login)
    db.prepare(`
      UPDATE users 
      SET password_hash = ?, must_change_password = 1, password_changed_at = NULL 
      WHERE student_id = ?
    `).run(hash, student.student_id);

    // Audit log
    db.prepare(`
      INSERT INTO receipt_audit_logs (receipt_id, receipt_number, action, changed_fields, performed_by)
      VALUES (NULL, ?, 'PASSWORD_RESET', ?, ?)
    `).run(
      student.student_id,
      `Password reset for student ${student.name} (${student.student_id}) by Administrator`,
      req.user?.full_name || 'Admin'
    );

    // Live broadcast password reset
    broadcastEvent({
      type: 'PASSWORD_RESET',
      studentId: student.student_id,
      name: student.name,
      timestamp: new Date().toISOString(),
    });

    res.json({
      success: true,
      student_id: student.student_id,
      student_name: student.name,
      temporaryPassword: newPassword,
      message: `Password for ${student.name} (${student.student_id}) has been reset to "${newPassword}". Forced change on next login is enabled.`,
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// DELETE /api/admin/students/:id - Delete or de-register student
router.delete('/students/:id', (req: AuthRequest, res: Response) => {
  const { id } = req.params;

  try {
    const student = db.prepare('SELECT * FROM students WHERE id = ?').get(id) as any;
    if (!student) {
      return res.status(404).json({ error: 'Student record not found.' });
    }

    // Delete user account
    db.prepare('DELETE FROM users WHERE student_id = ?').run(student.student_id);
    // Delete student record
    db.prepare('DELETE FROM students WHERE id = ?').run(id);

    res.json({ success: true, message: `Student ${student.name} (${student.student_id}) has been removed.` });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ==========================================
// 2. GROUP MANAGEMENT (Requirements 7, 8, 9, 10, 14)
// ==========================================

// Helper to generate next unique Group ID: GRP-YYYY-XXX
function getNextGroupId(): string {
  const year = new Date().getFullYear();
  const prefix = `GRP-${year}-`;
  const last = db.prepare(`
    SELECT group_id FROM groups 
    WHERE group_id LIKE ? 
    ORDER BY id DESC LIMIT 1
  `).get(`${prefix}%`) as { group_id: string } | undefined;

  let nextSeq = 1;
  if (last) {
    const parts = last.group_id.split('-');
    const num = parseInt(parts[parts.length - 1], 10);
    if (!isNaN(num)) nextSeq = num + 1;
  }
  return `${prefix}${String(nextSeq).padStart(3, '0')}`;
}

// GET /api/admin/groups - List all groups with leader, location, members, and collection totals
router.get('/groups', (req: AuthRequest, res: Response) => {
  try {
    const today = new Date().toISOString().split('T')[0];

    const groups = db.prepare(`
      SELECT 
        g.id,
        g.group_id,
        g.group_name,
        g.leader_student_id,
        g.leader_name,
        g.leader_phone,
        g.location_id,
        g.location_name,
        g.notes,
        g.status,
        g.created_at,
        COUNT(DISTINCT m.id) as members_count,
        COALESCE(SUM(p.amount), 0) as overall_collection,
        COUNT(DISTINCT p.id) as total_transactions,
        COALESCE(SUM(CASE WHEN p.payment_date = ? THEN p.amount ELSE 0 END), 0) as today_collection,
        COUNT(DISTINCT CASE WHEN p.payment_date = ? THEN p.id ELSE NULL END) as today_transactions,
        MAX(p.created_at) as last_payment_time
      FROM groups g
      LEFT JOIN group_members m ON g.id = m.group_id
      LEFT JOIN payments p ON g.group_id = p.group_id
      GROUP BY g.id
      ORDER BY today_collection DESC, overall_collection DESC
    `).all(today, today) as any[];

    // Fetch members for each group
    const membersStmt = db.prepare('SELECT * FROM group_members WHERE group_id = ? ORDER BY id ASC');
    for (const grp of groups) {
      grp.members = membersStmt.all(grp.id);
    }

    res.json(groups);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/admin/groups - Create a new Group with leader, location, and unlimited members
router.post('/groups', (req: AuthRequest, res: Response) => {
  const {
    group_name,
    leader_name,
    leader_phone,
    leader_student_id = '',
    location_id = null,
    notes = '',
    members = [],
  } = req.body;

  // Validation
  if (!group_name || !group_name.trim()) {
    return res.status(400).json({ error: 'Group Name is required.' });
  }
  if (!leader_name || !leader_name.trim()) {
    return res.status(400).json({ error: 'Designated Group Leader Name is required.' });
  }
  if (!leader_phone || !leader_phone.trim()) {
    return res.status(400).json({ error: 'Group Leader Mobile Number is required.' });
  }

  // Prevent duplicate group name (Requirement 15)
  const dup = db.prepare('SELECT id FROM groups WHERE LOWER(group_name) = LOWER(?)').get(group_name.trim());
  if (dup) {
    return res.status(400).json({ error: `A collection group named "${group_name}" already exists.` });
  }

  // Validate leader mobile
  const cleanLeaderPhone = leader_phone.replace(/[^0-9]/g, '');
  if (cleanLeaderPhone.length < 10) {
    return res.status(400).json({ error: 'Leader mobile number must contain at least 10 digits.' });
  }

  // Validate members (Requirement 9: Each member must have name and mobile number)
  if (Array.isArray(members)) {
    for (let i = 0; i < members.length; i++) {
      const m = members[i];
      if (!m.member_name || !m.member_name.trim()) {
        return res.status(400).json({ error: `Member #${i + 1} is missing a name.` });
      }
      if (!m.member_phone || !m.member_phone.trim()) {
        return res.status(400).json({ error: `Member "${m.member_name}" is missing a mobile number.` });
      }
      const mClean = m.member_phone.replace(/[^0-9]/g, '');
      if (mClean.length < 10) {
        return res.status(400).json({ error: `Member "${m.member_name}" has an invalid mobile number (at least 10 digits required).` });
      }
    }
  }

  // Generate unique Group ID (Requirement 14)
  const groupId = getNextGroupId();

  // Lookup location name if assigned (Requirement 10)
  let locationName = '';
  if (location_id) {
    const loc = db.prepare('SELECT name FROM locations WHERE id = ?').get(location_id) as any;
    if (loc) locationName = loc.name;
  }

  try {
    const groupInsert = db.prepare(`
      INSERT INTO groups (
        group_id, group_name, leader_student_id, leader_name, leader_phone,
        location_id, location_name, notes, total_collected, status
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0, 'Active')
    `).run(
      groupId,
      group_name.trim(),
      leader_student_id ? leader_student_id.trim() : '',
      leader_name.trim(),
      leader_phone.trim(),
      location_id || null,
      locationName,
      notes ? notes.trim() : ''
    );

    const groupDbId = Number(groupInsert.lastInsertRowid);

    // Insert Leader as first member
    const insertMember = db.prepare(`
      INSERT INTO group_members (group_id, student_id, member_name, member_phone, role)
      VALUES (?, ?, ?, ?, ?)
    `);

    insertMember.run(
      groupDbId,
      leader_student_id ? leader_student_id.trim() : '',
      leader_name.trim(),
      leader_phone.trim(),
      'Leader'
    );

    // Insert unlimited group members (Requirement 8 & 9)
    if (Array.isArray(members)) {
      for (const m of members) {
        // Skip if same as leader
        if (m.member_phone.replace(/[^0-9]/g, '') === cleanLeaderPhone) continue;
        insertMember.run(
          groupDbId,
          m.student_id ? m.student_id.trim() : '',
          m.member_name.trim(),
          m.member_phone.trim(),
          'Member'
        );
      }
    }

    // If leader is a registered student, update their student record
    if (leader_student_id) {
      db.prepare(`
        UPDATE students 
        SET group_id = ?, group_name = ?, location_id = COALESCE(?, location_id), location_name = COALESCE(?, location_name)
        WHERE student_id = ?
      `).run(groupId, group_name.trim(), location_id, locationName, leader_student_id);
    }

    // Live broadcast group created
    broadcastEvent({
      type: 'GROUP_CREATED',
      groupId,
      groupName: group_name.trim(),
      leaderName: leader_name.trim(),
      locationName,
      timestamp: new Date().toISOString(),
    });

    res.status(201).json({
      success: true,
      group: {
        id: groupDbId,
        group_id: groupId,
        group_name: group_name.trim(),
        leader_name: leader_name.trim(),
        leader_phone: leader_phone.trim(),
        location_id,
        location_name: locationName,
      },
      message: `Group "${group_name}" created with ID ${groupId} and designated leader ${leader_name}.`,
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/admin/groups/:id/members - Add unlimited members to existing group (Requirement 8 & 9)
router.post('/groups/:id/members', (req: AuthRequest, res: Response) => {
  const { id } = req.params;
  const { member_name, member_phone, student_id = '', role = 'Member' } = req.body;

  if (!member_name || !member_name.trim()) {
    return res.status(400).json({ error: 'Member Name is required.' });
  }
  if (!member_phone || !member_phone.trim()) {
    return res.status(400).json({ error: 'Member Mobile Number is required.' });
  }

  const clean = member_phone.replace(/[^0-9]/g, '');
  if (clean.length < 10) {
    return res.status(400).json({ error: 'Member mobile number must have at least 10 digits.' });
  }

  try {
    const grp = db.prepare('SELECT id, group_name FROM groups WHERE id = ?').get(id) as any;
    if (!grp) {
      return res.status(404).json({ error: 'Group record not found.' });
    }

    const insert = db.prepare(`
      INSERT INTO group_members (group_id, student_id, member_name, member_phone, role)
      VALUES (?, ?, ?, ?, ?)
    `).run(
      grp.id,
      student_id ? student_id.trim() : '',
      member_name.trim(),
      member_phone.trim(),
      role || 'Member'
    );

    // Live broadcast member added
    broadcastEvent({
      type: 'MEMBER_ADDED',
      groupId: grp.group_id,
      groupName: grp.group_name,
      memberName: member_name.trim(),
      timestamp: new Date().toISOString(),
    });

    res.status(201).json({
      success: true,
      memberId: Number(insert.lastInsertRowid),
      message: `Member "${member_name}" added to group "${grp.group_name}".`,
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// DELETE /api/admin/groups/:id/members/:memberId - Remove member from group
router.delete('/groups/:id/members/:memberId', (req: AuthRequest, res: Response) => {
  const { id, memberId } = req.params;
  try {
    db.prepare('DELETE FROM group_members WHERE id = ? AND group_id = ?').run(memberId, id);
    res.json({ success: true, message: 'Member removed from group.' });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// DELETE /api/admin/groups/:id - Delete group
router.delete('/groups/:id', (req: AuthRequest, res: Response) => {
  const { id } = req.params;
  try {
    const grp = db.prepare('SELECT group_id, group_name FROM groups WHERE id = ?').get(id) as any;
    if (!grp) return res.status(404).json({ error: 'Group not found.' });

    // Clean up members and group
    db.prepare('DELETE FROM group_members WHERE group_id = ?').run(id);
    db.prepare('DELETE FROM groups WHERE id = ?').run(id);

    // Unassign students from this group
    db.prepare('UPDATE students SET group_id = "", group_name = "" WHERE group_id = ?').run(grp.group_id);

    res.json({ success: true, message: `Group "${grp.group_name}" removed.` });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ==========================================
// 3. COLLECTION LOCATION MANAGEMENT (Requirement 10 & 14)
// ==========================================

// Helper to generate next unique Location Code: LOC-YYYY-XXX
function getNextLocationCode(): string {
  const year = new Date().getFullYear();
  const prefix = `LOC-${year}-`;
  const last = db.prepare(`
    SELECT location_code FROM locations 
    WHERE location_code LIKE ? 
    ORDER BY id DESC LIMIT 1
  `).get(`${prefix}%`) as { location_code: string } | undefined;

  let nextSeq = 1;
  if (last) {
    const parts = last.location_code.split('-');
    const num = parseInt(parts[parts.length - 1], 10);
    if (!isNaN(num)) nextSeq = num + 1;
  }
  return `${prefix}${String(nextSeq).padStart(3, '0')}`;
}

// GET /api/admin/locations - List all collection locations
router.get('/locations', (req: AuthRequest, res: Response) => {
  try {
    const today = new Date().toISOString().split('T')[0];

    const locations = db.prepare(`
      SELECT 
        l.id,
        l.location_code,
        l.name,
        l.city_or_area,
        l.description,
        l.status,
        l.created_at,
        COUNT(DISTINCT s.id) as assigned_students_count,
        COUNT(DISTINCT g.id) as assigned_groups_count,
        COALESCE(SUM(p.amount), 0) as overall_collection,
        COUNT(DISTINCT p.id) as total_transactions,
        COALESCE(SUM(CASE WHEN p.payment_date = ? THEN p.amount ELSE 0 END), 0) as today_collection,
        COUNT(DISTINCT CASE WHEN p.payment_date = ? THEN p.id ELSE NULL END) as today_transactions,
        MAX(p.created_at) as last_payment_time
      FROM locations l
      LEFT JOIN students s ON l.id = s.location_id
      LEFT JOIN groups g ON l.id = g.location_id
      LEFT JOIN payments p ON l.id = p.location_id
      GROUP BY l.id
      ORDER BY today_collection DESC, overall_collection DESC
    `).all(today, today);

    res.json(locations);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/admin/locations - Create a new collection location
router.post('/locations', (req: AuthRequest, res: Response) => {
  const { name, city_or_area = '', description = '' } = req.body;

  if (!name || !name.trim()) {
    return res.status(400).json({ error: 'Location Name is required.' });
  }

  // Prevent duplicate location name
  const dup = db.prepare('SELECT id FROM locations WHERE LOWER(name) = LOWER(?)').get(name.trim());
  if (dup) {
    return res.status(400).json({ error: `Collection location "${name}" already exists.` });
  }

  const code = getNextLocationCode();

  try {
    const insert = db.prepare(`
      INSERT INTO locations (location_code, name, city_or_area, description, status)
      VALUES (?, ?, ?, ?, 'Active')
    `).run(code, name.trim(), city_or_area ? city_or_area.trim() : '', description ? description.trim() : '');

    // Live broadcast location created
    broadcastEvent({
      type: 'LOCATION_CREATED',
      locationCode: code,
      name: name.trim(),
      timestamp: new Date().toISOString(),
    });

    res.status(201).json({
      success: true,
      location: {
        id: Number(insert.lastInsertRowid),
        location_code: code,
        name: name.trim(),
        city_or_area: city_or_area.trim(),
        description: description.trim(),
      },
      message: `Collection location "${name}" created with code ${code}.`,
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// PUT /api/admin/locations/:id - Update location
router.put('/locations/:id', (req: AuthRequest, res: Response) => {
  const { id } = req.params;
  const { name, city_or_area, description, status } = req.body;

  try {
    const loc = db.prepare('SELECT * FROM locations WHERE id = ?').get(id) as any;
    if (!loc) return res.status(404).json({ error: 'Location not found.' });

    db.prepare(`
      UPDATE locations 
      SET name = COALESCE(?, name),
          city_or_area = COALESCE(?, city_or_area),
          description = COALESCE(?, description),
          status = COALESCE(?, status)
      WHERE id = ?
    `).run(
      name ? name.trim() : null,
      city_or_area !== undefined ? city_or_area.trim() : null,
      description !== undefined ? description.trim() : null,
      status || null,
      id
    );

    // If name changed, update location_name in students and groups
    if (name && name.trim() !== loc.name) {
      db.prepare('UPDATE students SET location_name = ? WHERE location_id = ?').run(name.trim(), id);
      db.prepare('UPDATE groups SET location_name = ? WHERE location_id = ?').run(name.trim(), id);
      db.prepare('UPDATE payments SET location_name = ? WHERE location_id = ?').run(name.trim(), id);
    }

    res.json({ success: true, message: 'Location updated successfully.' });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// DELETE /api/admin/locations/:id - Delete location
router.delete('/locations/:id', (req: AuthRequest, res: Response) => {
  const { id } = req.params;
  try {
    db.prepare('UPDATE students SET location_id = NULL, location_name = "" WHERE location_id = ?').run(id);
    db.prepare('UPDATE groups SET location_id = NULL, location_name = "" WHERE location_id = ?').run(id);
    db.prepare('DELETE FROM locations WHERE id = ?').run(id);
    res.json({ success: true, message: 'Location deleted successfully.' });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ==========================================
// 4. MULTI-DIMENSIONAL BREAKDOWN REPORTS (Requirements 12 & 13)
// ==========================================

// GET /api/admin/breakdowns - Returns Individual, Group-Wise, and Location-Wise collections
router.get('/breakdowns', (req: AuthRequest, res: Response) => {
  const { period = 'daily', date, startDate, endDate } = req.query;

  try {
    const today = new Date().toISOString().split('T')[0];
    let start = (startDate as string) || (date as string) || today;
    let end = (endDate as string) || (date as string) || today;

    if (period === 'weekly') {
      const now = new Date();
      const first = now.getDate() - now.getDay();
      start = new Date(now.setDate(first)).toISOString().split('T')[0];
      end = today;
    } else if (period === 'monthly') {
      start = today.substring(0, 8) + '01';
      end = today;
    }

    // 1. Individual Student Collections
    const individuals = db.prepare(`
      SELECT 
        s.student_id,
        s.name as student_name,
        s.class_name,
        s.location_name,
        s.group_name,
        COUNT(p.id) as payment_count,
        COALESCE(SUM(p.amount), 0) as total_collected,
        MIN(p.created_at) as first_payment_time,
        MAX(p.created_at) as last_payment_time
      FROM students s
      LEFT JOIN payments p ON s.student_id = p.student_id AND p.payment_date >= ? AND p.payment_date <= ?
      GROUP BY s.student_id
      ORDER BY total_collected DESC
    `).all(start, end);

    // 2. Group-Wise Collections
    const groups = db.prepare(`
      SELECT 
        g.group_id,
        g.group_name,
        g.leader_name,
        g.leader_phone,
        g.location_name,
        COUNT(DISTINCT m.id) as members_count,
        COUNT(p.id) as payment_count,
        COALESCE(SUM(p.amount), 0) as total_collected,
        MIN(p.created_at) as first_payment_time,
        MAX(p.created_at) as last_payment_time
      FROM groups g
      LEFT JOIN group_members m ON g.id = m.group_id
      LEFT JOIN payments p ON g.group_id = p.group_id AND p.payment_date >= ? AND p.payment_date <= ?
      GROUP BY g.group_id
      ORDER BY total_collected DESC
    `).all(start, end);

    // 3. Location-Wise Collections
    const locations = db.prepare(`
      SELECT 
        l.location_code,
        l.name as location_name,
        l.city_or_area,
        COUNT(DISTINCT s.id) as assigned_students,
        COUNT(DISTINCT g.id) as assigned_groups,
        COUNT(p.id) as payment_count,
        COALESCE(SUM(p.amount), 0) as total_collected,
        MIN(p.created_at) as first_payment_time,
        MAX(p.created_at) as last_payment_time
      FROM locations l
      LEFT JOIN students s ON l.id = s.location_id
      LEFT JOIN groups g ON l.id = g.location_id
      LEFT JOIN payments p ON l.id = p.location_id AND p.payment_date >= ? AND p.payment_date <= ?
      GROUP BY l.id
      ORDER BY total_collected DESC
    `).all(start, end);

    // Aggregate summary
    const totalCollected = db.prepare(`
      SELECT COALESCE(SUM(amount), 0) as total, COUNT(id) as count 
      FROM payments WHERE payment_date >= ? AND payment_date <= ?
    `).get(start, end) as any;

    res.json({
      period,
      startDate: start,
      endDate: end,
      summary: {
        totalCollected: totalCollected?.total || 0,
        totalPayments: totalCollected?.count || 0,
        activeStudents: individuals.filter((i: any) => Number(i.total_collected) > 0).length,
        activeGroups: groups.filter((g: any) => Number(g.total_collected) > 0).length,
        activeLocations: locations.filter((l: any) => Number(l.total_collected) > 0).length,
      },
      individuals,
      groups,
      locations,
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

export default router;

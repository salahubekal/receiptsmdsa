/**
 * Converts a numeric amount into English words (Indian numbering system: Lakhs, Crores, Thousands)
 */
export function numberToWords(amount: number, currencyName: string = 'Rupees'): string {
  if (isNaN(amount) || amount === 0) return `Zero ${currencyName} Only`;

  const ones = [
    '', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine',
    'Ten', 'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen',
    'Seventeen', 'Eighteen', 'Nineteen'
  ];

  const tens = [
    '', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'
  ];

  function convertTwoDigits(num: number): string {
    if (num === 0) return '';
    if (num < 20) return ones[num] + ' ';
    const t = Math.floor(num / 10);
    const o = num % 10;
    return tens[t] + (o > 0 ? '-' + ones[o] : '') + ' ';
  }

  function convertThreeDigits(num: number): string {
    let str = '';
    const h = Math.floor(num / 100);
    const rest = num % 100;
    if (h > 0) {
      str += ones[h] + ' Hundred ';
      if (rest > 0) str += 'and ';
    }
    str += convertTwoDigits(rest);
    return str;
  }

  const integerPart = Math.floor(Math.abs(amount));
  const decimalPart = Math.round((Math.abs(amount) - integerPart) * 100);

  let num = integerPart;
  let words = '';

  // Crores (1,00,00,000)
  const crores = Math.floor(num / 10000000);
  num %= 10000000;
  if (crores > 0) {
    words += convertTwoDigits(crores) + 'Crore ';
  }

  // Lakhs (1,00,000)
  const lakhs = Math.floor(num / 100000);
  num %= 100000;
  if (lakhs > 0) {
    words += convertTwoDigits(lakhs) + 'Lakh ';
  }

  // Thousands (1,000)
  const thousands = Math.floor(num / 1000);
  num %= 1000;
  if (thousands > 0) {
    words += convertTwoDigits(thousands) + 'Thousand ';
  }

  // Hundreds & rest
  if (num > 0) {
    words += convertThreeDigits(num);
  }

  words = words.trim();
  if (!words) words = 'Zero';

  let result = words + ' ' + currencyName;

  if (decimalPart > 0) {
    result += ' and ' + convertTwoDigits(decimalPart).trim() + ' Paise';
  }

  return result + ' Only';
}


import html2canvas from 'html2canvas';
import { jsPDF } from 'jspdf';

/**
 * Generates and downloads a professional PDF from a DOM element
 */
export async function generateReceiptPdf(
  elementId: string,
  receiptNumber: string
): Promise<File> {
  const element = document.getElementById(elementId);
  if (!element) {
    throw new Error(`Element with id "${elementId}" not found`);
  }

  // Create canvas with 2x scale for crisp printing
  const canvas = await html2canvas(element, {
    scale: 2,
    useCORS: true,
    logging: false,
    backgroundColor: '#ffffff',
  });

  const imgData = canvas.toDataURL('image/png');
  const imgWidth = 210; // A4 width in mm
  const pageHeight = 297; // A4 height in mm
  const imgHeight = (canvas.height * imgWidth) / canvas.width;

  const pdf = new jsPDF('p', 'mm', 'a4');
  let heightLeft = imgHeight;
  let position = 0;

  // Render centered
  if (imgHeight <= pageHeight) {
    // Single page centered with slight top margin
    const topMargin = Math.max(10, (pageHeight - imgHeight) / 6);
    pdf.addImage(imgData, 'PNG', 0, topMargin, imgWidth, imgHeight);
  } else {
    // Multi-page if receipt is unusually long
    pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
    heightLeft -= pageHeight;

    while (heightLeft >= 0) {
      position = heightLeft - imgHeight;
      pdf.addPage();
      pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
      heightLeft -= pageHeight;
    }
  }

  const filename = `${receiptNumber}.pdf`;
  const blob = pdf.output('blob');
  const file = new File([blob], filename, { type: 'application/pdf' });

  // Trigger download
  pdf.save(filename);

  return file;
}


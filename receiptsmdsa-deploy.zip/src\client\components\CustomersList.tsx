import React, { useState, useEffect } from 'react';
import {
  Users,
  UserPlus,
  Search,
  Phone,
  MapPin,
  FileText,
  Edit2,
  Trash2,
  Plus,
  ArrowRight,
  Receipt as ReceiptIcon,
  X,
  Check,
} from 'lucide-react';
import { Customer, Receipt, Settings } from '../types';
import { COUNTRY_CODES } from '../utils/whatsappHelper';

interface Props {
  settings: Partial<Settings>;
  onCreateReceiptForCustomer: (customer: Customer) => void;
  onViewReceipt: (receipt: Receipt) => void;
}

export const CustomersList: React.FC<Props> = ({
  settings,
  onCreateReceiptForCustomer,
  onViewReceipt,
}) => {
  const currency = settings.currency_symbol || '₹';

  const [customers, setCustomers] = useState<Customer[]>([]);
  const [search, setSearch] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(true);

  // Modal state for Add/Edit
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
  const [editingCustomer, setEditingCustomer] = useState<Customer | null>(null);
  const [name, setName] = useState<string>('');
  const [countryCode, setCountryCode] = useState<string>('+91');
  const [phoneDigits, setPhoneDigits] = useState<string>('');
  const [email, setEmail] = useState<string>('');
  const [address, setAddress] = useState<string>('');
  const [notes, setNotes] = useState<string>('');
  const [formError, setFormError] = useState<string | null>(null);

  // Selected customer for history view
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);
  const [customerReceipts, setCustomerReceipts] = useState<Receipt[]>([]);
  const [loadingReceipts, setLoadingReceipts] = useState<boolean>(false);

  const fetchCustomers = async () => {
    setLoading(true);
    try {
      const res = await fetch(`/api/customers?search=${encodeURIComponent(search)}`);
      const data = await res.json();
      if (Array.isArray(data)) setCustomers(data);
    } catch (err) {
      console.error('Failed to fetch customers:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCustomers();
  }, [search]);

  // Load customer receipt history
  const loadCustomerHistory = async (cust: Customer) => {
    setSelectedCustomer(cust);
    setLoadingReceipts(true);
    try {
      const res = await fetch(`/api/customers/${cust.id}`);
      const data = await res.json();
      if (data.receipts) setCustomerReceipts(data.receipts);
    } catch (err) {
      console.error('Failed to load customer receipts:', err);
    } finally {
      setLoadingReceipts(false);
    }
  };

  // Open Add modal
  const handleOpenAdd = () => {
    setEditingCustomer(null);
    setName('');
    setCountryCode('+91');
    setPhoneDigits('');
    setEmail('');
    setAddress('');
    setNotes('');
    setFormError(null);
    setIsModalOpen(true);
  };

  // Open Edit modal
  const handleOpenEdit = (c: Customer, e: React.MouseEvent) => {
    e.stopPropagation();
    setEditingCustomer(c);
    setName(c.name);
    setEmail(c.email || '');
    setAddress(c.address || '');
    setNotes(c.notes || '');
    setFormError(null);

    const phone = c.phone || '';
    let matched = false;
    for (const codeObj of COUNTRY_CODES) {
      if (phone.startsWith(codeObj.code)) {
        setCountryCode(codeObj.code);
        setPhoneDigits(phone.replace(codeObj.code, '').trim());
        matched = true;
        break;
      }
    }
    if (!matched) {
      setPhoneDigits(phone.replace(/[^0-9]/g, ''));
    }

    setIsModalOpen(true);
  };

  // Handle Save
  const handleSaveCustomer = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);

    if (!name.trim() || !phoneDigits.trim()) {
      setFormError('Customer Name and WhatsApp Phone Number are required.');
      return;
    }

    const fullPhone = `${countryCode} ${phoneDigits}`.trim();
    const payload = {
      name: name.trim(),
      phone: fullPhone,
      email: email.trim(),
      address: address.trim(),
      notes: notes.trim(),
    };

    try {
      const url = editingCustomer ? `/api/customers/${editingCustomer.id}` : '/api/customers';
      const method = editingCustomer ? 'PUT' : 'POST';

      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to save customer');
      }

      setIsModalOpen(false);
      fetchCustomers();
    } catch (err: any) {
      setFormError(err.message || 'Error saving customer');
    }
  };

  // Handle Delete
  const handleDeleteCustomer = async (id: number, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!window.confirm('Are you sure you want to delete this customer? Previous receipts will be kept in database.')) {
      return;
    }

    try {
      await fetch(`/api/customers/${id}`, { method: 'DELETE' });
      fetchCustomers();
      if (selectedCustomer?.id === id) {
        setSelectedCustomer(null);
      }
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="space-y-5">
      {/* Top Header */}
      <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
            <Users className="w-5 h-5 text-emerald-600" /> Customer Management
          </h2>
          <p className="text-xs text-slate-500">
            Manage your verified customer contacts, view payment histories and dispatch receipts
          </p>
        </div>

        <button
          type="button"
          onClick={handleOpenAdd}
          className="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold flex items-center justify-center gap-1.5 shadow-sm transition-all"
        >
          <UserPlus className="w-4 h-4" />
          Add New Customer
        </button>
      </div>

      {/* Main Grid: Customer List and Profile History */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5 items-start">
        {/* LEFT 2 COLS: Customers Directory */}
        <div className="lg:col-span-2 bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
          {/* Search Bar */}
          <div className="p-3.5 border-b border-slate-200 bg-slate-50/50">
            <div className="relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search customers by name, phone or address..."
                className="w-full pl-9 pr-3 py-1.5 rounded-lg border border-slate-300 text-xs font-medium focus:outline-none focus:ring-1 focus:ring-emerald-500"
              />
            </div>
          </div>

          {/* Customer Cards List */}
          <div className="divide-y divide-slate-100 max-h-[620px] overflow-y-auto">
            {loading ? (
              <div className="p-8 text-center text-slate-400 text-xs animate-pulse">
                Loading customer directory...
              </div>
            ) : customers.length === 0 ? (
              <div className="p-8 text-center text-slate-400 text-xs">
                No customers found. Click "+ Add New Customer" to register one!
              </div>
            ) : (
              customers.map((c) => {
                const isSelected = selectedCustomer?.id === c.id;
                return (
                  <div
                    key={c.id}
                    onClick={() => loadCustomerHistory(c)}
                    className={`p-4 hover:bg-slate-50 transition-colors cursor-pointer flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
                      isSelected ? 'bg-emerald-50/60 border-l-4 border-emerald-600' : ''
                    }`}
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-sm text-slate-900">{c.name}</span>
                        <span className="text-[10px] bg-slate-100 px-2 py-0.5 rounded text-slate-600 font-semibold">
                          {c.total_receipts || 0} Receipts
                        </span>
                      </div>
                      <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-slate-500 mt-1">
                        <span className="font-mono text-emerald-800 font-semibold">
                          📱 {c.phone}
                        </span>
                        {c.address && <span>📍 {c.address}</span>}
                      </div>
                    </div>

                    <div className="flex items-center justify-between sm:justify-end gap-3 pt-2 sm:pt-0 border-t sm:border-t-0 border-slate-100">
                      {/* Financial info */}
                      <div className="text-left sm:text-right text-xs">
                        <div className="font-mono font-bold text-slate-800">
                          {currency} {Number(c.total_paid || 0).toLocaleString()}
                        </div>
                        {Number(c.total_balance || 0) > 0 && (
                          <div className="text-[10px] text-rose-600 font-semibold">
                            Due: {currency} {Number(c.total_balance).toLocaleString()}
                          </div>
                        )}
                      </div>

                      {/* Actions */}
                      <div className="flex items-center gap-1.5" onClick={(e) => e.stopPropagation()}>
                        <button
                          type="button"
                          onClick={() => onCreateReceiptForCustomer(c)}
                          className="px-2.5 py-1 rounded-lg bg-emerald-100/70 hover:bg-emerald-200 text-emerald-800 text-[11px] font-bold transition-colors"
                          title="Create Receipt"
                        >
                          + Receipt
                        </button>
                        <button
                          type="button"
                          onClick={(e) => handleOpenEdit(c, e)}
                          className="p-1 rounded text-slate-400 hover:text-blue-600 transition-colors"
                          title="Edit"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={(e) => handleDeleteCustomer(c.id, e)}
                          className="p-1 rounded text-slate-400 hover:text-rose-600 transition-colors"
                          title="Delete"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* RIGHT COL: Customer Receipts History Panel */}
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-4 sm:p-5 flex flex-col justify-between">
          {selectedCustomer ? (
            <div className="space-y-4">
              <div className="border-b pb-3 border-slate-200 flex items-start justify-between">
                <div>
                  <h3 className="font-bold text-base text-slate-900">{selectedCustomer.name}</h3>
                  <p className="text-xs font-mono text-emerald-700 font-medium">
                    {selectedCustomer.phone}
                  </p>
                  {selectedCustomer.address && (
                    <p className="text-xs text-slate-500 mt-1">📍 {selectedCustomer.address}</p>
                  )}
                </div>
                <button
                  type="button"
                  onClick={() => onCreateReceiptForCustomer(selectedCustomer)}
                  className="px-3 py-1.5 bg-emerald-600 text-white rounded-lg text-xs font-bold hover:bg-emerald-700 transition-colors shadow-sm"
                >
                  New Receipt
                </button>
              </div>

              {/* Financial summary banner */}
              <div className="grid grid-cols-2 gap-2 bg-slate-50 p-2.5 rounded-xl border border-slate-200 text-center text-xs">
                <div>
                  <span className="text-[10px] text-slate-400 uppercase font-semibold block">Total Paid</span>
                  <span className="font-mono font-bold text-slate-800 text-sm">
                    {currency} {Number(selectedCustomer.total_paid || 0).toLocaleString()}
                  </span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-400 uppercase font-semibold block">Pending Balance</span>
                  <span className={`font-mono font-bold text-sm ${Number(selectedCustomer.total_balance || 0) > 0 ? 'text-rose-600' : 'text-slate-800'}`}>
                    {currency} {Number(selectedCustomer.total_balance || 0).toLocaleString()}
                  </span>
                </div>
              </div>

              {/* Receipts list */}
              <div>
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-2">
                  Issued Receipts ({customerReceipts.length})
                </h4>

                {loadingReceipts ? (
                  <div className="text-xs text-slate-400 py-4 text-center animate-pulse">
                    Loading receipts...
                  </div>
                ) : customerReceipts.length === 0 ? (
                  <div className="text-xs text-slate-400 py-6 text-center">
                    No receipts issued yet for this customer.
                  </div>
                ) : (
                  <div className="space-y-2 max-h-[400px] overflow-y-auto pr-1">
                    {customerReceipts.map((r) => (
                      <div
                        key={r.id}
                        onClick={() => onViewReceipt(r)}
                        className="p-2.5 rounded-xl border border-slate-200 hover:border-emerald-500 bg-white hover:bg-emerald-50/30 transition-all cursor-pointer flex items-center justify-between text-xs"
                      >
                        <div>
                          <span className="font-mono font-bold text-slate-900 block">
                            {r.receipt_number}
                          </span>
                          <span className="text-[11px] text-slate-400">{r.receipt_date}</span>
                        </div>
                        <div className="text-right">
                          <span className="font-mono font-bold text-slate-800 block">
                            {currency} {Number(r.amount).toLocaleString()}
                          </span>
                          <span className={`text-[10px] font-bold ${
                            r.payment_status === 'Paid' ? 'text-emerald-700' : 'text-amber-700'
                          }`}>
                            {r.payment_status}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          ) : (
            <div className="py-16 text-center text-slate-400 text-xs">
              <Users className="w-8 h-8 mx-auto mb-2 opacity-30" />
              <p className="font-semibold">Select a customer from the list</p>
              <p className="text-[11px] text-slate-400 mt-1">
                View all past receipts and outstanding balance breakdown
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Add / Edit Customer Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-fadeIn">
          <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full overflow-hidden border border-slate-100">
            <div className="bg-emerald-600 text-white p-4 flex items-center justify-between">
              <h3 className="font-bold text-base">
                {editingCustomer ? 'Edit Customer' : 'Add New Customer'}
              </h3>
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="w-7 h-7 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveCustomer} className="p-5 space-y-4 text-xs sm:text-sm">
              {formError && (
                <div className="p-2.5 rounded-lg bg-rose-50 border border-rose-200 text-rose-700 text-xs">
                  {formError}
                </div>
              )}

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Full Customer Name <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Amina Farooq"
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-300 font-medium focus:outline-none focus:ring-1 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  WhatsApp Number <span className="text-rose-500">*</span>
                </label>
                <div className="flex gap-2">
                  <select
                    value={countryCode}
                    onChange={(e) => setCountryCode(e.target.value)}
                    className="w-24 py-2 px-1.5 rounded-xl border border-slate-300 text-xs font-medium bg-slate-50"
                  >
                    {COUNTRY_CODES.map((c) => (
                      <option key={c.code} value={c.code}>
                        {c.code}
                      </option>
                    ))}
                  </select>
                  <input
                    type="tel"
                    required
                    value={phoneDigits}
                    onChange={(e) => setPhoneDigits(e.target.value)}
                    placeholder="e.g. 97455 67890"
                    className="flex-1 px-3.5 py-2 rounded-xl border border-slate-300 font-mono font-medium focus:outline-none focus:ring-1 focus:ring-emerald-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Email Address <span className="text-slate-400 font-normal">(Optional)</span>
                </label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="e.g. amina@example.com"
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-300 font-medium focus:outline-none focus:ring-1 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Address / City <span className="text-slate-400 font-normal">(Optional)</span>
                </label>
                <input
                  type="text"
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  placeholder="e.g. Green Valley, Ernakulam"
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-300 font-medium focus:outline-none focus:ring-1 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Internal Notes <span className="text-slate-400 font-normal">(Optional)</span>
                </label>
                <textarea
                  rows={2}
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="e.g. Preferred contact time in morning"
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-300 font-medium focus:outline-none focus:ring-1 focus:ring-emerald-500"
                />
              </div>

              <div className="pt-3 border-t border-slate-200 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-xl border border-slate-300 text-slate-600 font-semibold hover:bg-slate-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold"
                >
                  {editingCustomer ? 'Update Customer' : 'Save Customer'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};


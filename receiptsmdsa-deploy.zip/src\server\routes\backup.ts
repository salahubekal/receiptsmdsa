import { Router } from 'express';
import fs from 'fs';
import path from 'path';
import { db } from '../db/index.js';

const router = Router();
const BACKUPS_DIR = path.resolve(process.cwd(), 'data', 'backups');

// GET /api/backup/export - Full JSON database snapshot
router.get('/export', (req, res) => {
  try {
    const customers = db.prepare('SELECT * FROM customers').all();
    const receipts = db.prepare('SELECT * FROM receipts').all();
    const auditLogs = db.prepare('SELECT * FROM receipt_audit_logs').all();
    const settings = db.prepare('SELECT * FROM settings').all();

    const backupPayload = {
      version: '1.0.0',
      exportedAt: new Date().toISOString(),
      metadata: {
        totalCustomers: customers.length,
        totalReceipts: receipts.length,
        totalAuditLogs: auditLogs.length,
      },
      customers,
      receipts,
      auditLogs,
      settings,
    };

    // Save automatic local file snapshot
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const autoFile = path.join(BACKUPS_DIR, `receipts-backup-${timestamp}.json`);
    fs.writeFileSync(autoFile, JSON.stringify(backupPayload, null, 2), 'utf-8');

    res.setHeader('Content-Type', 'application/json');
    res.setHeader('Content-Disposition', `attachment; filename=receipts-backup-${timestamp}.json`);
    res.send(JSON.stringify(backupPayload, null, 2));
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/backup/list - List automated backups
router.get('/list', (req, res) => {
  try {
    if (!fs.existsSync(BACKUPS_DIR)) {
      return res.json([]);
    }

    const files = fs.readdirSync(BACKUPS_DIR)
      .filter(f => f.endsWith('.json') || f.endsWith('.db'))
      .map(file => {
        const fullPath = path.join(BACKUPS_DIR, file);
        const stats = fs.statSync(fullPath);
        return {
          filename: file,
          sizeBytes: stats.size,
          createdAt: stats.birthtime,
          modifiedAt: stats.mtime,
        };
      })
      .sort((a, b) => new Date(b.modifiedAt).getTime() - new Date(a.modifiedAt).getTime());

    res.json(files);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/backup/restore - Restore from JSON backup payload
router.post('/restore', (req, res) => {
  const { customers, receipts, settings } = req.body;

  if (!Array.isArray(customers) || !Array.isArray(receipts)) {
    return res.status(400).json({ error: 'Invalid backup file structure. "customers" and "receipts" arrays required.' });
  }

  try {
    const restoreTx = db.transaction(() => {
      // Clear current data
      db.prepare('DELETE FROM receipt_audit_logs').run();
      db.prepare('DELETE FROM receipts').run();
      db.prepare('DELETE FROM customers').run();

      // Restore customers
      const insertCustomer = db.prepare(`
        INSERT INTO customers (id, name, phone, email, address, notes, created_at, updated_at)
        VALUES (@id, @name, @phone, @email, @address, @notes, @created_at, @updated_at)
      `);
      for (const c of customers) {
        insertCustomer.run(c);
      }

      // Restore receipts
      const insertReceipt = db.prepare(`
        INSERT INTO receipts (
          id, receipt_number, receipt_date, customer_id, customer_name, customer_phone,
          customer_address, description, amount, payment_method, transaction_id,
          payment_status, paid_amount, balance_amount, remarks, items_json, whatsapp_status,
          whatsapp_sent_at, created_at, updated_at
        ) VALUES (
          @id, @receipt_number, @receipt_date, @customer_id, @customer_name, @customer_phone,
          @customer_address, @description, @amount, @payment_method, @transaction_id,
          @payment_status, @paid_amount, @balance_amount, @remarks, @items_json, @whatsapp_status,
          @whatsapp_sent_at, @created_at, @updated_at
        )
      `);
      for (const r of receipts) {
        insertReceipt.run(r);
      }

      // Restore settings if present
      if (Array.isArray(settings)) {
        const insertSetting = db.prepare('INSERT OR REPLACE INTO settings (key, value) VALUES (@key, @value)');
        for (const s of settings) {
          insertSetting.run(s);
        }
      }

      // Add audit log for restore
      db.prepare(`
        INSERT INTO receipt_audit_logs (receipt_id, receipt_number, action, changed_fields, performed_by)
        VALUES (0, 'SYSTEM', 'RESTORE_DATABASE', ?, 'Admin')
      `).run(`Database restored with ${customers.length} customers and ${receipts.length} receipts.`);
    });

    restoreTx();

    res.json({
      success: true,
      message: `Database restored successfully. Restored ${customers.length} customers and ${receipts.length} receipts.`,
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

export default router;


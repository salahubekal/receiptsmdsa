import React, { useState, useEffect } from 'react';
import {
  GraduationCap,
  FileText,
  Download,
  Eye,
  LogOut,
  Calendar,
  CreditCard,
  CheckCircle,
  Clock,
  AlertCircle,
  Phone,
  Mail,
  MapPin,
  MessageSquare,
  ShieldCheck,
  PlusCircle,
  Search,
  Share2,
  RefreshCw,
  Sparkles,
  Lock,
  ArrowRight,
  Send,
  X,
  FileCheck,
  Check,
  Shield,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { Receipt, Settings, PaymentRecord } from '../types';
import { useAuth } from '../context/AuthContext';
import { DigitalReceiptTemplate } from './DigitalReceiptTemplate';
import { ReceiptPreviewModal } from './ReceiptPreviewModal';
import { WhatsAppShareModal } from './WhatsAppShareModal';
import { UltraProFooter } from './UltraProFooter';
import { ForcePasswordChangeModal } from './ForcePasswordChangeModal';
import { generateReceiptPdf } from '../utils/pdfGenerator';
import { generateReceiptImage } from '../utils/imageGenerator';
import { numberToWords } from '../utils/numberToWords';
import { COUNTRY_CODES, formatPhoneNumberForWhatsApp } from '../utils/whatsappHelper';
import { playNotificationChime } from '../utils/soundHelper';

interface Props {
  settings: Partial<Settings>;
  onLogout: () => void;
}

export const StudentPortal: React.FC<Props> = ({ settings, onLogout }) => {
  const { token, user } = useAuth();
  const currency = settings.currency_symbol || '₹';

  const [studentData, setStudentData] = useState<any>(null);
  const [summary, setSummary] = useState<any>({
    todayCollection: 0,
    totalCollection: 0,
    todayPayments: 0,
    totalReceipts: 0,
  });
  const [payments, setPayments] = useState<PaymentRecord[]>([]);
  const [receipts, setReceipts] = useState<Receipt[]>([]);
  const [loading, setLoading] = useState<boolean>(true);

  // Group & Location assignment state
  const [groupMembers, setGroupMembers] = useState<any[]>([]);
  const [locationId, setLocationId] = useState<number | null>(null);
  const [locationName, setLocationName] = useState<string>('');
  const [isGroupCollection, setIsGroupCollection] = useState<boolean>(false);
  const [collectingMemberName, setCollectingMemberName] = useState<string>('');
  const [collectingMemberPhone, setCollectingMemberPhone] = useState<string>('');
  const [forceChangePasswordOpen, setForceChangePasswordOpen] = useState<boolean>(false);
  const [liveStudentAlert, setLiveStudentAlert] = useState<any>(null);

  // View state: 'form' | 'history'
  const [activeView, setActiveView] = useState<'form' | 'history'>('form');

  // Modals state
  const [previewReceipt, setPreviewReceipt] = useState<Receipt | null>(null);
  const [whatsappReceipt, setWhatsappReceipt] = useState<Receipt | null>(null);
  const [isExporting, setIsExporting] = useState<number | null>(null);

  // Form state for CREATE NEW PAYMENT RECEIPT
  const [autoReceiptNumber, setAutoReceiptNumber] = useState<string>('');
  const [isCustomReceiptNo, setIsCustomReceiptNo] = useState<boolean>(false);
  const [paymentDate, setPaymentDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [payerName, setPayerName] = useState<string>('');
  const [countryCode, setCountryCode] = useState<string>('+91');
  const [payerPhoneDigits, setPayerPhoneDigits] = useState<string>('');
  const [amount, setAmount] = useState<string>('');
  const [paymentPurpose, setPaymentPurpose] = useState<string>('Annual Membership Contribution');
  const [customPurpose, setCustomPurpose] = useState<string>('');
  const [paymentMethod, setPaymentMethod] = useState<string>('Cash');
  const [transactionRef, setTransactionRef] = useState<string>('');
  const [remarks, setRemarks] = useState<string>('');
  const [formErrors, setFormErrors] = useState<{ [key: string]: string }>({});
  const [submitting, setSubmitting] = useState<boolean>(false);
  const [successReceipt, setSuccessReceipt] = useState<Receipt | null>(null);

  // Filter state for history
  const [historySearch, setHistorySearch] = useState<string>('');
  const [statusFilter, setStatusFilter] = useState<string>('All');

  // Fetch student dashboard data
  const fetchStudentDashboard = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/student/dashboard', {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      const data = await res.json();
      if (res.ok) {
        setStudentData(data.student);
        if (data.student?.must_change_password) {
          setForceChangePasswordOpen(true);
        }
        if (data.student?.location_id) {
          setLocationId(data.student.location_id);
          setLocationName(data.student.location_name || '');
        }
        if (data.student?.group_id) {
          setIsGroupCollection(true);
        }
        if (data.groupMembers) {
          setGroupMembers(data.groupMembers);
        }
        setSummary(data.summary || {
          todayCollection: 0,
          totalCollection: 0,
          todayPayments: 0,
          totalReceipts: 0,
        });
        setPayments(data.payments || []);
        setReceipts(data.receipts || []);
      }
    } catch (err) {
      console.error('Failed to load student dashboard:', err);
    } finally {
      setLoading(false);
    }
  };

  // Fetch next receipt number
  const fetchNextReceiptNumber = async () => {
    try {
      const res = await fetch('/api/payments/next-number');
      const data = await res.json();
      if (data?.nextNumber) {
        setAutoReceiptNumber(data.nextNumber);
      }
    } catch (err) {
      console.error('Failed to get next receipt number:', err);
    }
  };

  useEffect(() => {
    fetchStudentDashboard();
    fetchNextReceiptNumber();

    // Universal live real-time connection across Chrome, Edge, Safari, Mobile
    const eventSource = new EventSource('/api/realtime/stream');
    eventSource.onmessage = (event) => {
      try {
        const payload = JSON.parse(event.data);
        if (payload.type === 'PAYMENT_VERIFIED') {
          playNotificationChime('verified');
          confetti({ particleCount: 50, spread: 70, origin: { y: 0.7 } });
          setLiveStudentAlert({
            title: 'Payment Verified by Admin!',
            icon: '🛡️',
            message: `Receipt #${payload.receiptNumber} has been verified by ${payload.verifiedBy}!`,
            timestamp: new Date().toLocaleTimeString(),
          });
          fetchStudentDashboard();
        } else if (payload.type === 'NEW_PAYMENT' || payload.type === 'GROUP_UPDATED' || payload.type === 'MEMBER_ADDED') {
          fetchStudentDashboard();
        }
      } catch (e) {
        console.error('Student live stream parse error:', e);
      }
    };

    return () => {
      eventSource.close();
    };
  }, [token]);

  // Handle Form Validation
  const validateForm = () => {
    const errors: { [key: string]: string } = {};
    if (!payerName.trim()) {
      errors.payerName = 'Customer / Payer Name is required.';
    }
    const cleanPhone = payerPhoneDigits.replace(/[^0-9]/g, '');
    if (!cleanPhone || cleanPhone.length < 7) {
      errors.payerPhone = 'Valid WhatsApp phone number is required.';
    }
    const cleanAmount = parseFloat(amount);
    if (isNaN(cleanAmount) || cleanAmount <= 0) {
      errors.amount = 'Please enter a valid amount greater than zero.';
    }
    const finalPurpose = paymentPurpose === 'Other' ? customPurpose.trim() : paymentPurpose;
    if (!finalPurpose) {
      errors.paymentPurpose = 'Payment Purpose is required.';
    }
    if ((paymentMethod === 'UPI' || paymentMethod === 'Bank Transfer') && !transactionRef.trim()) {
      errors.transactionRef = `Transaction Reference is required for ${paymentMethod}.`;
    }
    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  // Build temporary receipt object for previewing
  const buildCurrentReceiptObject = (): Receipt => {
    const finalPurpose = paymentPurpose === 'Other' ? customPurpose.trim() : paymentPurpose;
    const cleanAmount = parseFloat(amount) || 0;
    const fullPhone = `${countryCode} ${payerPhoneDigits.trim()}`;
    const targetGroup = isGroupCollection ? (studentData?.group_id || '') : '';
    const targetGroupName = isGroupCollection ? (studentData?.group_name || '') : '';
    const targetMember = isGroupCollection ? (collectingMemberName || studentData?.name || user?.full_name || '') : (studentData?.name || user?.full_name || '');
    const targetMemberPhone = isGroupCollection ? (collectingMemberPhone || studentData?.phone || '') : (studentData?.phone || '');

    return {
      id: 0,
      receipt_number: autoReceiptNumber || 'MDSA-2026-PREVIEW',
      receipt_date: paymentDate,
      customer_name: payerName.trim() || 'Valued Payer',
      customer_phone: fullPhone,
      student_id: studentData?.student_id || user?.student_id || 'STD-2026-001',
      student_name: studentData?.name || user?.full_name || 'Student Collector',
      group_id: targetGroup,
      group_name: targetGroupName,
      collecting_member_name: targetMember,
      collecting_member_phone: targetMemberPhone,
      location_id: locationId || studentData?.location_id,
      location_name: locationName || studentData?.location_name || '',
      description: finalPurpose || 'Payment Collection',
      amount: cleanAmount,
      payment_method: paymentMethod,
      transaction_id: transactionRef.trim(),
      payment_status: 'Paid',
      verification_status: 'Self-Reported',
      paid_amount: cleanAmount,
      balance_amount: 0,
      remarks: remarks.trim(),
      whatsapp_status: 'Generated',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };
  };

  // Handle Form Submission
  const handleSubmitPayment = async (andShareWhatsApp: boolean = false) => {
    if (!validateForm()) return;
    setSubmitting(true);

    try {
      const finalPurpose = paymentPurpose === 'Other' ? customPurpose.trim() : paymentPurpose;
      const cleanAmount = parseFloat(amount);
      const fullPhone = `${countryCode} ${payerPhoneDigits.trim()}`;
      const targetGroup = isGroupCollection ? (studentData?.group_id || '') : '';
      const targetGroupName = isGroupCollection ? (studentData?.group_name || '') : '';
      const targetMember = isGroupCollection ? (collectingMemberName || studentData?.name || user?.full_name || '') : (studentData?.name || user?.full_name || '');
      const targetMemberPhone = isGroupCollection ? (collectingMemberPhone || studentData?.phone || '') : (studentData?.phone || '');

      const res = await fetch('/api/payments', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          custom_receipt_number: isCustomReceiptNo ? autoReceiptNumber : undefined,
          payer_name: payerName.trim(),
          payer_phone: fullPhone,
          amount: cleanAmount,
          payment_purpose: finalPurpose,
          payment_method: paymentMethod,
          transaction_ref: transactionRef.trim(),
          payment_date: paymentDate,
          remarks: remarks.trim(),
          location_id: locationId || studentData?.location_id || null,
          location_name: locationName || studentData?.location_name || '',
          group_id: targetGroup,
          group_name: targetGroupName,
          collecting_member_name: targetMember,
          collecting_member_phone: targetMemberPhone,
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        setFormErrors({ submit: data.error || 'Failed to save payment.' });
        setSubmitting(false);
        return;
      }

      // Success!
      confetti({
        particleCount: 80,
        spread: 60,
        origin: { y: 0.6 },
      });

      setSuccessReceipt(data.receipt);
      fetchStudentDashboard();
      fetchNextReceiptNumber();

      // Reset form fields
      setPayerName('');
      setPayerPhoneDigits('');
      setAmount('');
      setTransactionRef('');
      setRemarks('');
      setCustomPurpose('');
      setFormErrors({});

      if (andShareWhatsApp && data.receipt) {
        setWhatsappReceipt(data.receipt);
      }
    } catch (err: any) {
      setFormErrors({ submit: err.message || 'Network error while recording payment.' });
    } finally {
      setSubmitting(false);
    }
  };

  const handleDownloadPdf = async (r: Receipt) => {
    setIsExporting(r.id);
    try {
      setPreviewReceipt(r);
      setTimeout(async () => {
        await generateReceiptPdf('preview-receipt-container', r.receipt_number);
        setIsExporting(null);
      }, 350);
    } catch (err) {
      console.error(err);
      setIsExporting(null);
    }
  };

  const handleDownloadImage = async (r: Receipt) => {
    setIsExporting(r.id);
    try {
      setPreviewReceipt(r);
      setTimeout(async () => {
        await generateReceiptImage('preview-receipt-container', r.receipt_number, 'png');
        setIsExporting(null);
      }, 350);
    } catch (err) {
      console.error(err);
      setIsExporting(null);
    }
  };

  // Filtered payments for student's personal history
  const filteredPayments = payments.filter((p) => {
    const term = historySearch.toLowerCase();
    const matchesSearch =
      p.receipt_number.toLowerCase().includes(term) ||
      p.payer_name.toLowerCase().includes(term) ||
      p.payer_phone.includes(term) ||
      p.payment_purpose.toLowerCase().includes(term);

    const matchesStatus =
      statusFilter === 'All' ||
      (statusFilter === 'Verified' && p.verification_status === 'Admin Verified') ||
      (statusFilter === 'Self-Reported' && (p.verification_status === 'Self-Reported' || !p.verification_status)) ||
      (statusFilter === 'Flagged' && p.verification_status === 'Flagged');

    return matchesSearch && matchesStatus;
  });

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans">
      {/* Top Student Header */}
      <header className="bg-gradient-to-r from-purple-900 via-indigo-900 to-blue-900 text-white shadow-lg sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
          <div className="flex items-center gap-3.5">
            <img
              src="/assets/mdsa-logo.png"
              alt="MDSA Logo"
              className="h-11 w-auto object-contain brightness-0 invert drop-shadow"
              onError={(e) => {
                e.currentTarget.src = '/assets/mdsa-logo.svg';
              }}
            />
            <div className="border-l border-white/20 pl-3">
              <span className="text-sm sm:text-base font-black tracking-tight block">
                MDSA DIGITAL RECEIPT PORTAL
              </span>
              <span className="text-[10px] text-purple-200 tracking-wider uppercase block font-semibold">
                Student Payment Collection System
              </span>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="text-right hidden sm:block">
              <span className="text-xs font-bold text-white block">
                {studentData?.name || user?.full_name}
              </span>
              <div className="flex items-center justify-end gap-1.5 mt-0.5">
                <span className="text-[10px] bg-purple-500/30 text-purple-200 border border-purple-400/30 px-2 py-0.5 rounded font-mono font-bold">
                  ID: {studentData?.student_id || user?.student_id || 'STD-2026-001'}
                </span>
                <span className="text-[10px] text-emerald-300 flex items-center gap-1 font-semibold">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                  Active Collector
                </span>
              </div>
            </div>

            <button
              type="button"
              onClick={onLogout}
              className="px-3.5 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-bold flex items-center gap-1.5 transition-colors border border-white/20"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>Sign Out</span>
            </button>
          </div>
        </div>
      </header>

      {/* Real-time Student Live Alert Toast */}
      {liveStudentAlert && (
        <div className="fixed top-4 right-4 sm:top-24 sm:right-6 z-50 max-w-sm sm:max-w-md w-full bg-slate-900/95 backdrop-blur-md text-white rounded-2xl shadow-2xl p-4 border border-purple-500/40 flex items-start justify-between gap-3 animate-scaleUp">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-xl bg-purple-600 flex items-center justify-center flex-shrink-0 mt-0.5 text-lg shadow-md">
              {liveStudentAlert.icon || '🛡️'}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-extrabold text-sm text-purple-300">
                  {liveStudentAlert.title}
                </span>
                <span className="text-[10px] bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded-full font-mono font-bold">
                  {liveStudentAlert.timestamp}
                </span>
              </div>
              <p className="text-xs text-slate-300 mt-1 leading-snug">
                {liveStudentAlert.message}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={() => setLiveStudentAlert(null)}
            className="text-slate-400 hover:text-white p-1"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Main Container */}
      <main className="max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8 flex-1 space-y-6">
        {/* Welcome & Student Collector Banner */}
        <div className="bg-white rounded-3xl p-6 border border-slate-200/80 shadow-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-purple-600 via-indigo-600 to-blue-600 text-white flex items-center justify-center font-bold text-2xl shadow-md flex-shrink-0">
              <GraduationCap className="w-8 h-8" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl font-extrabold text-slate-900">
                  {studentData?.name || user?.full_name}
                </h1>
                <span className="bg-purple-100 text-purple-800 text-[10px] font-bold px-2.5 py-0.5 rounded-full">
                  Authorized Collector
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-0.5 font-medium">
                {studentData?.class_name || 'MDSA Collector Program'} • Student ID:{' '}
                <span className="font-mono font-bold text-purple-700">
                  {studentData?.student_id || user?.student_id || 'STD-2026-001'}
                </span>
              </p>
              <div className="flex flex-wrap items-center gap-x-4 gap-y-1.5 text-xs text-slate-600 mt-2">
                {studentData?.phone && (
                  <span className="flex items-center gap-1 font-mono">
                    <Phone className="w-3 h-3 text-purple-600" /> {studentData.phone}
                  </span>
                )}
                {studentData?.email && (
                  <span className="flex items-center gap-1">
                    <Mail className="w-3 h-3 text-purple-600" /> {studentData.email}
                  </span>
                )}
                {studentData?.location_name && (
                  <span className="flex items-center gap-1 bg-emerald-50 text-emerald-800 border border-emerald-200 px-2.5 py-0.5 rounded-full text-[11px] font-semibold">
                    <MapPin className="w-3 h-3 text-emerald-600" /> {studentData.location_name}
                  </span>
                )}
                {studentData?.group_name && (
                  <span className="flex items-center gap-1 bg-indigo-50 text-indigo-800 border border-indigo-200 px-2.5 py-0.5 rounded-full text-[11px] font-semibold">
                    <Users className="w-3 h-3 text-indigo-600" /> Squad: {studentData.group_name}
                  </span>
                )}
              </div>
            </div>
          </div>

          {/* Quick Navigation Tabs */}
          <div className="flex items-center gap-2 w-full sm:w-auto">
            <button
              type="button"
              onClick={() => setActiveView('form')}
              className={`flex-1 sm:flex-initial px-4 py-2.5 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all ${
                activeView === 'form'
                  ? 'bg-purple-600 text-white shadow-md shadow-purple-600/25'
                  : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
              }`}
            >
              <PlusCircle className="w-4 h-4" />
              <span>Collect Payment</span>
            </button>
            <button
              type="button"
              onClick={() => setActiveView('history')}
              className={`flex-1 sm:flex-initial px-4 py-2.5 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all ${
                activeView === 'history'
                  ? 'bg-purple-600 text-white shadow-md shadow-purple-600/25'
                  : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
              }`}
            >
              <FileText className="w-4 h-4" />
              <span>My History ({payments.length})</span>
            </button>
          </div>
        </div>

        {/* 4 Financial Metric Cards (Requirement 1) */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm hover:border-purple-200 transition-all">
            <span className="text-[11px] font-bold uppercase tracking-wider text-purple-600 block mb-1">
              Today's Collection
            </span>
            <div className="text-2xl sm:text-3xl font-black font-mono text-purple-900">
              {currency} {Number(summary.todayCollection || 0).toLocaleString()}
            </div>
            <span className="text-[11px] text-slate-500 mt-1 block">
              Collected on {paymentDate}
            </span>
          </div>

          <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm hover:border-emerald-200 transition-all">
            <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-600 block mb-1">
              Total Collection
            </span>
            <div className="text-2xl sm:text-3xl font-black font-mono text-emerald-700">
              {currency} {Number(summary.totalCollection || 0).toLocaleString()}
            </div>
            <span className="text-[11px] text-emerald-600 font-medium mt-1 flex items-center gap-1">
              <CheckCircle className="w-3.5 h-3.5" /> All-time collected
            </span>
          </div>

          <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm hover:border-blue-200 transition-all">
            <span className="text-[11px] font-bold uppercase tracking-wider text-blue-600 block mb-1">
              Payments Today
            </span>
            <div className="text-2xl sm:text-3xl font-black font-mono text-slate-900">
              {summary.todayPayments || 0}
            </div>
            <span className="text-[11px] text-slate-500 mt-1 block">
              Transactions today
            </span>
          </div>

          <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm hover:border-indigo-200 transition-all">
            <span className="text-[11px] font-bold uppercase tracking-wider text-indigo-600 block mb-1">
              Total Receipts Issued
            </span>
            <div className="text-2xl sm:text-3xl font-black font-mono text-indigo-700">
              {summary.totalReceipts || 0}
            </div>
            <span className="text-[11px] text-slate-500 mt-1 block">
              Digital receipts generated
            </span>
          </div>
        </div>

        {/* Success Banner if receipt just generated */}
        {successReceipt && (
          <div className="bg-emerald-50 border border-emerald-200 rounded-3xl p-5 shadow-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 animate-scaleUp">
            <div className="flex items-center gap-3.5">
              <div className="w-10 h-10 rounded-2xl bg-emerald-600 text-white flex items-center justify-center flex-shrink-0">
                <Check className="w-6 h-6" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-emerald-950">
                  Payment Recorded & Digital Receipt Generated!
                </h4>
                <p className="text-xs text-emerald-700 mt-0.5">
                  Receipt <span className="font-mono font-bold text-emerald-900">#{successReceipt.receipt_number}</span> for {successReceipt.customer_name} ({currency}{Number(successReceipt.amount).toLocaleString()})
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 w-full sm:w-auto">
              <button
                type="button"
                onClick={() => setPreviewReceipt(successReceipt)}
                className="px-3.5 py-1.5 rounded-xl bg-white hover:bg-emerald-100 text-emerald-900 border border-emerald-200 text-xs font-bold flex items-center gap-1.5"
              >
                <Eye className="w-3.5 h-3.5" />
                <span>View Receipt</span>
              </button>
              <button
                type="button"
                onClick={() => handleDownloadPdf(successReceipt)}
                className="px-3.5 py-1.5 rounded-xl bg-white hover:bg-emerald-100 text-emerald-900 border border-emerald-200 text-xs font-bold flex items-center gap-1.5"
              >
                <Download className="w-3.5 h-3.5" />
                <span>PDF</span>
              </button>
              <button
                type="button"
                onClick={() => setWhatsappReceipt(successReceipt)}
                className="px-3.5 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold flex items-center gap-1.5 shadow"
              >
                <Share2 className="w-3.5 h-3.5" />
                <span>Send WhatsApp</span>
              </button>
              <button
                type="button"
                onClick={() => setSuccessReceipt(null)}
                className="p-1.5 rounded-xl text-emerald-700 hover:bg-emerald-100"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* SECTION 1: CREATE NEW PAYMENT RECEIPT FORM (Requirement 2) */}
        {activeView === 'form' && (
          <div className="bg-white rounded-3xl border border-slate-200/90 shadow-sm overflow-hidden animate-fadeIn">
            <div className="p-5 sm:p-6 border-b border-slate-200 bg-gradient-to-r from-slate-50 to-purple-50/30 flex items-center justify-between">
              <div>
                <h2 className="text-lg font-extrabold text-slate-900 flex items-center gap-2">
                  <PlusCircle className="w-5 h-5 text-purple-600" />
                  CREATE NEW PAYMENT RECEIPT
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Record payments received from contributors, members, or students with automatic MDSA branding
                </p>
              </div>

              <div className="flex items-center gap-2">
                <span className="text-[11px] font-bold text-slate-400 uppercase hidden sm:inline">
                  Receipt No:
                </span>
                <span className="font-mono font-bold text-xs bg-purple-100 text-purple-900 px-3 py-1 rounded-full border border-purple-200">
                  {autoReceiptNumber || 'Loading...'}
                </span>
              </div>
            </div>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleSubmitPayment(false);
              }}
              className="p-5 sm:p-7 space-y-6"
            >
              {formErrors.submit && (
                <div className="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-xs text-rose-700 flex items-start gap-2.5">
                  <AlertCircle className="w-4 h-4 text-rose-600 flex-shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold">Payment Error:</span> {formErrors.submit}
                  </div>
                </div>
              )}

              {/* Row 1: Collector Info (Auto-Filled) & Receipt Number */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 p-4 rounded-2xl bg-purple-50/50 border border-purple-100">
                <div>
                  <label className="text-[11px] font-bold uppercase tracking-wider text-slate-500 block mb-1">
                    Receipt Number
                  </label>
                  <div className="flex items-center gap-1.5">
                    <input
                      type="text"
                      value={autoReceiptNumber}
                      onChange={(e) => setAutoReceiptNumber(e.target.value)}
                      disabled={!isCustomReceiptNo}
                      className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono text-xs font-bold text-purple-900 bg-white focus:outline-none focus:ring-1 focus:ring-purple-600 disabled:bg-purple-100/50 disabled:text-purple-800"
                    />
                    <button
                      type="button"
                      onClick={() => setIsCustomReceiptNo(!isCustomReceiptNo)}
                      title={isCustomReceiptNo ? 'Lock to auto sequence' : 'Edit receipt number'}
                      className="px-2.5 py-2 rounded-xl bg-white border border-slate-300 hover:bg-slate-50 text-slate-600 text-xs font-bold"
                    >
                      {isCustomReceiptNo ? 'Auto' : 'Edit'}
                    </button>
                  </div>
                </div>

                <div>
                  <label className="text-[11px] font-bold uppercase tracking-wider text-slate-500 block mb-1">
                    Student Collector (Auto-Filled)
                  </label>
                  <div className="relative">
                    <input
                      type="text"
                      readOnly
                      value={studentData?.name || user?.full_name || 'Student'}
                      className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-slate-100/80 text-xs font-bold text-slate-700 cursor-not-allowed"
                    />
                    <Lock className="w-3.5 h-3.5 text-slate-400 absolute right-3 top-2.5" />
                  </div>
                </div>

                <div>
                  <label className="text-[11px] font-bold uppercase tracking-wider text-slate-500 block mb-1">
                    Student ID (Auto-Filled)
                  </label>
                  <div className="relative">
                    <input
                      type="text"
                      readOnly
                      value={studentData?.student_id || user?.student_id || 'STD-2026-001'}
                      className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-slate-100/80 font-mono text-xs font-bold text-purple-700 cursor-not-allowed"
                    />
                    <Lock className="w-3.5 h-3.5 text-slate-400 absolute right-3 top-2.5" />
                  </div>
                </div>
              </div>

              {/* Row: Collection Location & Group Squad Assignment (Requirements 10 & 11) */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 p-4 rounded-2xl bg-indigo-50/50 border border-indigo-100">
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">
                    Collection Location / Venue
                  </label>
                  <div className="px-3.5 py-2 rounded-xl border border-slate-300 bg-white text-xs font-semibold text-slate-800 flex items-center gap-2">
                    <MapPin className="w-3.5 h-3.5 text-emerald-600 flex-shrink-0" />
                    <span>{locationName || studentData?.location_name || 'General Campus Counter'}</span>
                  </div>
                </div>

                {studentData?.group_name ? (
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="text-xs font-bold text-slate-700">
                        Collection Mode
                      </label>
                      <span className="text-[10px] text-indigo-700 font-bold bg-indigo-100 px-2 py-0.5 rounded-full">
                        Squad: {studentData.group_name}
                      </span>
                    </div>
                    <select
                      value={isGroupCollection ? 'group' : 'individual'}
                      onChange={(e) => setIsGroupCollection(e.target.value === 'group')}
                      className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-xs font-semibold bg-white text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-600"
                    >
                      <option value="group">Record for Squad: {studentData.group_name}</option>
                      <option value="individual">Record as Personal Student Collection</option>
                    </select>
                  </div>
                ) : (
                  <div>
                    <label className="text-xs font-bold text-slate-700 block mb-1">
                      Collection Unit
                    </label>
                    <div className="px-3.5 py-2 rounded-xl border border-slate-200 bg-slate-100 text-xs font-bold text-slate-600">
                      Individual Collector Account
                    </div>
                  </div>
                )}
              </div>

              {/* If recording for group, select or specify Actual Collecting Member (Requirement 11) */}
              {isGroupCollection && studentData?.group_name && (
                <div className="p-4 rounded-2xl bg-purple-50/60 border border-purple-100 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-extrabold text-purple-900 flex items-center gap-1.5">
                      <Users className="w-4 h-4 text-purple-600" /> Actual Collecting Member in Squad (Requirement 11)
                    </span>
                    <span className="text-[10px] text-purple-700 font-medium">
                      Select or enter the team member who collected the money
                    </span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="text-[11px] font-bold text-slate-600 block mb-1">
                        Collecting Member Name
                      </label>
                      {groupMembers.length > 0 ? (
                        <select
                          value={collectingMemberName || studentData?.name}
                          onChange={(e) => {
                            const selected = groupMembers.find((m) => m.member_name === e.target.value);
                            setCollectingMemberName(e.target.value);
                            if (selected) setCollectingMemberPhone(selected.member_phone);
                          }}
                          className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-xs font-medium bg-white focus:outline-none focus:ring-2 focus:ring-purple-600"
                        >
                          <option value={studentData?.name}>{studentData?.name} (You / Leader)</option>
                          {groupMembers
                            .filter((m) => m.member_name !== studentData?.name)
                            .map((m) => (
                              <option key={m.id} value={m.member_name}>
                                {m.member_name} ({m.member_phone})
                              </option>
                            ))}
                        </select>
                      ) : (
                        <input
                          type="text"
                          value={collectingMemberName}
                          onChange={(e) => setCollectingMemberName(e.target.value)}
                          placeholder="Member name who collected"
                          className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-xs font-medium bg-white"
                        />
                      )}
                    </div>

                    <div>
                      <label className="text-[11px] font-bold text-slate-600 block mb-1">
                        Collecting Member Mobile
                      </label>
                      <input
                        type="tel"
                        value={collectingMemberPhone || studentData?.phone}
                        onChange={(e) => setCollectingMemberPhone(e.target.value)}
                        placeholder="+91 98470 12345"
                        className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-xs font-mono font-medium bg-white"
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* Row 2: Customer / Payer Information */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">
                    Customer / Payer Name <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={payerName}
                    onChange={(e) => {
                      setPayerName(e.target.value);
                      if (formErrors.payerName) setFormErrors({ ...formErrors, payerName: '' });
                    }}
                    placeholder="Enter payer full name"
                    className={`w-full px-3.5 py-2.5 rounded-xl border text-xs font-medium focus:outline-none focus:ring-2 ${
                      formErrors.payerName
                        ? 'border-rose-400 focus:ring-rose-500 bg-rose-50/30'
                        : 'border-slate-300 focus:ring-purple-600'
                    }`}
                  />
                  {formErrors.payerName && (
                    <span className="text-[10px] text-rose-500 font-semibold mt-1 block">
                      {formErrors.payerName}
                    </span>
                  )}
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">
                    Customer WhatsApp Number <span className="text-rose-500">*</span>
                  </label>
                  <div className="flex gap-2">
                    <select
                      value={countryCode}
                      onChange={(e) => setCountryCode(e.target.value)}
                      className="w-28 px-2 py-2.5 rounded-xl border border-slate-300 text-xs font-medium bg-white focus:outline-none focus:ring-2 focus:ring-purple-600"
                    >
                      {COUNTRY_CODES.map((c) => (
                        <option key={c.code} value={c.code}>
                          {c.code} ({c.country.split(' ')[0]})
                        </option>
                      ))}
                    </select>
                    <input
                      type="tel"
                      value={payerPhoneDigits}
                      onChange={(e) => {
                        setPayerPhoneDigits(e.target.value);
                        if (formErrors.payerPhone) setFormErrors({ ...formErrors, payerPhone: '' });
                      }}
                      placeholder="e.g. 98470 12345"
                      className={`flex-1 px-3.5 py-2.5 rounded-xl border text-xs font-mono font-medium focus:outline-none focus:ring-2 ${
                        formErrors.payerPhone
                          ? 'border-rose-400 focus:ring-rose-500 bg-rose-50/30'
                          : 'border-slate-300 focus:ring-purple-600'
                      }`}
                    />
                  </div>
                  {formErrors.payerPhone && (
                    <span className="text-[10px] text-rose-500 font-semibold mt-1 block">
                      {formErrors.payerPhone}
                    </span>
                  )}
                </div>
              </div>

              {/* Row 3: Amount, Date & Payment Method */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">
                    Payment Amount ({currency}) <span className="text-rose-500">*</span>
                  </label>
                  <div className="relative">
                    <span className="absolute left-3.5 top-2.5 text-xs font-bold text-slate-400 font-mono">
                      {currency}
                    </span>
                    <input
                      type="number"
                      step="any"
                      min="1"
                      value={amount}
                      onChange={(e) => {
                        setAmount(e.target.value);
                        if (formErrors.amount) setFormErrors({ ...formErrors, amount: '' });
                      }}
                      placeholder="0.00"
                      className={`w-full pl-8 pr-3.5 py-2.5 rounded-xl border text-xs font-mono font-bold text-slate-900 focus:outline-none focus:ring-2 ${
                        formErrors.amount
                          ? 'border-rose-400 focus:ring-rose-500 bg-rose-50/30'
                          : 'border-slate-300 focus:ring-purple-600'
                      }`}
                    />
                  </div>
                  {/* Real-time Amount in words */}
                  {parseFloat(amount) > 0 && (
                    <span className="text-[10px] text-purple-700 font-semibold italic mt-1 block">
                      Words: {numberToWords(parseFloat(amount))}
                    </span>
                  )}
                  {formErrors.amount && (
                    <span className="text-[10px] text-rose-500 font-semibold mt-1 block">
                      {formErrors.amount}
                    </span>
                  )}
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">
                    Payment Date <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="date"
                    value={paymentDate}
                    onChange={(e) => setPaymentDate(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs font-medium focus:outline-none focus:ring-2 focus:ring-purple-600"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">
                    Payment Method <span className="text-rose-500">*</span>
                  </label>
                  <select
                    value={paymentMethod}
                    onChange={(e) => setPaymentMethod(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs font-semibold text-slate-800 bg-white focus:outline-none focus:ring-2 focus:ring-purple-600"
                  >
                    <option value="Cash">Cash (Physical Currency)</option>
                    <option value="UPI">UPI (Google Pay / PhonePe / Paytm)</option>
                    <option value="Bank Transfer">Bank Transfer / NEFT / IMPS</option>
                    <option value="Cheque">Cheque / Demand Draft</option>
                    <option value="Other">Other Mode</option>
                  </select>
                </div>
              </div>

              {/* Row 4: Purpose & Transaction Ref */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">
                    Payment Purpose / Category <span className="text-rose-500">*</span>
                  </label>
                  <select
                    value={paymentPurpose}
                    onChange={(e) => setPaymentPurpose(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs font-medium bg-white focus:outline-none focus:ring-2 focus:ring-purple-600"
                  >
                    <option value="Annual Membership Contribution">Annual Membership Contribution</option>
                    <option value="Student Welfare Fund">Student Welfare Fund</option>
                    <option value="Conference & Event Registration">Conference & Event Registration</option>
                    <option value="General Charitable Donation">General Charitable Donation</option>
                    <option value="Examination & Certification Fee">Examination & Certification Fee</option>
                    <option value="Publication & Magazine Subscription">Publication & Magazine Subscription</option>
                    <option value="Other">Other (Custom Purpose)</option>
                  </select>

                  {paymentPurpose === 'Other' && (
                    <input
                      type="text"
                      value={customPurpose}
                      onChange={(e) => setCustomPurpose(e.target.value)}
                      placeholder="Specify custom purpose..."
                      className="w-full mt-2 px-3.5 py-2 rounded-xl border border-slate-300 text-xs font-medium focus:outline-none focus:ring-1 focus:ring-purple-600"
                    />
                  )}
                  {formErrors.paymentPurpose && (
                    <span className="text-[10px] text-rose-500 font-semibold mt-1 block">
                      {formErrors.paymentPurpose}
                    </span>
                  )}
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">
                    Transaction Reference Number{' '}
                    {(paymentMethod === 'UPI' || paymentMethod === 'Bank Transfer') && (
                      <span className="text-rose-500">*</span>
                    )}
                  </label>
                  <input
                    type="text"
                    value={transactionRef}
                    onChange={(e) => {
                      setTransactionRef(e.target.value);
                      if (formErrors.transactionRef) setFormErrors({ ...formErrors, transactionRef: '' });
                    }}
                    placeholder={
                      paymentMethod === 'UPI'
                        ? 'e.g. 12-digit UPI UTR number'
                        : paymentMethod === 'Bank Transfer'
                        ? 'e.g. IMPS / NEFT ref number'
                        : 'Optional reference ID'
                    }
                    className={`w-full px-3.5 py-2.5 rounded-xl border text-xs font-mono focus:outline-none focus:ring-2 ${
                      formErrors.transactionRef
                        ? 'border-rose-400 focus:ring-rose-500 bg-rose-50/30'
                        : 'border-slate-300 focus:ring-purple-600'
                    }`}
                  />
                  {formErrors.transactionRef && (
                    <span className="text-[10px] text-rose-500 font-semibold mt-1 block">
                      {formErrors.transactionRef}
                    </span>
                  )}
                </div>
              </div>

              {/* Row 5: Remarks / Notes */}
              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">
                  Additional Remarks / Note (Optional)
                </label>
                <textarea
                  rows={2}
                  value={remarks}
                  onChange={(e) => setRemarks(e.target.value)}
                  placeholder="Optional notes or instructions to be printed on receipt..."
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs font-medium focus:outline-none focus:ring-2 focus:ring-purple-600"
                />
              </div>

              {/* Requirement 2 Action Buttons */}
              <div className="pt-3 border-t border-slate-200 flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center gap-2">
                  {/* Preview Receipt Button */}
                  <button
                    type="button"
                    onClick={() => setPreviewReceipt(buildCurrentReceiptObject())}
                    className="px-4 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold flex items-center gap-1.5 transition-colors"
                  >
                    <Eye className="w-4 h-4 text-slate-500" />
                    <span>Preview Receipt</span>
                  </button>

                  {/* Generate PDF Button */}
                  <button
                    type="button"
                    onClick={() => handleDownloadPdf(buildCurrentReceiptObject())}
                    className="px-4 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold flex items-center gap-1.5 transition-colors"
                  >
                    <Download className="w-4 h-4 text-slate-500" />
                    <span>Generate PDF</span>
                  </button>
                </div>

                <div className="flex items-center gap-2">
                  {/* Send via WhatsApp Button */}
                  <button
                    type="button"
                    onClick={() => handleSubmitPayment(true)}
                    disabled={submitting}
                    className="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold flex items-center gap-1.5 transition-all shadow-md shadow-emerald-600/20 disabled:opacity-50"
                  >
                    <Share2 className="w-4 h-4" />
                    <span>Save & Send WhatsApp</span>
                  </button>

                  {/* Primary Save Payment Button */}
                  <button
                    type="submit"
                    disabled={submitting}
                    className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white text-xs font-extrabold flex items-center gap-2 shadow-lg shadow-purple-600/30 transition-all disabled:opacity-50"
                  >
                    {submitting ? (
                      <>
                        <RefreshCw className="w-4 h-4 animate-spin" />
                        <span>Recording Payment...</span>
                      </>
                    ) : (
                      <>
                        <FileCheck className="w-4 h-4" />
                        <span>Save Payment</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            </form>
          </div>
        )}

        {/* SECTION 2: MY PAYMENT HISTORY TABLE (Requirement 1 & 8) */}
        <div className="bg-white rounded-3xl border border-slate-200/90 shadow-sm overflow-hidden">
          <div className="p-5 border-b border-slate-200 bg-slate-50/50 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
            <div>
              <h2 className="text-base font-extrabold text-slate-900 flex items-center gap-2">
                <FileText className="w-5 h-5 text-purple-600" />
                My Payment Collection Records
              </h2>
              <p className="text-xs text-slate-500">
                All collections recorded by your student account. Real-time verification and WhatsApp tracking.
              </p>
            </div>

            <div className="flex items-center gap-2">
              <div className="relative flex-1 sm:w-64">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="text"
                  value={historySearch}
                  onChange={(e) => setHistorySearch(e.target.value)}
                  placeholder="Search receipt, payer, phone..."
                  className="w-full pl-8 pr-3 py-1.5 rounded-xl border border-slate-300 text-xs font-medium focus:outline-none focus:ring-1 focus:ring-purple-600"
                />
              </div>

              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="px-3 py-1.5 rounded-xl border border-slate-300 text-xs font-medium bg-white text-slate-700"
              >
                <option value="All">All Statuses</option>
                <option value="Verified">Admin Verified</option>
                <option value="Self-Reported">Self-Reported</option>
                <option value="Flagged">Flagged</option>
              </select>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="bg-slate-50 text-slate-500 font-semibold border-b border-slate-200 uppercase tracking-wider text-[11px]">
                  <th className="py-3.5 px-5">Receipt No</th>
                  <th className="py-3.5 px-5">Date</th>
                  <th className="py-3.5 px-5">Customer / Payer</th>
                  <th className="py-3.5 px-5">Purpose</th>
                  <th className="py-3.5 px-5">Payment Method</th>
                  <th className="py-3.5 px-5 text-right">Amount</th>
                  <th className="py-3.5 px-5 text-center">Audit Status</th>
                  <th className="py-3.5 px-5 text-center">WhatsApp</th>
                  <th className="py-3.5 px-5 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {loading ? (
                  <tr>
                    <td colSpan={9} className="py-12 text-center text-slate-400 text-xs">
                      Loading your payment collection records...
                    </td>
                  </tr>
                ) : filteredPayments.length === 0 ? (
                  <tr>
                    <td colSpan={9} className="py-12 text-center text-slate-400 text-xs">
                      No payment records found. Use the form above to record your first payment collection.
                    </td>
                  </tr>
                ) : (
                  filteredPayments.map((p) => {
                    const matchedReceipt = receipts.find(
                      (r) => r.receipt_number === p.receipt_number
                    );
                    const isVerified = p.verification_status === 'Admin Verified';
                    const isFlagged = p.verification_status === 'Flagged';

                    return (
                      <tr key={p.id} className="hover:bg-slate-50/70 transition-colors">
                        <td className="py-4 px-5 font-mono font-bold text-purple-900 whitespace-nowrap">
                          {p.receipt_number}
                        </td>
                        <td className="py-4 px-5 text-slate-500 whitespace-nowrap">
                          {p.payment_date}
                        </td>
                        <td className="py-4 px-5">
                          <span className="font-bold text-slate-900 block">{p.payer_name}</span>
                          <span className="text-[11px] text-slate-500 font-mono">
                            {p.payer_phone}
                          </span>
                        </td>
                        <td className="py-4 px-5 font-medium text-slate-700 max-w-xs">
                          {p.payment_purpose}
                        </td>
                        <td className="py-4 px-5 whitespace-nowrap">
                          <span className="font-semibold text-slate-800 block">
                            {p.payment_method}
                          </span>
                          {p.transaction_ref ? (
                            <span className="text-[10px] text-slate-400 font-mono block">
                              Ref: {p.transaction_ref}
                            </span>
                          ) : (
                            <span className="text-[10px] text-slate-400 italic">No ref</span>
                          )}
                        </td>
                        <td className="py-4 px-5 text-right font-mono font-black text-slate-900 whitespace-nowrap">
                          {currency} {Number(p.amount).toLocaleString()}
                        </td>
                        <td className="py-4 px-5 text-center whitespace-nowrap">
                          <span
                            className={`inline-block px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                              isVerified
                                ? 'bg-emerald-100 text-emerald-800'
                                : isFlagged
                                ? 'bg-rose-100 text-rose-800'
                                : 'bg-amber-100 text-amber-800'
                            }`}
                          >
                            {p.verification_status || 'Self-Reported'}
                          </span>
                          {p.verified_by && (
                            <span className="block text-[9px] text-slate-400 mt-0.5">
                              verified by {p.verified_by}
                            </span>
                          )}
                        </td>
                        <td className="py-4 px-5 text-center whitespace-nowrap">
                          <span
                            className={`inline-block px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                              matchedReceipt?.whatsapp_status === 'Sent'
                                ? 'bg-emerald-100 text-emerald-800'
                                : matchedReceipt?.whatsapp_status === 'Delivered'
                                ? 'bg-blue-100 text-blue-800'
                                : matchedReceipt?.whatsapp_status === 'Failed'
                                ? 'bg-rose-100 text-rose-800'
                                : 'bg-amber-100 text-amber-800'
                            }`}
                          >
                            {matchedReceipt?.whatsapp_status || 'Generated'}
                          </span>
                        </td>
                        <td className="py-4 px-5 text-right whitespace-nowrap">
                          <div className="flex items-center justify-end gap-1.5">
                            {matchedReceipt && (
                              <>
                                <button
                                  type="button"
                                  onClick={() => setPreviewReceipt(matchedReceipt)}
                                  className="px-2.5 py-1.5 rounded-xl bg-purple-50 hover:bg-purple-100 text-purple-800 text-xs font-bold flex items-center gap-1 transition-colors"
                                >
                                  <Eye className="w-3.5 h-3.5" />
                                  <span>View</span>
                                </button>
                                <button
                                  type="button"
                                  onClick={() => handleDownloadPdf(matchedReceipt)}
                                  disabled={isExporting === matchedReceipt.id}
                                  className="px-2.5 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold flex items-center gap-1 transition-colors disabled:opacity-50"
                                >
                                  <Download className="w-3.5 h-3.5" />
                                  <span>PDF</span>
                                </button>
                                <button
                                  type="button"
                                  onClick={() => setWhatsappReceipt(matchedReceipt)}
                                  className="p-1.5 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-700 transition-colors"
                                  title="Share on WhatsApp"
                                >
                                  <Share2 className="w-3.5 h-3.5" />
                                </button>
                              </>
                            )}
                          </div>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* STUDENT PORTAL ULTRA PRO COPYRIGHT BANNER & DEVELOPER SUPPORT */}
        <UltraProFooter mode="student" />
      </main>

      {/* Hidden container for DOM PDF/Image generation */}
      {previewReceipt && (
        <div className="hidden">
          <DigitalReceiptTemplate
            elementId="preview-receipt-container"
            receipt={previewReceipt}
            settings={settings}
          />
        </div>
      )}

      {/* Visual Receipt Preview Modal */}
      <ReceiptPreviewModal
        isOpen={!!previewReceipt}
        receipt={previewReceipt || {}}
        settings={settings}
        onClose={() => setPreviewReceipt(null)}
        onShareRequested={(r) => setWhatsappReceipt(r)}
      />

      {/* WhatsApp Share Modal */}
      {whatsappReceipt && (
        <WhatsAppShareModal
          isOpen={!!whatsappReceipt}
          receipt={whatsappReceipt}
          settings={settings}
          onClose={() => setWhatsappReceipt(null)}
          onStatusUpdated={() => fetchStudentDashboard()}
        />
      )}

      {/* Force Password Change Modal (Requirement 4) */}
      <ForcePasswordChangeModal
        isOpen={forceChangePasswordOpen}
        onSuccess={() => {
          setForceChangePasswordOpen(false);
          fetchStudentDashboard();
        }}
      />
    </div>
  );
};

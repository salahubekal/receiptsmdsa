import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';

export const MDSA3DCanvas: React.FC = () => {
  const mountRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    // SCENE, CAMERA, RENDERER
    const scene = new THREE.Scene();
    const width = container.clientWidth || 500;
    const height = container.clientHeight || 500;

    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000);
    camera.position.set(0, 2.5, 9);
    camera.lookAt(0, 0.2, 0);

    const renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true, powerPreference: 'high-performance' });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.2;

    container.appendChild(renderer.domElement);

    // LIGHTING matching the reference image (Cyan, Violet, Soft White)
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.9);
    scene.add(ambientLight);

    const mainLight = new THREE.DirectionalLight(0xffffff, 1.8);
    mainLight.position.set(5, 10, 7);
    mainLight.castShadow = true;
    scene.add(mainLight);

    const purpleLight = new THREE.PointLight(0xa855f7, 3, 20);
    purpleLight.position.set(-3, 3, 2);
    scene.add(purpleLight);

    const cyanLight = new THREE.PointLight(0x06b6d4, 3, 20);
    cyanLight.position.set(3, -1, 3);
    scene.add(cyanLight);

    // MAIN GROUP FOR ROTATION & HOVER
    const mainGroup = new THREE.Group();
    scene.add(mainGroup);

    // 1. FLOATING STEPPED BASE PLATFORMS (Podium)
    const baseMatBottom = new THREE.MeshPhysicalMaterial({
      color: 0x1e1b4b,
      metalness: 0.8,
      roughness: 0.2,
      reflectivity: 0.9,
      clearcoat: 1.0,
      clearcoatRoughness: 0.1,
    });

    const baseBottomGeom = new THREE.BoxGeometry(4.2, 0.35, 4.2);
    const baseBottom = new THREE.Mesh(baseBottomGeom, baseMatBottom);
    baseBottom.position.y = -1.6;
    baseBottom.receiveShadow = true;
    mainGroup.add(baseBottom);

    const baseMatTop = new THREE.MeshPhysicalMaterial({
      color: 0x312e81,
      metalness: 0.9,
      roughness: 0.15,
      emissive: 0x4f46e5,
      emissiveIntensity: 0.2,
      clearcoat: 1.0,
    });

    const baseTopGeom = new THREE.BoxGeometry(3.4, 0.3, 3.4);
    const baseTop = new THREE.Mesh(baseTopGeom, baseMatTop);
    baseTop.position.y = -1.3;
    baseTop.receiveShadow = true;
    mainGroup.add(baseTop);

    // 2. GLOWING NEON CYAN/PURPLE LIGHT RINGS (Orbiting Platform)
    const ringMat1 = new THREE.MeshBasicMaterial({
      color: 0x38bdf8,
      wireframe: false,
    });
    const ringGeom1 = new THREE.TorusGeometry(2.8, 0.04, 16, 100);
    const ring1 = new THREE.Mesh(ringGeom1, ringMat1);
    ring1.rotation.x = Math.PI / 2;
    ring1.position.y = -1.25;
    mainGroup.add(ring1);

    const ringMat2 = new THREE.MeshBasicMaterial({
      color: 0xc084fc,
      wireframe: false,
    });
    const ringGeom2 = new THREE.TorusGeometry(3.1, 0.03, 16, 100);
    const ring2 = new THREE.Mesh(ringGeom2, ringMat2);
    ring2.rotation.x = Math.PI / 2 + 0.1;
    ring2.position.y = -1.15;
    mainGroup.add(ring2);

    // 3. CENTRAL 3D GLOSSY PURPLE/VIOLET CUBE (The Receipt Vault)
    const cubeMat = new THREE.MeshPhysicalMaterial({
      color: 0x4c1d95,
      emissive: 0x2e1065,
      emissiveIntensity: 0.4,
      metalness: 0.7,
      roughness: 0.2,
      clearcoat: 1.0,
      clearcoatRoughness: 0.1,
      reflectivity: 1.0,
    });

    const cubeGeom = new THREE.BoxGeometry(2.4, 2.4, 2.4);
    const cube = new THREE.Mesh(cubeGeom, cubeMat);
    cube.position.y = 0.1;
    cube.rotation.y = Math.PI / 4;
    cube.castShadow = true;
    cube.receiveShadow = true;
    mainGroup.add(cube);

    // 4. INNER CHAMBER (Top Opening from where receipt emerges)
    const innerOpeningMat = new THREE.MeshBasicMaterial({ color: 0x1e1b4b });
    const innerGeom = new THREE.BoxGeometry(1.8, 0.1, 1.8);
    const innerOpening = new THREE.Mesh(innerGeom, innerOpeningMat);
    innerOpening.position.y = 1.26;
    innerOpening.rotation.y = Math.PI / 4;
    mainGroup.add(innerOpening);

    // 5. 3D FOLDED DIGITAL RECEIPT SHEETS EMERGING
    const receiptGroup = new THREE.Group();
    receiptGroup.position.set(0, 1.2, 0);
    receiptGroup.rotation.y = Math.PI / 4;

    const receiptPaperMat = new THREE.MeshPhysicalMaterial({
      color: 0xf8fafc,
      roughness: 0.3,
      metalness: 0.1,
      clearcoat: 0.5,
    });

    // Lower sheet
    const rGeom1 = new THREE.BoxGeometry(1.3, 1.1, 0.05);
    const rSheet1 = new THREE.Mesh(rGeom1, receiptPaperMat);
    rSheet1.position.set(0, 0.5, 0);
    rSheet1.rotation.x = -0.15;
    receiptGroup.add(rSheet1);

    // Folded top curved sheet with serrated tear styling
    const rGeom2 = new THREE.BoxGeometry(1.3, 0.9, 0.05);
    const rSheet2 = new THREE.Mesh(rGeom2, receiptPaperMat);
    rSheet2.position.set(0, 1.25, -0.15);
    rSheet2.rotation.x = 0.25;
    receiptGroup.add(rSheet2);

    // Receipt printed lines (white/cyan data bars)
    const lineMat = new THREE.MeshBasicMaterial({ color: 0x6366f1 });
    for (let i = 0; i < 4; i++) {
      const lineGeom = new THREE.BoxGeometry(0.8 - i * 0.1, 0.035, 0.06);
      const lineMesh = new THREE.Mesh(lineGeom, lineMat);
      lineMesh.position.set(0, 0.3 + i * 0.2, 0.01);
      rSheet1.add(lineMesh);
    }
    mainGroup.add(receiptGroup);

    // 6. CHROME METALLIC SPHERES FLOATING AROUND
    const sphereMat = new THREE.MeshPhysicalMaterial({
      color: 0xe0e7ff,
      metalness: 0.95,
      roughness: 0.05,
      clearcoat: 1.0,
      reflectivity: 1.0,
    });

    const sphereGeom1 = new THREE.SphereGeometry(0.28, 32, 32);
    const sphere1 = new THREE.Mesh(sphereGeom1, sphereMat);
    sphere1.position.set(-2.4, -0.8, 1.6);
    sphere1.castShadow = true;
    mainGroup.add(sphere1);

    const sphereGeom2 = new THREE.SphereGeometry(0.22, 32, 32);
    const sphere2 = new THREE.Mesh(sphereGeom2, sphereMat);
    sphere2.position.set(2.2, -0.9, 1.8);
    sphere2.castShadow = true;
    mainGroup.add(sphere2);

    // 7. PARTICLES DUST FIELD
    const particleCount = 60;
    const particleGeom = new THREE.BufferGeometry();
    const particlePositions = new Float32Array(particleCount * 3);

    for (let i = 0; i < particleCount * 3; i += 3) {
      particlePositions[i] = (Math.random() - 0.5) * 10;
      particlePositions[i + 1] = Math.random() * 6 - 2;
      particlePositions[i + 2] = (Math.random() - 0.5) * 8;
    }
    particleGeom.setAttribute('position', new THREE.BufferAttribute(particlePositions, 3));

    const particleMat = new THREE.PointsMaterial({
      color: 0x38bdf8,
      size: 0.06,
      transparent: true,
      opacity: 0.7,
      blending: THREE.AdditiveBlending,
    });
    const particles = new THREE.Points(particleGeom, particleMat);
    scene.add(particles);

    // MOUSE PARALLAX INTERACTION
    let mouseX = 0;
    let mouseY = 0;
    let targetX = 0;
    let targetY = 0;

    const onMouseMove = (e: MouseEvent) => {
      const rect = container.getBoundingClientRect();
      const x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      const y = -(((e.clientY - rect.top) / rect.height) * 2 - 1);
      mouseX = x * 0.4;
      mouseY = y * 0.3;
    };

    window.addEventListener('mousemove', onMouseMove);

    // ANIMATION LOOP
    let animationFrameId: number;
    let clock = new THREE.Clock();

    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);
      const elapsedTime = clock.getElapsedTime();

      // Smooth floating motion
      mainGroup.position.y = Math.sin(elapsedTime * 1.5) * 0.12;

      // Gentle continuous rotation
      targetX += (mouseX - targetX) * 0.05;
      targetY += (mouseY - targetY) * 0.05;

      mainGroup.rotation.y = targetX + Math.sin(elapsedTime * 0.6) * 0.08;
      mainGroup.rotation.x = -targetY * 0.5;

      // Light ring slow spin
      ring1.rotation.z = elapsedTime * 0.5;
      ring2.rotation.z = -elapsedTime * 0.35;

      // Chrome spheres floating
      sphere1.position.y = -0.8 + Math.sin(elapsedTime * 2 + 1) * 0.08;
      sphere2.position.y = -0.9 + Math.cos(elapsedTime * 2) * 0.08;

      // Subtle particles slow drift
      particles.rotation.y = elapsedTime * 0.03;

      renderer.render(scene, camera);
    };

    animate();

    // RESIZE LISTENER
    const handleResize = () => {
      if (!container) return;
      const newWidth = container.clientWidth;
      const newHeight = container.clientHeight;
      camera.aspect = newWidth / newHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(newWidth, newHeight);
    };

    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('resize', handleResize);
      renderer.dispose();
      if (container && renderer.domElement) {
        container.removeChild(renderer.domElement);
      }
    };
  }, []);

  return <div ref={mountRef} className="w-full h-full min-h-[460px] relative pointer-events-auto" />;
};


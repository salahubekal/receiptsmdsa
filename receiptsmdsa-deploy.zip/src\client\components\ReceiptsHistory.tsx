import React, { useState, useEffect } from 'react';
import {
  FileText,
  Search,
  Filter,
  Download,
  Share2,
  Eye,
  Edit2,
  Trash2,
  History,
  Calendar,
  CheckCircle,
  Clock,
  AlertCircle,
  X,
  Save,
} from 'lucide-react';
import { Receipt, Settings, AuditLog } from '../types';
import { generateReceiptPdf } from '../utils/pdfGenerator';
import { generateReceiptImage } from '../utils/imageGenerator';

interface Props {
  settings: Partial<Settings>;
  onViewReceipt: (receipt: Receipt) => void;
  onShareWhatsApp: (receipt: Receipt) => void;
}

export const ReceiptsHistory: React.FC<Props> = ({
  settings,
  onViewReceipt,
  onShareWhatsApp,
}) => {
  const currency = settings.currency_symbol || '₹';

  const [receipts, setReceipts] = useState<Receipt[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [totalCount, setTotalCount] = useState<number>(0);

  // Filters
  const [search, setSearch] = useState<string>('');
  const [status, setStatus] = useState<string>('All');
  const [method, setMethod] = useState<string>('All');
  const [startDate, setStartDate] = useState<string>('');
  const [endDate, setEndDate] = useState<string>('');

  // Edit Modal State
  const [isEditModalOpen, setIsEditModalOpen] = useState<boolean>(false);
  const [editingReceipt, setEditingReceipt] = useState<Receipt | null>(null);
  const [editDate, setEditDate] = useState<string>('');
  const [editDescription, setEditDescription] = useState<string>('');
  const [editAmount, setEditAmount] = useState<string>('');
  const [editMethod, setEditMethod] = useState<string>('Cash');
  const [editStatus, setEditStatus] = useState<'Paid' | 'Partially Paid' | 'Pending'>('Paid');
  const [editPaidAmount, setEditPaidAmount] = useState<string>('');
  const [editBalanceAmount, setEditBalanceAmount] = useState<string>('');
  const [editRemarks, setEditRemarks] = useState<string>('');
  const [editError, setEditError] = useState<string | null>(null);

  // Audit Logs Modal State
  const [isAuditModalOpen, setIsAuditModalOpen] = useState<boolean>(false);
  const [selectedAuditReceipt, setSelectedAuditReceipt] = useState<Receipt | null>(null);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  const [loadingAudit, setLoadingAudit] = useState<boolean>(false);

  const fetchReceipts = async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (search) params.append('search', search);
      if (status !== 'All') params.append('status', status);
      if (method !== 'All') params.append('method', method);
      if (startDate) params.append('startDate', startDate);
      if (endDate) params.append('endDate', endDate);

      const res = await fetch(`/api/receipts?${params.toString()}`);
      const data = await res.json();
      if (data.receipts) {
        setReceipts(data.receipts);
        setTotalCount(data.total || 0);
      }
    } catch (err) {
      console.error('Failed to fetch receipts:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchReceipts();
  }, [search, status, method, startDate, endDate]);

  // Open Edit Modal
  const handleOpenEdit = (r: Receipt) => {
    setEditingReceipt(r);
    setEditDate(r.receipt_date);
    setEditDescription(r.description);
    setEditAmount(r.amount.toString());
    setEditMethod(r.payment_method);
    setEditStatus(r.payment_status as any);
    setEditPaidAmount(r.paid_amount.toString());
    setEditBalanceAmount(r.balance_amount.toString());
    setEditRemarks(r.remarks || '');
    setEditError(null);
    setIsEditModalOpen(true);
  };

  // Save Edit (with audit trail recorded)
  const handleSaveEdit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingReceipt) return;
    setEditError(null);

    const amt = parseFloat(editAmount) || 0;
    if (amt <= 0) {
      setEditError('Payment amount must be greater than zero.');
      return;
    }

    const payload = {
      receipt_date: editDate,
      description: editDescription.trim(),
      amount: amt,
      payment_method: editMethod,
      payment_status: editStatus,
      paid_amount: parseFloat(editPaidAmount) || amt,
      balance_amount: parseFloat(editBalanceAmount) || 0,
      remarks: editRemarks.trim(),
      edited_by: 'Administrator',
    };

    try {
      const res = await fetch(`/api/receipts/${editingReceipt.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to update receipt');
      }

      setIsEditModalOpen(false);
      fetchReceipts();
    } catch (err: any) {
      setEditError(err.message || 'Error occurred');
    }
  };

  // Open Audit History Modal
  const handleOpenAudit = async (r: Receipt) => {
    setSelectedAuditReceipt(r);
    setIsAuditModalOpen(true);
    setLoadingAudit(true);
    try {
      const res = await fetch(`/api/receipts/${r.id}`);
      const data = await res.json();
      if (data.auditLogs) {
        setAuditLogs(data.auditLogs);
      }
    } catch (err) {
      console.error('Failed to load audit logs:', err);
    } finally {
      setLoadingAudit(false);
    }
  };

  // Quick preset filters
  const applyDatePreset = (preset: 'today' | 'month' | 'all') => {
    const today = new Date().toISOString().split('T')[0];
    if (preset === 'today') {
      setStartDate(today);
      setEndDate(today);
    } else if (preset === 'month') {
      const firstDay = today.substring(0, 8) + '01';
      setStartDate(firstDay);
      setEndDate(today);
    } else {
      setStartDate('');
      setEndDate('');
    }
  };

  return (
    <div className="space-y-5">
      {/* Top Banner */}
      <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
            <FileText className="w-5 h-5 text-emerald-600" /> Receipt Management & Audit History
          </h2>
          <p className="text-xs text-slate-500">
            Search, filter, download, resend and track full revision logs of every issued receipt
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => applyDatePreset('today')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold border transition-all ${
              startDate && startDate === endDate
                ? 'bg-emerald-600 text-white border-emerald-600'
                : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
            }`}
          >
            Today
          </button>
          <button
            type="button"
            onClick={() => applyDatePreset('month')}
            className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-50 border border-slate-200 text-slate-600 hover:bg-slate-100 transition-all"
          >
            This Month
          </button>
          <button
            type="button"
            onClick={() => applyDatePreset('all')}
            className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-50 border border-slate-200 text-slate-600 hover:bg-slate-100 transition-all"
          >
            All Time
          </button>
        </div>
      </div>

      {/* Filter Toolbar */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-sm grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3 text-xs">
        {/* Search */}
        <div className="relative lg:col-span-2">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search receipt #, customer, phone, purpose..."
            className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-300 font-medium focus:outline-none focus:ring-1 focus:ring-emerald-500"
          />
        </div>

        {/* Status */}
        <div>
          <select
            value={status}
            onChange={(e) => setStatus(e.target.value)}
            className="w-full py-2 px-3 rounded-xl border border-slate-300 font-medium bg-white text-slate-700 focus:outline-none focus:ring-1 focus:ring-emerald-500"
          >
            <option value="All">All Payment Statuses</option>
            <option value="Paid">Paid Full</option>
            <option value="Partially Paid">Partially Paid</option>
            <option value="Pending">Pending</option>
          </select>
        </div>

        {/* Method */}
        <div>
          <select
            value={method}
            onChange={(e) => setMethod(e.target.value)}
            className="w-full py-2 px-3 rounded-xl border border-slate-300 font-medium bg-white text-slate-700 focus:outline-none focus:ring-1 focus:ring-emerald-500"
          >
            <option value="All">All Payment Methods</option>
            <option value="Cash">Cash</option>
            <option value="UPI">UPI</option>
            <option value="Bank Transfer">Bank Transfer</option>
            <option value="Cheque">Cheque</option>
            <option value="Card">Card</option>
          </select>
        </div>

        {/* Date range pickers */}
        <div className="flex gap-2">
          <input
            type="date"
            value={startDate}
            onChange={(e) => setStartDate(e.target.value)}
            className="w-full py-2 px-2 rounded-xl border border-slate-300 font-medium text-slate-700 text-xs"
            title="Start Date"
          />
          <input
            type="date"
            value={endDate}
            onChange={(e) => setEndDate(e.target.value)}
            className="w-full py-2 px-2 rounded-xl border border-slate-300 font-medium text-slate-700 text-xs"
            title="End Date"
          />
        </div>
      </div>

      {/* Receipts History Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs sm:text-sm">
            <thead>
              <tr className="bg-slate-50 text-slate-500 font-semibold border-b border-slate-200 text-xs uppercase tracking-wider">
                <th className="py-3 px-4">Receipt No</th>
                <th className="py-3 px-4">Date</th>
                <th className="py-3 px-4">Customer Name</th>
                <th className="py-3 px-4">Contact</th>
                <th className="py-3 px-4 text-right">Amount</th>
                <th className="py-3 px-4 text-center">Status</th>
                <th className="py-3 px-4 text-center">WhatsApp</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {loading ? (
                <tr>
                  <td colSpan={8} className="py-12 text-center text-slate-400">
                    Loading receipts...
                  </td>
                </tr>
              ) : receipts.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-12 text-center text-slate-400">
                    No receipts found for the selected filters.
                  </td>
                </tr>
              ) : (
                receipts.map((r) => (
                  <tr key={r.id} className="hover:bg-slate-50 transition-colors">
                    <td className="py-3.5 px-4 font-mono font-bold text-slate-900 flex items-center gap-1.5">
                      <FileText className="w-4 h-4 text-emerald-600" />
                      <span>{r.receipt_number}</span>
                    </td>
                    <td className="py-3.5 px-4 text-xs text-slate-500 whitespace-nowrap">
                      {r.receipt_date}
                    </td>
                    <td className="py-3.5 px-4 font-semibold text-slate-800">
                      <div>{r.customer_name}</div>
                      <div className="text-[11px] text-slate-400 font-normal truncate max-w-xs">
                        {r.description}
                      </div>
                    </td>
                    <td className="py-3.5 px-4 font-mono text-xs text-slate-600">
                      {r.customer_phone}
                    </td>
                    <td className="py-3.5 px-4 text-right font-mono font-bold text-slate-900">
                      {currency} {Number(r.amount).toLocaleString()}
                    </td>
                    <td className="py-3.5 px-4 text-center">
                      <span
                        className={`inline-block px-2.5 py-0.5 rounded-full text-[11px] font-bold ${
                          r.payment_status === 'Paid'
                            ? 'bg-emerald-100 text-emerald-800'
                            : r.payment_status === 'Partially Paid'
                            ? 'bg-amber-100 text-amber-800'
                            : 'bg-rose-100 text-rose-800'
                        }`}
                      >
                        {r.payment_status}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 text-center whitespace-nowrap">
                      <span className="text-[11px] bg-slate-100 text-slate-600 px-2.5 py-0.5 rounded-full">
                        {r.whatsapp_status || 'Not Sent'}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 text-right whitespace-nowrap">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          type="button"
                          onClick={() => onViewReceipt(r)}
                          className="p-1.5 rounded-lg text-slate-500 hover:text-slate-900 hover:bg-slate-100"
                          title="View / Print"
                        >
                          <Eye className="w-4 h-4" />
                        </button>
                        <button
                          type="button"
                          onClick={() => onShareWhatsApp(r)}
                          className="p-1.5 rounded-lg text-emerald-600 hover:text-emerald-700 hover:bg-emerald-50"
                          title="Share / Resend on WhatsApp"
                        >
                          <Share2 className="w-4 h-4" />
                        </button>
                        <button
                          type="button"
                          onClick={() => handleOpenAudit(r)}
                          className="p-1.5 rounded-lg text-purple-600 hover:text-purple-700 hover:bg-purple-50"
                          title="View Audit History"
                        >
                          <History className="w-4 h-4" />
                        </button>
                        <button
                          type="button"
                          onClick={() => handleOpenEdit(r)}
                          className="p-1.5 rounded-lg text-blue-600 hover:text-blue-700 hover:bg-blue-50"
                          title="Edit Details"
                        >
                          <Edit2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Edit Receipt Modal */}
      {isEditModalOpen && editingReceipt && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-fadeIn">
          <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full overflow-hidden border border-slate-100">
            <div className="bg-slate-900 text-white p-4 flex items-center justify-between">
              <div>
                <h3 className="font-bold text-sm">Edit Receipt Details</h3>
                <span className="text-xs text-slate-400 font-mono">
                  {editingReceipt.receipt_number} • Customer: {editingReceipt.customer_name}
                </span>
              </div>
              <button
                type="button"
                onClick={() => setIsEditModalOpen(false)}
                className="w-7 h-7 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveEdit} className="p-5 space-y-4 text-xs sm:text-sm">
              <div className="bg-amber-50 border border-amber-200 text-amber-900 p-2.5 rounded-lg text-xs leading-relaxed">
                ℹ️ All modifications are recorded in the permanent audit history to ensure transparency.
              </div>

              {editError && (
                <div className="p-2.5 rounded-lg bg-rose-50 border border-rose-200 text-rose-700 text-xs">
                  {editError}
                </div>
              )}

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Receipt Date</label>
                  <input
                    type="date"
                    required
                    value={editDate}
                    onChange={(e) => setEditDate(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Payment Method</label>
                  <select
                    value={editMethod}
                    onChange={(e) => setEditMethod(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs bg-white"
                  >
                    <option value="Cash">Cash</option>
                    <option value="UPI">UPI</option>
                    <option value="Bank Transfer">Bank Transfer</option>
                    <option value="Cheque">Cheque</option>
                    <option value="Card">Card</option>
                    <option value="Other">Other</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Description / Purpose</label>
                <textarea
                  rows={2}
                  required
                  value={editDescription}
                  onChange={(e) => setEditDescription(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Total Amount ({currency})
                  </label>
                  <input
                    type="number"
                    min="0"
                    step="any"
                    required
                    value={editAmount}
                    onChange={(e) => setEditAmount(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono text-sm"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Payment Status</label>
                  <select
                    value={editStatus}
                    onChange={(e) => setEditStatus(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs bg-white"
                  >
                    <option value="Paid">Paid Full</option>
                    <option value="Partially Paid">Partially Paid</option>
                    <option value="Pending">Pending</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Remarks</label>
                <input
                  type="text"
                  value={editRemarks}
                  onChange={(e) => setEditRemarks(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs"
                />
              </div>

              <div className="pt-3 border-t border-slate-200 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsEditModalOpen(false)}
                  className="px-4 py-2 rounded-xl border border-slate-300 text-slate-600 font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold flex items-center gap-1.5"
                >
                  <Save className="w-4 h-4" /> Save Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Audit History Modal */}
      {isAuditModalOpen && selectedAuditReceipt && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-fadeIn">
          <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full max-h-[85vh] flex flex-col overflow-hidden border border-slate-100">
            <div className="bg-purple-900 text-white p-4 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <History className="w-5 h-5 text-purple-300" />
                <div>
                  <h3 className="font-bold text-sm">Receipt Audit Trail History</h3>
                  <p className="text-xs text-purple-200 font-mono">
                    {selectedAuditReceipt.receipt_number} ({selectedAuditReceipt.customer_name})
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsAuditModalOpen(false)}
                className="w-7 h-7 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-4 sm:p-6 overflow-y-auto space-y-3">
              {loadingAudit ? (
                <div className="text-center py-8 text-xs text-slate-400 animate-pulse">
                  Loading audit trail...
                </div>
              ) : auditLogs.length === 0 ? (
                <div className="text-center py-8 text-xs text-slate-400">
                  No revisions logged for this receipt.
                </div>
              ) : (
                auditLogs.map((log) => (
                  <div
                    key={log.id}
                    className="p-3.5 rounded-xl border border-slate-200 bg-slate-50 text-xs space-y-1.5"
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold px-2 py-0.5 rounded text-[10px] bg-purple-100 text-purple-800">
                        {log.action}
                      </span>
                      <span className="text-slate-400 font-mono text-[11px]">
                        {new Date(log.created_at).toLocaleString()}
                      </span>
                    </div>
                    <div className="text-slate-700">
                      <span className="font-semibold text-slate-900">Performed by: </span>
                      <span>{log.performed_by}</span>
                    </div>
                    {log.changed_fields && (
                      <div className="mt-1 font-mono text-[11px] bg-white p-2 rounded border border-slate-200 text-slate-600 whitespace-pre-wrap break-all">
                        {log.changed_fields}
                      </div>
                    )}
                  </div>
                ))
              )}
            </div>

            <div className="p-3 bg-slate-50 border-t border-slate-200 flex justify-end">
              <button
                type="button"
                onClick={() => setIsAuditModalOpen(false)}
                className="px-4 py-2 rounded-xl bg-slate-800 text-white text-xs font-semibold hover:bg-slate-900"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};


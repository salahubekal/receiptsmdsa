import Database from 'better-sqlite3';
import path from 'path';
import fs from 'fs';
import bcrypt from 'bcryptjs';
import { SCHEMA_SQL } from './schema.js';

const DATA_DIR = path.resolve(process.cwd(), 'data');
const DB_FILE = path.join(DATA_DIR, 'receipts.db');
const BACKUPS_DIR = path.join(DATA_DIR, 'backups');
const RECEIPTS_PDF_DIR = path.join(DATA_DIR, 'receipts_pdf');

// Ensure data, backup, and PDF storage directories exist
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(BACKUPS_DIR)) fs.mkdirSync(BACKUPS_DIR, { recursive: true });
if (!fs.existsSync(RECEIPTS_PDF_DIR)) fs.mkdirSync(RECEIPTS_PDF_DIR, { recursive: true });

export const db = new Database(DB_FILE);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

// Add missing columns if upgrading an existing database before creating indexes
try { db.exec("ALTER TABLE users ADD COLUMN student_id TEXT DEFAULT ''"); } catch {}
try { db.exec("ALTER TABLE users ADD COLUMN customer_id INTEGER DEFAULT NULL"); } catch {}
try { db.exec("ALTER TABLE users ADD COLUMN must_change_password INTEGER DEFAULT 0"); } catch {}
try { db.exec("ALTER TABLE users ADD COLUMN password_changed_at DATETIME DEFAULT NULL"); } catch {}
try { db.exec("ALTER TABLE customers ADD COLUMN student_id TEXT DEFAULT ''"); } catch {}
try { db.exec("ALTER TABLE customers ADD COLUMN class_name TEXT DEFAULT 'MDSA Batch 2026'"); } catch {}
try { db.exec("ALTER TABLE students ADD COLUMN location_id INTEGER DEFAULT NULL"); } catch {}
try { db.exec("ALTER TABLE students ADD COLUMN location_name TEXT DEFAULT ''"); } catch {}
try { db.exec("ALTER TABLE students ADD COLUMN group_id TEXT DEFAULT ''"); } catch {}
try { db.exec("ALTER TABLE students ADD COLUMN group_name TEXT DEFAULT ''"); } catch {}
try { db.exec("ALTER TABLE payments ADD COLUMN location_id INTEGER DEFAULT NULL"); } catch {}
try { db.exec("ALTER TABLE payments ADD COLUMN location_name TEXT DEFAULT ''"); } catch {}
try { db.exec("ALTER TABLE payments ADD COLUMN group_id TEXT DEFAULT ''"); } catch {}
try { db.exec("ALTER TABLE payments ADD COLUMN group_name TEXT DEFAULT ''"); } catch {}
try { db.exec("ALTER TABLE payments ADD COLUMN collecting_member_name TEXT DEFAULT ''"); } catch {}
try { db.exec("ALTER TABLE payments ADD COLUMN collecting_member_phone TEXT DEFAULT ''"); } catch {}
try { db.exec("ALTER TABLE receipts ADD COLUMN student_id TEXT DEFAULT ''"); } catch {}
try { db.exec("ALTER TABLE receipts ADD COLUMN student_name TEXT DEFAULT ''"); } catch {}
try { db.exec("ALTER TABLE receipts ADD COLUMN location_id INTEGER DEFAULT NULL"); } catch {}
try { db.exec("ALTER TABLE receipts ADD COLUMN location_name TEXT DEFAULT ''"); } catch {}
try { db.exec("ALTER TABLE receipts ADD COLUMN group_id TEXT DEFAULT ''"); } catch {}
try { db.exec("ALTER TABLE receipts ADD COLUMN group_name TEXT DEFAULT ''"); } catch {}
try { db.exec("ALTER TABLE receipts ADD COLUMN collecting_member_name TEXT DEFAULT ''"); } catch {}
try { db.exec("ALTER TABLE receipts ADD COLUMN collecting_member_phone TEXT DEFAULT ''"); } catch {}
try { db.exec("ALTER TABLE receipts ADD COLUMN verification_status TEXT DEFAULT 'Self-Reported'"); } catch {}
try { db.exec("ALTER TABLE receipts ADD COLUMN whatsapp_message_id TEXT DEFAULT ''"); } catch {}

// Ensure receipt_audit_logs allows NULL receipt_id for administrative events (student reg, password reset, etc.)
try {
  const auditInfo = db.prepare('PRAGMA table_info(receipt_audit_logs)').all() as any[];
  const rIdCol = auditInfo.find(c => c.name === 'receipt_id');
  if (rIdCol && rIdCol.notnull === 1) {
    db.pragma('foreign_keys = OFF');
    db.exec(`
      CREATE TABLE receipt_audit_logs_temp (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        receipt_id INTEGER NULL,
        receipt_number TEXT NOT NULL,
        action TEXT NOT NULL,
        changed_fields TEXT,
        previous_data TEXT,
        new_data TEXT,
        performed_by TEXT DEFAULT 'Admin',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (receipt_id) REFERENCES receipts(id) ON DELETE SET NULL
      );
      INSERT INTO receipt_audit_logs_temp SELECT * FROM receipt_audit_logs;
      DROP TABLE receipt_audit_logs;
      ALTER TABLE receipt_audit_logs_temp RENAME TO receipt_audit_logs;
    `);
    db.pragma('foreign_keys = ON');
  }
} catch (e) {
  db.pragma('foreign_keys = ON');
}

// Initialize schema (tables, triggers, indexes)
db.exec(SCHEMA_SQL);

// Seed default settings and MDSA branding
export function initDefaults() {
  const getSetting = db.prepare('SELECT value FROM settings WHERE key = ?');
  const setSetting = db.prepare('INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)');

  const defaults: Record<string, any> = {
    'org_name': 'MDSA DIGITAL RECEIPT MANAGEMENT',
    'org_tagline': 'Smart Solutions for a Digital Tomorrow',
    'org_address': 'MDSA Center, Commercial Boulevard, Digital Zone',
    'org_phone': '+91 98470 12345',
    'org_email': 'receipts@mdsa.portal',
    'org_tax_id': 'MDSA-REG-2026',
    'org_reg_no': 'MDSA/ED/2026-90',
    'currency_symbol': '₹',
    'currency_code': 'INR',
    'receipt_prefix': 'MDSA',
    'receipt_start_number': '1001',
    'primary_color': '#6366F1', // Royal Purple / Indigo
    'accent_color': '#3B82F6', // Blue
    'theme_style': 'royal-navy',
    'show_qr_code': 'true',
    'show_signature': 'true',
    'signatory_name': 'MDSA Authorised Signatory',
    'signatory_title': 'Accounts & Digital Receipts Division',
    'signature_image': '',
    'logo_image': '/assets/mdsa-logo.png',
    'terms_and_conditions': '1. This is an official digital receipt generated by MDSA Digital Receipt Management Portal.\n2. Collected through student payment collection terminal and verified digitally.\n3. Retain this digital receipt for all administrative & academic correspondence.',
    'whatsapp_default_message': `Dear [Customer Name],

Thank you for your payment to MDSA.

Please find your official digital payment receipt details below:

📄 *Receipt No:* [Receipt Number]
📅 *Date:* [Date]
💰 *Amount Received:* [Currency][Amount]
💳 *Payment Method:* [Method]
📝 *Purpose:* [Description]
👨‍🎓 *Collected By:* [Student Name] (ID: [Student ID])
📊 *Status:* [Status] ([Verification Status])

Additional Note:
[Additional Message]

You can verify and download your receipt here:
[Receipt Link]

Thank you!
_[Organization Name]_
*Smart Solutions for a Digital Tomorrow*`,
    'whatsapp_cloud_api_phone_id': '',
    'whatsapp_cloud_api_token': '',
    'whatsapp_cloud_api_template': 'receipt_standard',
  };

  const insertMany = db.transaction((defs) => {
    for (const [key, val] of Object.entries(defs)) {
      setSetting.run(key, typeof val === 'string' ? val : JSON.stringify(val));
    }
  });

  insertMany(defaults);

  const hashPassword = (pw: string) => bcrypt.hashSync(pw, bcrypt.genSaltSync(10));

  // Seed default admin accounts
  const insertUser = db.prepare(
    'INSERT OR REPLACE INTO users (username, password_hash, role, full_name, student_id, customer_id) VALUES (?, ?, ?, ?, ?, ?)'
  );

  insertUser.run('admin', hashPassword('admin@receipt2026'), 'admin', 'MDSA Chief Administrator', '', null);
  insertUser.run('mdsa_admin', hashPassword('admin123'), 'admin', 'MDSA Portal Admin', '', null);

  // Seed 4 Registered Student Collectors
  const initialStudents = [
    {
      student_id: 'STD-2026-001',
      username: 'student',
      name: 'Mohammed Rizwan',
      phone: '+91 98470 12345',
      email: 'rizwan@mdsa.org',
      class_name: 'Digital Commerce - Batch A',
    },
    {
      student_id: 'STD-2026-002',
      username: 'STD202602',
      name: 'Amina Farooq',
      phone: '+91 97455 67890',
      email: 'amina@mdsa.org',
      class_name: 'Digital Systems - Batch B',
    },
    {
      student_id: 'STD-2026-003',
      username: 'STD202603',
      name: 'Bilal Ahmed',
      phone: '+91 98460 33445',
      email: 'bilal@mdsa.org',
      class_name: 'Digital Commerce - Batch A',
    },
    {
      student_id: 'STD-2026-004',
      username: 'STD202604',
      name: 'Fatima Zahra',
      phone: '+91 97441 55667',
      email: 'fatima@mdsa.org',
      class_name: 'Information Systems - Batch C',
    },
  ];

  const insertStudent = db.prepare(`
    INSERT OR REPLACE INTO students (student_id, name, phone, email, class_name, total_collected, status)
    VALUES (?, ?, ?, ?, ?, ?, 'Active')
  `);

  for (const s of initialStudents) {
    insertUser.run(s.username, hashPassword('student123'), 'student', s.name, s.student_id, null);
    // Also support username matching the student ID
    if (s.username !== s.student_id) {
      insertUser.run(s.student_id, hashPassword('student123'), 'student', s.name, s.student_id, null);
    }
    insertStudent.run(s.student_id, s.name, s.phone, s.email, s.class_name, 0);
  }

  // Seed sample collection locations if table is empty
  const locCount = db.prepare('SELECT COUNT(*) as count FROM locations').get() as { count: number };
  if (locCount.count === 0) {
    const insertLoc = db.prepare('INSERT INTO locations (location_code, name, city_or_area, description) VALUES (?, ?, ?, ?)');
    insertLoc.run('LOC-2026-001', 'Main Campus - West Gate Center', 'West Campus Zone', 'Primary entrance counter for academic & student contributions');
    insertLoc.run('LOC-2026-002', 'City Center Commercial Hub', 'Downtown District', 'Central commerce & public sponsorship collection point');
    insertLoc.run('LOC-2026-003', 'North Zone Community Hall', 'North District', 'Community outreach center and event hall terminal');
    insertLoc.run('LOC-2026-004', 'Eastern Boulevard Counter', 'East Extension', 'East district collection pavilion');
  }

  // Seed sample collection groups if table is empty
  const groupCount = db.prepare('SELECT COUNT(*) as count FROM groups').get() as { count: number };
  if (groupCount.count === 0) {
    const insertGrp = db.prepare(`
      INSERT INTO groups (group_id, group_name, leader_student_id, leader_name, leader_phone, location_id, location_name, notes, total_collected)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    const insertMember = db.prepare(`
      INSERT INTO group_members (group_id, student_id, member_name, member_phone, role)
      VALUES (?, ?, ?, ?, ?)
    `);

    // Group 1
    const g1 = insertGrp.run(
      'GRP-2026-001',
      'Falcon Squad - Batch A',
      'STD-2026-001',
      'Mohammed Rizwan',
      '+91 98470 12345',
      1,
      'Main Campus - West Gate Center',
      'Main campus student collection team',
      9500
    );
    const g1Id = Number(g1.lastInsertRowid);
    insertMember.run(g1Id, 'STD-2026-001', 'Mohammed Rizwan', '+91 98470 12345', 'Leader');
    insertMember.run(g1Id, '', 'Tariq Mansoor', '+91 98471 11223', 'Member');
    insertMember.run(g1Id, '', 'Salman Farsi', '+91 98472 22334', 'Member');
    insertMember.run(g1Id, '', 'Imran Qureshi', '+91 98473 33445', 'Member');

    // Group 2
    const g2 = insertGrp.run(
      'GRP-2026-002',
      'Pioneer Stars - Batch B',
      'STD-2026-002',
      'Amina Farooq',
      '+91 97455 67890',
      2,
      'City Center Commercial Hub',
      'City center business outreach group',
      12000
    );
    const g2Id = Number(g2.lastInsertRowid);
    insertMember.run(g2Id, 'STD-2026-002', 'Amina Farooq', '+91 97455 67890', 'Leader');
    insertMember.run(g2Id, '', 'Zoya Siddiqui', '+91 97456 44556', 'Member');
    insertMember.run(g2Id, '', 'Mariam Nisar', '+91 97457 55667', 'Member');

    // Update students with assigned group & location
    db.prepare('UPDATE students SET location_id = 1, location_name = ?, group_id = ?, group_name = ? WHERE student_id = ?')
      .run('Main Campus - West Gate Center', 'GRP-2026-001', 'Falcon Squad - Batch A', 'STD-2026-001');
    db.prepare('UPDATE students SET location_id = 2, location_name = ?, group_id = ?, group_name = ? WHERE student_id = ?')
      .run('City Center Commercial Hub', 'GRP-2026-002', 'Pioneer Stars - Batch B', 'STD-2026-002');
    db.prepare('UPDATE students SET location_id = 3, location_name = ? WHERE student_id = ?')
      .run('North Zone Community Hall', 'STD-2026-003');
    db.prepare('UPDATE students SET location_id = 4, location_name = ? WHERE student_id = ?')
      .run('Eastern Boulevard Counter', 'STD-2026-004');
  }

  // Seed sample payments & receipts if table is empty
  const paymentCount = db.prepare('SELECT COUNT(*) as count FROM payments').get() as { count: number };
  if (paymentCount.count === 0) {
    const today = new Date().toISOString().split('T')[0];

    // Seed Payment 1 (Collected by Mohammed Rizwan)
    db.prepare(`
      INSERT INTO payments (
        receipt_number, student_id, student_name, payer_name, payer_phone,
        amount, payment_purpose, payment_method, transaction_ref, payment_date,
        verification_status, verified_by, remarks
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      'MDSA-2026-1001',
      'STD-2026-001',
      'Mohammed Rizwan',
      'Kareem Abdullah',
      '+91 98950 11223',
      4500,
      'Annual Event Registration & Material Kit',
      'UPI',
      'UPI/MDSA/8892019',
      today,
      'Admin Verified',
      'MDSA Chief Administrator',
      'Paid via GPay to student collection terminal'
    );

    // Seed Receipt 1
    db.prepare(`
      INSERT OR REPLACE INTO receipts (
        receipt_number, receipt_date, customer_name, customer_phone, customer_address,
        student_id, student_name, description, amount, payment_method, transaction_id,
        payment_status, verification_status, paid_amount, balance_amount, remarks,
        items_json, whatsapp_status
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      'MDSA-2026-1001',
      today,
      'Kareem Abdullah',
      '+91 98950 11223',
      'North Commercial Block, Calicut',
      'STD-2026-001',
      'Mohammed Rizwan',
      'Annual Event Registration & Material Kit',
      4500,
      'UPI',
      'UPI/MDSA/8892019',
      'Paid',
      'Admin Verified',
      4500,
      0,
      'Verified payment credited to central account',
      JSON.stringify([{ description: 'Annual Event Registration & Kit', quantity: 1, rate: 4500, amount: 4500 }]),
      'Delivered'
    );

    // Seed Payment 2 (Collected by Amina Farooq)
    db.prepare(`
      INSERT INTO payments (
        receipt_number, student_id, student_name, payer_name, payer_phone,
        amount, payment_purpose, payment_method, transaction_ref, payment_date,
        verification_status, verified_by, remarks
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      'MDSA-2026-1002',
      'STD-2026-002',
      'Amina Farooq',
      'Dr. Suhair Mansoor',
      '+91 97455 33441',
      12000,
      'Conference Sponsorship & Delegate Pass',
      'Bank Transfer',
      'NEFT/MDSA/991204',
      today,
      'Self-Reported',
      '',
      'Awaiting bank statement reconciliation'
    );

    // Seed Receipt 2
    db.prepare(`
      INSERT OR REPLACE INTO receipts (
        receipt_number, receipt_date, customer_name, customer_phone, customer_address,
        student_id, student_name, description, amount, payment_method, transaction_id,
        payment_status, verification_status, paid_amount, balance_amount, remarks,
        items_json, whatsapp_status
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      'MDSA-2026-1002',
      today,
      'Dr. Suhair Mansoor',
      '+91 97455 33441',
      'Galaxy Towers, Ernakulam',
      'STD-2026-002',
      'Amina Farooq',
      'Conference Sponsorship & Delegate Pass',
      12000,
      'Bank Transfer',
      'NEFT/MDSA/991204',
      'Paid',
      'Self-Reported',
      12000,
      0,
      'Student self-reported payment collection',
      JSON.stringify([{ description: 'Delegate Pass & Institutional Sponsorship', quantity: 1, rate: 12000, amount: 12000 }]),
      'Sent'
    );

    // Seed Payment 3 (Collected by Bilal Ahmed)
    db.prepare(`
      INSERT INTO payments (
        receipt_number, student_id, student_name, payer_name, payer_phone,
        amount, payment_purpose, payment_method, transaction_ref, payment_date,
        verification_status, verified_by, remarks
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      'MDSA-2026-1003',
      'STD-2026-003',
      'Bilal Ahmed',
      'Zainab Rasheed',
      '+91 98460 77889',
      3500,
      'Special Workshop Registration',
      'Cash',
      'CASH-COLLECT-01',
      today,
      'Self-Reported',
      '',
      'Cash collected in person'
    );

    // Seed Receipt 3
    db.prepare(`
      INSERT OR REPLACE INTO receipts (
        receipt_number, receipt_date, customer_name, customer_phone, customer_address,
        student_id, student_name, description, amount, payment_method, transaction_id,
        payment_status, verification_status, paid_amount, balance_amount, remarks,
        items_json, whatsapp_status
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      'MDSA-2026-1003',
      today,
      'Zainab Rasheed',
      '+91 98460 77889',
      'Manjeri, Malappuram',
      'STD-2026-003',
      'Bilal Ahmed',
      'Special Workshop Registration',
      3500,
      'Cash',
      'CASH-COLLECT-01',
      'Paid',
      'Self-Reported',
      3500,
      0,
      'Cash handed to student coordinator',
      JSON.stringify([{ description: 'Special Skill Workshop Pass', quantity: 1, rate: 3500, amount: 3500 }]),
      'Queued'
    );
  }

  // Update total_collected cache in students table
  db.exec(`
    UPDATE students 
    SET total_collected = (
      SELECT COALESCE(SUM(amount), 0) 
      FROM payments 
      WHERE payments.student_id = students.student_id
    )
  `);
}

initDefaults();

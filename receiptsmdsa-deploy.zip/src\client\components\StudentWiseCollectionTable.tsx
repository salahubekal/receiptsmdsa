import React from 'react';
import {
  GraduationCap,
  Eye,
  RefreshCw,
  Clock,
  TrendingUp,
  Award,
  ArrowRight,
  ShieldCheck,
  CheckCircle,
} from 'lucide-react';
import { StudentStats } from '../types';

interface Props {
  students: StudentStats[];
  loading: boolean;
  currency: string;
  onViewDetails: (studentId: string) => void;
  onRefresh: () => void;
}

export const StudentWiseCollectionTable: React.FC<Props> = ({
  students,
  loading,
  currency,
  onViewDetails,
  onRefresh,
}) => {
  // Calculate aggregate stats across all students
  const totalToday = students.reduce((acc, s) => acc + (Number(s.today_collection) || 0), 0);
  const totalTodayTx = students.reduce((acc, s) => acc + (Number(s.today_transactions) || 0), 0);
  const totalOverall = students.reduce((acc, s) => acc + (Number(s.overall_collection) || 0), 0);

  // Format relative time
  const formatTime = (timeStr?: string) => {
    if (!timeStr) return 'No payments yet';
    try {
      const d = new Date(timeStr);
      return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) + ' (' + d.toLocaleDateString([], { month: 'short', day: 'numeric' }) + ')';
    } catch {
      return timeStr;
    }
  };

  return (
    <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
      {/* Table Top Header */}
      <div className="p-5 sm:p-6 border-b border-slate-200 bg-gradient-to-r from-slate-50 to-purple-50/40 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-purple-600 text-white flex items-center justify-center flex-shrink-0 shadow-md shadow-purple-600/20">
            <GraduationCap className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="font-extrabold text-slate-900 text-base">
                Live Student-Wise Collection Table
              </h3>
              <span className="flex items-center gap-1 bg-emerald-100 text-emerald-800 text-[10px] font-bold px-2 py-0.5 rounded-full">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                LIVE SSE
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              Real-time monitoring of all student collections and daily intake
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs font-bold text-slate-500">
            {students.length} Student Collectors
          </span>
          <button
            type="button"
            onClick={onRefresh}
            disabled={loading}
            className="p-2 rounded-xl bg-white border border-slate-200 hover:bg-slate-50 text-slate-600 text-xs font-bold transition-colors disabled:opacity-50"
            title="Refresh student collections"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin text-purple-600' : ''}`} />
          </button>
        </div>
      </div>

      {/* Table Body */}
      <div className="overflow-x-auto">
        <table className="w-full text-left text-xs sm:text-sm">
          <thead>
            <tr className="bg-slate-50 text-slate-500 font-semibold border-b border-slate-200 text-xs uppercase tracking-wider">
              <th className="py-3.5 px-5">Student Name</th>
              <th className="py-3.5 px-5">Student ID</th>
              <th className="py-3.5 px-5">Location</th>
              <th className="py-3.5 px-5">Group Squad</th>
              <th className="py-3.5 px-5 text-right">Today's Collection</th>
              <th className="py-3.5 px-5 text-center">Tx Today</th>
              <th className="py-3.5 px-5 text-right">Overall Collection</th>
              <th className="py-3.5 px-5">Last Payment Time</th>
              <th className="py-3.5 px-5 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {loading && students.length === 0 ? (
              <tr>
                <td colSpan={7} className="py-12 text-center text-slate-400 text-xs">
                  Loading live student collections...
                </td>
              </tr>
            ) : students.length === 0 ? (
              <tr>
                <td colSpan={7} className="py-12 text-center text-slate-400 text-xs">
                  No student records found in database.
                </td>
              </tr>
            ) : (
              students.map((s, idx) => {
                const isTopPerformer = idx === 0 && Number(s.today_collection) > 0;
                return (
                  <tr key={s.student_id} className="hover:bg-slate-50/70 transition-colors">
                    {/* Student Name */}
                    <td className="py-4 px-5">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-xl bg-purple-100 text-purple-800 font-black text-xs flex items-center justify-center flex-shrink-0">
                          {s.name.substring(0, 1)}
                        </div>
                        <div>
                          <div className="flex items-center gap-1.5">
                            <span className="font-bold text-slate-900">{s.name}</span>
                            {isTopPerformer && (
                              <span
                                title="Top collector today"
                                className="flex items-center gap-0.5 bg-amber-100 text-amber-800 text-[10px] font-bold px-1.5 py-0.2 rounded"
                              >
                                <Award className="w-3 h-3 text-amber-600" />
                                Top
                              </span>
                            )}
                          </div>
                          <span className="text-[11px] text-slate-400 block">
                            {s.class_name || 'MDSA Collector'}
                          </span>
                        </div>
                      </div>
                    </td>

                    {/* Student ID */}
                    <td className="py-4 px-5 font-mono font-bold text-purple-900 text-xs whitespace-nowrap">
                      {s.student_id}
                    </td>

                    {/* Location */}
                    <td className="py-4 px-5">
                      {s.location_name ? (
                        <span className="inline-flex items-center gap-1 bg-emerald-50 text-emerald-800 text-[10px] font-semibold px-2 py-0.5 rounded-full border border-emerald-200">
                          {s.location_name}
                        </span>
                      ) : (
                        <span className="text-slate-400 text-[10px] italic">General</span>
                      )}
                    </td>

                    {/* Group */}
                    <td className="py-4 px-5">
                      {s.group_name ? (
                        <span className="inline-flex items-center gap-1 bg-indigo-50 text-indigo-800 text-[10px] font-semibold px-2 py-0.5 rounded-full border border-indigo-200">
                          {s.group_name}
                        </span>
                      ) : (
                        <span className="text-slate-400 text-[10px] italic">Individual</span>
                      )}
                    </td>

                    {/* Today's Collection */}
                    <td className="py-4 px-5 text-right font-mono font-black text-purple-900 whitespace-nowrap">
                      {currency} {Number(s.today_collection || 0).toLocaleString()}
                    </td>

                    {/* Number of Transactions Today */}
                    <td className="py-4 px-5 text-center whitespace-nowrap">
                      <span
                        className={`inline-block px-2.5 py-0.5 rounded-full text-xs font-bold ${
                          Number(s.today_transactions) > 0
                            ? 'bg-purple-100 text-purple-800'
                            : 'bg-slate-100 text-slate-500'
                        }`}
                      >
                        {s.today_transactions || 0}
                      </span>
                    </td>

                    {/* Overall Collection */}
                    <td className="py-4 px-5 text-right font-mono font-extrabold text-slate-900 whitespace-nowrap">
                      {currency} {Number(s.overall_collection || 0).toLocaleString()}
                    </td>

                    {/* Last Payment Time */}
                    <td className="py-4 px-5 text-xs text-slate-500 whitespace-nowrap">
                      <div className="flex items-center gap-1.5">
                        <Clock className="w-3.5 h-3.5 text-slate-400 flex-shrink-0" />
                        <span>{formatTime(s.last_payment_time)}</span>
                      </div>
                    </td>

                    {/* Action: View Details button */}
                    <td className="py-4 px-5 text-right whitespace-nowrap">
                      <button
                        type="button"
                        onClick={() => onViewDetails(s.student_id)}
                        className="px-3.5 py-1.5 rounded-xl bg-purple-50 hover:bg-purple-100 text-purple-800 text-xs font-bold inline-flex items-center gap-1.5 transition-colors border border-purple-200"
                      >
                        <Eye className="w-3.5 h-3.5" />
                        <span>View Details</span>
                      </button>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>

          {/* Grand Total Footer */}
          {students.length > 0 && (
            <tfoot className="bg-slate-50/90 font-extrabold border-t-2 border-slate-200 text-xs sm:text-sm">
              <tr>
                <td className="py-4 px-5 text-slate-800 uppercase tracking-wider">
                  Grand Total ({students.length} Students)
                </td>
                <td className="py-4 px-5" colSpan={3}></td>
                <td className="py-4 px-5 text-right font-mono text-purple-950 font-black">
                  {currency} {totalToday.toLocaleString()}
                </td>
                <td className="py-4 px-5 text-center font-mono text-purple-950 font-black">
                  {totalTodayTx}
                </td>
                <td className="py-4 px-5 text-right font-mono text-slate-950 font-black">
                  {currency} {totalOverall.toLocaleString()}
                </td>
                <td className="py-4 px-5" colSpan={2}></td>
              </tr>
            </tfoot>
          )}
        </table>
      </div>
    </div>
  );
};


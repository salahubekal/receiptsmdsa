import React, { useState, useEffect } from 'react';
import {
  Database,
  Download,
  Upload,
  RefreshCw,
  CheckCircle,
  AlertCircle,
  FileText,
  Clock,
  HardDrive,
} from 'lucide-react';

export const BackupRestore: React.FC = () => {
  const [backupsList, setBackupsList] = useState<any[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [restoreMessage, setRestoreMessage] = useState<string | null>(null);
  const [restoreError, setRestoreError] = useState<string | null>(null);
  const [isRestoring, setIsRestoring] = useState<boolean>(false);

  const fetchBackups = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/backup/list');
      const data = await res.json();
      if (Array.isArray(data)) setBackupsList(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchBackups();
  }, []);

  // Trigger export download
  const handleExport = () => {
    window.location.href = '/api/backup/export';
    setTimeout(fetchBackups, 1000);
  };

  // Handle restore from JSON file
  const handleRestoreFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!window.confirm('Warning: Restoring this backup will replace current records. Are you sure you want to proceed?')) {
      return;
    }

    setIsRestoring(true);
    setRestoreError(null);
    setRestoreMessage(null);

    const reader = new FileReader();
    reader.onload = async () => {
      try {
        const payload = JSON.parse(reader.result as string);
        const res = await fetch('/api/backup/restore', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload),
        });

        const data = await res.json();
        if (!res.ok) {
          throw new Error(data.error || 'Restore failed');
        }

        setRestoreMessage(data.message || 'Database restored successfully!');
        fetchBackups();
      } catch (err: any) {
        setRestoreError(err.message || 'Invalid backup JSON file');
      } finally {
        setIsRestoring(false);
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="space-y-5">
      {/* Top Banner */}
      <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
            <Database className="w-5 h-5 text-emerald-600" /> Safe Database Storage & Automated Backups
          </h2>
          <p className="text-xs text-slate-500">
            Receipts and customer data are stored persistently in SQLite database (`data/receipts.db`). Export and restore anytime.
          </p>
        </div>

        <button
          type="button"
          onClick={handleExport}
          className="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold flex items-center justify-center gap-1.5 shadow-sm transition-all"
        >
          <Download className="w-4 h-4" />
          Export Database Backup (JSON)
        </button>
      </div>

      {restoreMessage && (
        <div className="p-3.5 bg-emerald-50 border border-emerald-200 text-emerald-900 text-xs rounded-xl flex items-center gap-2 font-semibold">
          <CheckCircle className="w-4 h-4 text-emerald-600 flex-shrink-0" />
          <span>{restoreMessage}</span>
        </div>
      )}

      {restoreError && (
        <div className="p-3.5 bg-rose-50 border border-rose-200 text-rose-900 text-xs rounded-xl flex items-center gap-2 font-semibold">
          <AlertCircle className="w-4 h-4 text-rose-600 flex-shrink-0" />
          <span>{restoreError}</span>
        </div>
      )}

      {/* Grid: Restore Actions & Automated Snapshots */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Restore card */}
        <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm space-y-4">
          <h3 className="font-bold text-sm text-slate-900 flex items-center gap-2">
            <Upload className="w-4 h-4 text-emerald-600" /> Restore From Backup File
          </h3>
          <p className="text-xs text-slate-500 leading-relaxed">
            Select a previously exported `.json` backup file to restore customers, receipts, and settings.
          </p>

          <div className="border-2 border-dashed border-slate-300 rounded-xl p-6 text-center hover:bg-slate-50 transition-colors">
            <HardDrive className="w-8 h-8 text-slate-400 mx-auto mb-2" />
            <input
              type="file"
              accept=".json"
              onChange={handleRestoreFile}
              disabled={isRestoring}
              className="text-xs text-slate-500 file:mr-3 file:py-2 file:px-4 file:rounded-xl file:border-0 file:text-xs file:font-semibold file:bg-emerald-50 file:text-emerald-700 hover:file:bg-emerald-100 cursor-pointer"
            />
            {isRestoring && (
              <span className="text-xs text-emerald-600 font-bold block mt-2 animate-pulse">
                Restoring database records...
              </span>
            )}
          </div>
        </div>

        {/* Automated backups history */}
        <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-sm text-slate-900 flex items-center gap-2">
              <Clock className="w-4 h-4 text-emerald-600" /> Automated Snapshot History
            </h3>
            <button
              type="button"
              onClick={fetchBackups}
              className="p-1 rounded text-slate-400 hover:text-slate-600"
              title="Refresh"
            >
              <RefreshCw className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="divide-y divide-slate-100 max-h-60 overflow-y-auto">
            {loading ? (
              <div className="text-center py-6 text-xs text-slate-400">Loading backups...</div>
            ) : backupsList.length === 0 ? (
              <div className="text-center py-6 text-xs text-slate-400">
                No automated backup files yet. Click "Export Database Backup" to create one now.
              </div>
            ) : (
              backupsList.map((b, i) => (
                <div key={i} className="py-2.5 flex items-center justify-between text-xs">
                  <div>
                    <span className="font-mono font-semibold text-slate-800 block">{b.filename}</span>
                    <span className="text-[10px] text-slate-400">
                      {new Date(b.modifiedAt).toLocaleString()} • {(b.sizeBytes / 1024).toFixed(1)} KB
                    </span>
                  </div>
                  <span className="text-[10px] bg-slate-100 px-2 py-0.5 rounded text-slate-600 font-semibold">
                    Saved
                  </span>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};


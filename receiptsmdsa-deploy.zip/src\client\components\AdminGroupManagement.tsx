import React, { useState, useEffect } from 'react';
import {
  Users,
  PlusCircle,
  Search,
  MapPin,
  Phone,
  Crown,
  Trash2,
  UserPlus,
  CheckCircle,
  AlertCircle,
  X,
  RefreshCw,
  Building,
  UserCheck,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { GroupRecord, LocationRecord, StudentStats, Settings } from '../types';

interface Props {
  settings: Partial<Settings>;
}

export const AdminGroupManagement: React.FC<Props> = ({ settings }) => {
  const currency = settings.currency_symbol || '₹';
  const token = localStorage.getItem('receipt_auth_token');

  const [groups, setGroups] = useState<GroupRecord[]>([]);
  const [locations, setLocations] = useState<LocationRecord[]>([]);
  const [students, setStudents] = useState<StudentStats[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [search, setSearch] = useState<string>('');

  // Modals
  const [isCreateOpen, setIsCreateOpen] = useState<boolean>(false);
  const [selectedGroupForMembers, setSelectedGroupForMembers] = useState<GroupRecord | null>(null);

  // Group Form State
  const [groupName, setGroupName] = useState<string>('');
  const [leaderName, setLeaderName] = useState<string>('');
  const [leaderPhone, setLeaderPhone] = useState<string>('');
  const [leaderStudentId, setLeaderStudentId] = useState<string>('');
  const [locationId, setLocationId] = useState<string>('');
  const [notes, setNotes] = useState<string>('');
  const [initialMembers, setInitialMembers] = useState<{ member_name: string; member_phone: string }[]>([
    { member_name: '', member_phone: '' },
  ]);
  const [formError, setFormError] = useState<string>('');
  const [formLoading, setFormLoading] = useState<boolean>(false);

  // Add Member to Existing Group Modal State
  const [newMemberName, setNewMemberName] = useState<string>('');
  const [newMemberPhone, setNewMemberPhone] = useState<string>('');
  const [memberLoading, setMemberLoading] = useState<boolean>(false);
  const [memberError, setMemberError] = useState<string>('');

  const fetchGroups = async () => {
    setLoading(true);
    try {
      const [grpRes, locRes, stuRes] = await Promise.all([
        fetch('/api/admin/groups', { headers: { Authorization: `Bearer ${token}` } }),
        fetch('/api/admin/locations', { headers: { Authorization: `Bearer ${token}` } }),
        fetch('/api/admin/students', { headers: { Authorization: `Bearer ${token}` } }),
      ]);

      if (grpRes.ok) setGroups(await grpRes.json());
      if (locRes.ok) setLocations(await locRes.json());
      if (stuRes.ok) setStudents(await stuRes.json());
    } catch (err) {
      console.error('Failed to load group management data:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchGroups();
  }, []);

  // Quick autofill when selecting a registered student as leader
  const handleSelectLeaderStudent = (stuId: string) => {
    setLeaderStudentId(stuId);
    const stu = students.find((s) => s.student_id === stuId);
    if (stu) {
      setLeaderName(stu.name);
      setLeaderPhone(stu.phone);
      if (stu.location_id) setLocationId(String(stu.location_id));
    }
  };

  const handleAddMemberField = () => {
    setInitialMembers([...initialMembers, { member_name: '', member_phone: '' }]);
  };

  const handleRemoveMemberField = (idx: number) => {
    setInitialMembers(initialMembers.filter((_, i) => i !== idx));
  };

  const handleMemberChange = (idx: number, field: 'member_name' | 'member_phone', val: string) => {
    const updated = [...initialMembers];
    updated[idx][field] = val;
    setInitialMembers(updated);
  };

  // Submit Create Group
  const handleCreateGroup = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError('');

    if (!groupName.trim() || !leaderName.trim() || !leaderPhone.trim()) {
      setFormError('Group Name, Leader Name, and Leader Mobile Number are required.');
      return;
    }

    // Filter out empty rows
    const cleanedMembers = initialMembers.filter(
      (m) => m.member_name.trim() !== '' && m.member_phone.trim() !== ''
    );

    setFormLoading(true);
    try {
      const res = await fetch('/api/admin/groups', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          group_name: groupName.trim(),
          leader_name: leaderName.trim(),
          leader_phone: leaderPhone.trim(),
          leader_student_id: leaderStudentId.trim(),
          location_id: locationId ? parseInt(locationId, 10) : null,
          notes: notes.trim(),
          members: cleanedMembers,
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        setFormError(data.error || 'Failed to create collection group.');
        setFormLoading(false);
        return;
      }

      confetti({ particleCount: 75, spread: 60, origin: { y: 0.6 } });
      setIsCreateOpen(false);
      fetchGroups();

      // Reset form
      setGroupName('');
      setLeaderName('');
      setLeaderPhone('');
      setLeaderStudentId('');
      setLocationId('');
      setNotes('');
      setInitialMembers([{ member_name: '', member_phone: '' }]);
    } catch (err: any) {
      setFormError(err.message || 'Error creating group.');
    } finally {
      setFormLoading(false);
    }
  };

  // Add member to existing group
  const handleAddMemberToGroup = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedGroupForMembers) return;
    setMemberError('');

    if (!newMemberName.trim() || !newMemberPhone.trim()) {
      setMemberError('Member Name and Mobile Number are required.');
      return;
    }

    setMemberLoading(true);
    try {
      const res = await fetch(`/api/admin/groups/${selectedGroupForMembers.id}/members`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          member_name: newMemberName.trim(),
          member_phone: newMemberPhone.trim(),
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        setMemberError(data.error || 'Failed to add member.');
        setMemberLoading(false);
        return;
      }

      setNewMemberName('');
      setNewMemberPhone('');
      fetchGroups();

      // Update current modal state
      const updatedMembers = [
        ...(selectedGroupForMembers.members || []),
        {
          id: data.memberId,
          group_id: selectedGroupForMembers.id,
          member_name: newMemberName.trim(),
          member_phone: newMemberPhone.trim(),
          role: 'Member',
        },
      ];
      setSelectedGroupForMembers({
        ...selectedGroupForMembers,
        members: updatedMembers,
        members_count: updatedMembers.length,
      });
    } catch (err: any) {
      setMemberError(err.message || 'Error adding member.');
    } finally {
      setMemberLoading(false);
    }
  };

  // Remove member from group
  const handleRemoveMember = async (memberId: number) => {
    if (!selectedGroupForMembers) return;
    try {
      const res = await fetch(
        `/api/admin/groups/${selectedGroupForMembers.id}/members/${memberId}`,
        {
          method: 'DELETE',
          headers: { Authorization: `Bearer ${token}` },
        }
      );
      if (res.ok) {
        const remaining = (selectedGroupForMembers.members || []).filter((m) => m.id !== memberId);
        setSelectedGroupForMembers({
          ...selectedGroupForMembers,
          members: remaining,
          members_count: remaining.length,
        });
        fetchGroups();
      }
    } catch (err) {
      console.error(err);
    }
  };

  const filteredGroups = groups.filter((g) => {
    const term = search.toLowerCase();
    return (
      g.group_name.toLowerCase().includes(term) ||
      g.group_id.toLowerCase().includes(term) ||
      g.leader_name.toLowerCase().includes(term) ||
      (g.location_name && g.location_name.toLowerCase().includes(term))
    );
  });

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-extrabold text-slate-900 flex items-center gap-2">
              <Users className="w-6 h-6 text-indigo-600" />
              Group Management & Squad Assignment
            </h2>
            <span className="bg-indigo-100 text-indigo-800 text-xs font-bold px-2.5 py-0.5 rounded-full">
              Multi-Member Squads
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Create collection groups with designated leaders, unlimited members, and assigned collection venues.
          </p>
        </div>

        <button
          type="button"
          onClick={() => {
            setFormError('');
            setIsCreateOpen(true);
          }}
          className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white font-bold text-xs flex items-center gap-2 shadow-lg shadow-indigo-600/25 transition-all"
        >
          <PlusCircle className="w-4 h-4" />
          <span>Create New Group</span>
        </button>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-sm">
          <span className="text-[10px] font-bold uppercase text-slate-400 block mb-1">
            Total Squad Groups
          </span>
          <div className="text-2xl font-black font-mono text-indigo-950">{groups.length}</div>
          <span className="text-[10px] text-slate-500 mt-0.5 block">Active team units</span>
        </div>

        <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-sm">
          <span className="text-[10px] font-bold uppercase text-slate-400 block mb-1">
            Total Group Members
          </span>
          <div className="text-2xl font-black font-mono text-purple-700">
            {groups.reduce((acc, g) => acc + (Number(g.members_count) || 0), 0)}
          </div>
          <span className="text-[10px] text-slate-500 mt-0.5 block">Enrolled volunteers & collectors</span>
        </div>

        <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-sm">
          <span className="text-[10px] font-bold uppercase text-slate-400 block mb-1">
            Today's Group Collections
          </span>
          <div className="text-2xl font-black font-mono text-emerald-700">
            {currency} {groups.reduce((acc, g) => acc + (Number(g.today_collection) || 0), 0).toLocaleString()}
          </div>
          <span className="text-[10px] text-emerald-600 font-semibold mt-0.5 block">Collected today</span>
        </div>

        <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-sm">
          <span className="text-[10px] font-bold uppercase text-slate-400 block mb-1">
            Overall Group Collection
          </span>
          <div className="text-2xl font-black font-mono text-slate-900">
            {currency} {groups.reduce((acc, g) => acc + (Number(g.overall_collection) || 0), 0).toLocaleString()}
          </div>
          <span className="text-[10px] text-slate-500 mt-0.5 block">All time squad collection</span>
        </div>
      </div>

      {/* Groups Table */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-4 sm:p-5 border-b border-slate-200 bg-slate-50/50 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
          <div className="relative flex-1 max-w-md">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search by group name, ID, leader or location..."
              className="w-full pl-9 pr-3 py-1.5 rounded-xl border border-slate-300 text-xs font-medium focus:outline-none focus:ring-1 focus:ring-indigo-600"
            />
          </div>

          <div className="flex items-center gap-2 text-xs text-slate-500 font-medium">
            <span>{filteredGroups.length} Groups listed</span>
            <button
              type="button"
              onClick={fetchGroups}
              className="p-1.5 rounded-lg border border-slate-200 hover:bg-slate-100"
            >
              <RefreshCw className="w-3.5 h-3.5 text-slate-500" />
            </button>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="bg-slate-50 text-slate-500 font-semibold border-b border-slate-200 uppercase tracking-wider text-[11px]">
                <th className="py-3 px-4">Group Name & ID</th>
                <th className="py-3 px-4">Designated Leader</th>
                <th className="py-3 px-4">Assigned Location</th>
                <th className="py-3 px-4 text-center">Members Count</th>
                <th className="py-3 px-4 text-right">Today's Coll.</th>
                <th className="py-3 px-4 text-right">Overall Coll.</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {loading ? (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-slate-400 text-xs">
                    Loading collection groups...
                  </td>
                </tr>
              ) : filteredGroups.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-slate-400 text-xs">
                    No collection groups found. Click "Create New Group" to get started.
                  </td>
                </tr>
              ) : (
                filteredGroups.map((g) => (
                  <tr key={g.id} className="hover:bg-slate-50/70 transition-colors">
                    <td className="py-4 px-4">
                      <div className="flex items-center gap-2.5">
                        <div className="w-8 h-8 rounded-xl bg-indigo-100 text-indigo-800 font-black text-xs flex items-center justify-center flex-shrink-0">
                          {g.group_name.substring(0, 1)}
                        </div>
                        <div>
                          <span className="font-bold text-slate-900 block">{g.group_name}</span>
                          <span className="text-[10px] text-indigo-700 font-mono font-bold">
                            {g.group_id}
                          </span>
                        </div>
                      </div>
                    </td>

                    <td className="py-4 px-4 whitespace-nowrap">
                      <div className="flex items-center gap-1.5 font-bold text-slate-800">
                        <Crown className="w-3.5 h-3.5 text-amber-500" />
                        <span>{g.leader_name}</span>
                      </div>
                      <span className="text-[10px] text-slate-400 font-mono block">
                        📱 {g.leader_phone}
                      </span>
                    </td>

                    <td className="py-4 px-4">
                      {g.location_name ? (
                        <span className="inline-flex items-center gap-1 bg-emerald-50 text-emerald-800 border border-emerald-200 text-[10px] font-semibold px-2.5 py-0.5 rounded-full">
                          <MapPin className="w-2.5 h-2.5 text-emerald-600" />
                          {g.location_name}
                        </span>
                      ) : (
                        <span className="text-slate-400 italic text-[11px]">Unassigned</span>
                      )}
                    </td>

                    <td className="py-4 px-4 text-center whitespace-nowrap">
                      <button
                        type="button"
                        onClick={() => setSelectedGroupForMembers(g)}
                        className="inline-flex items-center gap-1 bg-purple-50 hover:bg-purple-100 text-purple-800 font-bold px-2.5 py-1 rounded-xl text-xs transition-colors border border-purple-200"
                      >
                        <Users className="w-3 h-3 text-purple-600" />
                        <span>{g.members_count || 0} Members</span>
                      </button>
                    </td>

                    <td className="py-4 px-4 text-right font-mono font-bold text-indigo-900 whitespace-nowrap">
                      {currency} {Number(g.today_collection || 0).toLocaleString()}
                    </td>

                    <td className="py-4 px-4 text-right font-mono font-black text-slate-900 whitespace-nowrap">
                      {currency} {Number(g.overall_collection || 0).toLocaleString()}
                    </td>

                    <td className="py-4 px-4 text-right whitespace-nowrap">
                      <button
                        type="button"
                        onClick={() => setSelectedGroupForMembers(g)}
                        className="px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs inline-flex items-center gap-1 transition-colors"
                      >
                        <UserPlus className="w-3 h-3" />
                        <span>Manage Members</span>
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* CREATE GROUP MODAL (Requirements 1, 7, 8, 9, 10, 14, 15) */}
      {isCreateOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl shadow-2xl border border-slate-200 w-full max-w-2xl max-h-[90vh] flex flex-col overflow-hidden animate-scaleUp">
            <div className="bg-gradient-to-r from-indigo-900 to-purple-900 p-5 text-white flex items-center justify-between flex-shrink-0">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center">
                  <Users className="w-5 h-5 text-indigo-300" />
                </div>
                <div>
                  <h3 className="text-base font-extrabold text-white">Create Collection Group</h3>
                  <p className="text-[11px] text-indigo-200">
                    Designate group leader, assign collection location, and add unlimited team members
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsCreateOpen(false)}
                className="p-1 rounded-lg hover:bg-white/10 text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateGroup} className="p-6 overflow-y-auto space-y-4 flex-1">
              {formError && (
                <div className="p-3.5 rounded-xl bg-rose-50 border border-rose-200 text-xs text-rose-700 flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 text-rose-600 flex-shrink-0 mt-0.5" />
                  <span>{formError}</span>
                </div>
              )}

              {/* Group Name & Location */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">
                    Group Name <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={groupName}
                    onChange={(e) => setGroupName(e.target.value)}
                    placeholder="e.g. Falcon Squad - Batch A"
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-xs font-medium focus:outline-none focus:ring-1 focus:ring-indigo-600"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">
                    Assign Collection Location (Requirement 10)
                  </label>
                  <select
                    value={locationId}
                    onChange={(e) => setLocationId(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs font-medium bg-white focus:outline-none focus:ring-1 focus:ring-indigo-600"
                  >
                    <option value="">No Location (General Area)</option>
                    {locations.map((loc) => (
                      <option key={loc.id} value={loc.id}>
                        {loc.name} ({loc.location_code})
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Designated Group Leader (Requirement 7) */}
              <div className="p-4 rounded-2xl bg-amber-50/60 border border-amber-200 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-extrabold text-amber-900 flex items-center gap-1.5">
                    <Crown className="w-4 h-4 text-amber-600" /> Designated Group Leader <span className="text-rose-500">*</span>
                  </span>
                  {students.length > 0 && (
                    <select
                      value={leaderStudentId}
                      onChange={(e) => handleSelectLeaderStudent(e.target.value)}
                      className="px-2.5 py-1 rounded-lg border border-amber-300 text-[11px] font-medium bg-white text-slate-700"
                    >
                      <option value="">Pick Existing Student (Optional)</option>
                      {students.map((s) => (
                        <option key={s.id} value={s.student_id}>
                          {s.name} ({s.student_id})
                        </option>
                      ))}
                    </select>
                  )}
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="text-[11px] font-bold text-slate-600 block mb-1">
                      Leader Name
                    </label>
                    <input
                      type="text"
                      required
                      value={leaderName}
                      onChange={(e) => setLeaderName(e.target.value)}
                      placeholder="e.g. Mohammed Rizwan"
                      className="w-full px-3 py-1.5 rounded-xl border border-slate-300 text-xs font-medium bg-white focus:outline-none focus:ring-1 focus:ring-indigo-600"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] font-bold text-slate-600 block mb-1">
                      Leader Mobile Number
                    </label>
                    <input
                      type="tel"
                      required
                      value={leaderPhone}
                      onChange={(e) => setLeaderPhone(e.target.value)}
                      placeholder="+91 98470 12345"
                      className="w-full px-3 py-1.5 rounded-xl border border-slate-300 text-xs font-mono font-medium bg-white focus:outline-none focus:ring-1 focus:ring-indigo-600"
                    />
                  </div>
                </div>
              </div>

              {/* Unlimited Group Members (Requirement 8 & 9) */}
              <div className="space-y-2 pt-2">
                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-xs font-bold text-slate-800">
                      Additional Group Members (Unlimited)
                    </span>
                    <span className="text-[11px] text-slate-400 block">
                      Every member must have a name and mobile number
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={handleAddMemberField}
                    className="px-3 py-1 rounded-xl bg-indigo-50 hover:bg-indigo-100 text-indigo-700 text-xs font-bold flex items-center gap-1 transition-colors border border-indigo-200"
                  >
                    <PlusCircle className="w-3.5 h-3.5" />
                    <span>+ Add Member</span>
                  </button>
                </div>

                <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                  {initialMembers.map((m, idx) => (
                    <div key={idx} className="flex items-center gap-2 bg-slate-50 p-2.5 rounded-xl border border-slate-200">
                      <span className="text-[11px] font-mono text-slate-400 font-bold w-5">
                        #{idx + 1}
                      </span>
                      <input
                        type="text"
                        placeholder="Member Full Name"
                        value={m.member_name}
                        onChange={(e) => handleMemberChange(idx, 'member_name', e.target.value)}
                        className="flex-1 px-3 py-1.5 rounded-lg border border-slate-300 text-xs font-medium focus:outline-none focus:ring-1 focus:ring-indigo-600 bg-white"
                      />
                      <input
                        type="tel"
                        placeholder="Mobile Number"
                        value={m.member_phone}
                        onChange={(e) => handleMemberChange(idx, 'member_phone', e.target.value)}
                        className="w-40 px-3 py-1.5 rounded-lg border border-slate-300 text-xs font-mono font-medium focus:outline-none focus:ring-1 focus:ring-indigo-600 bg-white"
                      />
                      {initialMembers.length > 1 && (
                        <button
                          type="button"
                          onClick={() => handleRemoveMemberField(idx)}
                          className="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg hover:bg-slate-200"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              {/* Notes */}
              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">
                  Notes / Instructions (Optional)
                </label>
                <textarea
                  rows={2}
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Special instructions, assigned territory or purpose..."
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs font-medium focus:outline-none focus:ring-1 focus:ring-indigo-600"
                />
              </div>

              <div className="pt-3 border-t border-slate-200 flex items-center justify-end gap-2 flex-shrink-0">
                <button
                  type="button"
                  onClick={() => setIsCreateOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={formLoading}
                  className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shadow disabled:opacity-50"
                >
                  {formLoading ? 'Creating Group...' : 'Save & Create Group'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MANAGE GROUP MEMBERS MODAL (Requirement 8 & 9) */}
      {selectedGroupForMembers && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl shadow-2xl border border-slate-200 w-full max-w-xl max-h-[90vh] flex flex-col overflow-hidden animate-scaleUp">
            <div className="bg-gradient-to-r from-purple-900 via-indigo-900 to-slate-900 p-5 text-white flex items-center justify-between flex-shrink-0">
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-base font-extrabold text-white">
                    {selectedGroupForMembers.group_name}
                  </h3>
                  <span className="font-mono text-[10px] bg-white/20 px-2 py-0.5 rounded font-bold">
                    {selectedGroupForMembers.group_id}
                  </span>
                </div>
                <p className="text-[11px] text-purple-200 mt-0.5">
                  Leader: {selectedGroupForMembers.leader_name} • Location: {selectedGroupForMembers.location_name || 'General'}
                </p>
              </div>
              <button
                type="button"
                onClick={() => setSelectedGroupForMembers(null)}
                className="p-1 rounded-lg hover:bg-white/10 text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 overflow-y-auto space-y-5 flex-1">
              {/* Form to Add New Member to This Group */}
              <form onSubmit={handleAddMemberToGroup} className="bg-purple-50/60 border border-purple-200 rounded-2xl p-4 space-y-3">
                <span className="text-xs font-bold text-purple-900 block flex items-center gap-1.5">
                  <UserPlus className="w-4 h-4 text-purple-600" /> Add New Group Member
                </span>

                {memberError && (
                  <div className="text-xs text-rose-600 font-semibold">{memberError}</div>
                )}

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  <input
                    type="text"
                    required
                    placeholder="Member Full Name"
                    value={newMemberName}
                    onChange={(e) => setNewMemberName(e.target.value)}
                    className="px-3.5 py-1.5 rounded-xl border border-slate-300 text-xs font-medium bg-white focus:outline-none focus:ring-1 focus:ring-purple-600"
                  />
                  <input
                    type="tel"
                    required
                    placeholder="Member Mobile Number"
                    value={newMemberPhone}
                    onChange={(e) => setNewMemberPhone(e.target.value)}
                    className="px-3.5 py-1.5 rounded-xl border border-slate-300 text-xs font-mono font-medium bg-white focus:outline-none focus:ring-1 focus:ring-purple-600"
                  />
                </div>

                <div className="flex justify-end">
                  <button
                    type="submit"
                    disabled={memberLoading}
                    className="px-4 py-1.5 rounded-xl bg-purple-600 hover:bg-purple-700 text-white text-xs font-bold shadow disabled:opacity-50"
                  >
                    {memberLoading ? 'Adding...' : '+ Add Member to Squad'}
                  </button>
                </div>
              </form>

              {/* Members List */}
              <div>
                <span className="text-xs font-bold text-slate-800 block mb-2">
                  Enrolled Members ({selectedGroupForMembers.members?.length || 0})
                </span>

                <div className="space-y-2">
                  {(selectedGroupForMembers.members || []).map((m) => (
                    <div
                      key={m.id}
                      className="p-3 rounded-2xl bg-slate-50 border border-slate-200 flex items-center justify-between text-xs"
                    >
                      <div className="flex items-center gap-2.5">
                        <div className={`w-7 h-7 rounded-lg flex items-center justify-center font-bold text-xs ${
                          m.role === 'Leader'
                            ? 'bg-amber-100 text-amber-800'
                            : 'bg-indigo-100 text-indigo-800'
                        }`}>
                          {m.member_name.substring(0, 1)}
                        </div>
                        <div>
                          <div className="flex items-center gap-1.5">
                            <span className="font-bold text-slate-900">{m.member_name}</span>
                            {m.role === 'Leader' && (
                              <span className="bg-amber-100 text-amber-800 text-[10px] font-bold px-1.5 py-0.2 rounded flex items-center gap-0.5">
                                <Crown className="w-2.5 h-2.5" /> Leader
                              </span>
                            )}
                          </div>
                          <span className="text-[11px] text-slate-500 font-mono">
                            📱 {m.member_phone}
                          </span>
                        </div>
                      </div>

                      {m.role !== 'Leader' && (
                        <button
                          type="button"
                          onClick={() => handleRemoveMember(m.id!)}
                          className="p-1 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50"
                          title="Remove member"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="p-4 bg-slate-50 border-t border-slate-200 flex justify-end flex-shrink-0">
              <button
                type="button"
                onClick={() => setSelectedGroupForMembers(null)}
                className="px-5 py-2 rounded-xl bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold text-xs"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

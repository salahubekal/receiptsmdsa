import React, { useState, useEffect } from 'react';
import {
  GraduationCap,
  PlusCircle,
  Search,
  KeyRound,
  Edit2,
  Trash2,
  Eye,
  CheckCircle,
  AlertCircle,
  Phone,
  Mail,
  MapPin,
  Users,
  ShieldAlert,
  Clock,
  X,
  Copy,
  Check,
  RefreshCw,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { StudentStats, LocationRecord, GroupRecord, Settings } from '../types';

interface Props {
  settings: Partial<Settings>;
  onViewStudentDetails: (studentId: string) => void;
}

export const AdminStudentManagement: React.FC<Props> = ({ settings, onViewStudentDetails }) => {
  const currency = settings.currency_symbol || '₹';
  const token = localStorage.getItem('receipt_auth_token');

  const [students, setStudents] = useState<StudentStats[]>([]);
  const [locations, setLocations] = useState<LocationRecord[]>([]);
  const [groups, setGroups] = useState<GroupRecord[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [search, setSearch] = useState<string>('');

  // Modals
  const [isRegisterOpen, setIsRegisterOpen] = useState<boolean>(false);
  const [resetModalStudent, setResetModalStudent] = useState<StudentStats | null>(null);
  const [editingStudent, setEditingStudent] = useState<StudentStats | null>(null);

  // Form states for Registration
  const [regName, setRegName] = useState<string>('');
  const [regPhone, setRegPhone] = useState<string>('');
  const [regEmail, setRegEmail] = useState<string>('');
  const [regClass, setRegClass] = useState<string>('MDSA Batch 2026');
  const [regLocationId, setRegLocationId] = useState<string>('');
  const [regGroupId, setRegGroupId] = useState<string>('');
  const [regError, setRegError] = useState<string>('');
  const [regLoading, setRegLoading] = useState<boolean>(false);
  const [createdSummary, setCreatedSummary] = useState<any>(null);

  // Password reset state
  const [customPassword, setCustomPassword] = useState<string>('');
  const [resetSuccessMsg, setResetSuccessMsg] = useState<string>('');
  const [resetLoading, setResetLoading] = useState<boolean>(false);
  const [copied, setCopied] = useState<boolean>(false);

  const fetchData = async () => {
    setLoading(true);
    try {
      const [studentsRes, locsRes, grpsRes] = await Promise.all([
        fetch('/api/admin/students', { headers: { Authorization: `Bearer ${token}` } }),
        fetch('/api/admin/locations', { headers: { Authorization: `Bearer ${token}` } }),
        fetch('/api/admin/groups', { headers: { Authorization: `Bearer ${token}` } }),
      ]);

      if (studentsRes.ok) setStudents(await studentsRes.json());
      if (locsRes.ok) setLocations(await locsRes.json());
      if (grpsRes.ok) setGroups(await grpsRes.json());
    } catch (err) {
      console.error('Failed to load admin student data:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleRegisterStudent = async (e: React.FormEvent) => {
    e.preventDefault();
    setRegError('');

    if (!regName.trim() || !regPhone.trim()) {
      setRegError('Student Name and Mobile Number are required.');
      return;
    }

    setRegLoading(true);
    try {
      const res = await fetch('/api/admin/students', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          name: regName.trim(),
          phone: regPhone.trim(),
          email: regEmail.trim(),
          class_name: regClass.trim(),
          location_id: regLocationId ? parseInt(regLocationId, 10) : null,
          group_id: regGroupId,
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        setRegError(data.error || 'Failed to register student.');
        setRegLoading(false);
        return;
      }

      confetti({
        particleCount: 80,
        spread: 60,
        origin: { y: 0.6 },
      });

      setCreatedSummary(data.student);
      fetchData();

      // Reset form
      setRegName('');
      setRegPhone('');
      setRegEmail('');
      setRegLocationId('');
      setRegGroupId('');
    } catch (err: any) {
      setRegError(err.message || 'Error creating student.');
    } finally {
      setRegLoading(false);
    }
  };

  const handleResetPassword = async () => {
    if (!resetModalStudent) return;
    setResetLoading(true);
    try {
      const res = await fetch(`/api/admin/students/${resetModalStudent.id}/reset-password`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          custom_password: customPassword.trim(),
        }),
      });

      const data = await res.json();
      if (res.ok) {
        setResetSuccessMsg(data.message);
        fetchData();
      }
    } catch (err) {
      console.error('Failed to reset password:', err);
    } finally {
      setResetLoading(false);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const filteredStudents = students.filter((s) => {
    const term = search.toLowerCase();
    return (
      s.name.toLowerCase().includes(term) ||
      s.student_id.toLowerCase().includes(term) ||
      s.phone.includes(term) ||
      (s.location_name && s.location_name.toLowerCase().includes(term)) ||
      (s.group_name && s.group_name.toLowerCase().includes(term))
    );
  });

  return (
    <div className="space-y-6">
      {/* Top Header & Actions */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-extrabold text-slate-900 flex items-center gap-2">
              <GraduationCap className="w-6 h-6 text-purple-600" />
              Student Registration & Management
            </h2>
            <span className="bg-purple-100 text-purple-800 text-xs font-bold px-2.5 py-0.5 rounded-full">
              Admin Exclusive
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Create individual student collector accounts, assign collection locations, and manage credentials.
          </p>
        </div>

        <button
          type="button"
          onClick={() => {
            setCreatedSummary(null);
            setRegError('');
            setIsRegisterOpen(true);
          }}
          className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white font-bold text-xs flex items-center gap-2 shadow-lg shadow-purple-600/25 transition-all"
        >
          <PlusCircle className="w-4 h-4" />
          <span>Register New Student</span>
        </button>
      </div>

      {/* Summary KPI Strip */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-sm">
          <span className="text-[10px] font-bold uppercase text-slate-400 block mb-1">
            Total Students
          </span>
          <div className="text-2xl font-black font-mono text-purple-950">
            {students.length}
          </div>
          <span className="text-[10px] text-slate-500 mt-0.5 block">Registered collectors</span>
        </div>

        <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-sm">
          <span className="text-[10px] font-bold uppercase text-slate-400 block mb-1">
            Assigned to Locations
          </span>
          <div className="text-2xl font-black font-mono text-indigo-700">
            {students.filter((s) => s.location_name).length}
          </div>
          <span className="text-[10px] text-slate-500 mt-0.5 block">With designated venues</span>
        </div>

        <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-sm">
          <span className="text-[10px] font-bold uppercase text-slate-400 block mb-1">
            Assigned to Groups
          </span>
          <div className="text-2xl font-black font-mono text-blue-700">
            {students.filter((s) => s.group_name).length}
          </div>
          <span className="text-[10px] text-slate-500 mt-0.5 block">In squad teams</span>
        </div>

        <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-sm">
          <span className="text-[10px] font-bold uppercase text-slate-400 block mb-1">
            Total Collections
          </span>
          <div className="text-2xl font-black font-mono text-emerald-700">
            {currency} {students.reduce((acc, s) => acc + (Number(s.overall_collection) || 0), 0).toLocaleString()}
          </div>
          <span className="text-[10px] text-emerald-600 font-semibold mt-0.5 block">Cleared payments</span>
        </div>
      </div>

      {/* Student List Table */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-4 sm:p-5 border-b border-slate-200 bg-slate-50/50 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
          <div className="relative flex-1 max-w-md">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search by name, student ID, mobile or location..."
              className="w-full pl-9 pr-3 py-1.5 rounded-xl border border-slate-300 text-xs font-medium focus:outline-none focus:ring-1 focus:ring-purple-600"
            />
          </div>

          <div className="flex items-center gap-2 text-xs text-slate-500 font-medium">
            <span>Showing {filteredStudents.length} of {students.length} students</span>
            <button
              type="button"
              onClick={fetchData}
              className="p-1.5 rounded-lg border border-slate-200 hover:bg-slate-100"
              title="Refresh student list"
            >
              <RefreshCw className="w-3.5 h-3.5 text-slate-500" />
            </button>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="bg-slate-50 text-slate-500 font-semibold border-b border-slate-200 uppercase tracking-wider text-[11px]">
                <th className="py-3 px-4">Student Name & Username</th>
                <th className="py-3 px-4">Student ID</th>
                <th className="py-3 px-4">Mobile & Contact</th>
                <th className="py-3 px-4">Assigned Location</th>
                <th className="py-3 px-4">Assigned Group</th>
                <th className="py-3 px-4 text-right">Today's Coll.</th>
                <th className="py-3 px-4 text-right">Total Coll.</th>
                <th className="py-3 px-4 text-center">First Login</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {loading ? (
                <tr>
                  <td colSpan={9} className="py-12 text-center text-slate-400 text-xs">
                    Loading student collector accounts...
                  </td>
                </tr>
              ) : filteredStudents.length === 0 ? (
                <tr>
                  <td colSpan={9} className="py-12 text-center text-slate-400 text-xs">
                    No students found matching your search.
                  </td>
                </tr>
              ) : (
                filteredStudents.map((s) => (
                  <tr key={s.id} className="hover:bg-slate-50/70 transition-colors">
                    <td className="py-3.5 px-4">
                      <div className="flex items-center gap-2.5">
                        <div className="w-8 h-8 rounded-xl bg-purple-100 text-purple-800 font-black text-xs flex items-center justify-center flex-shrink-0">
                          {s.name.substring(0, 1)}
                        </div>
                        <div>
                          <span className="font-bold text-slate-900 block">{s.name}</span>
                          <span className="text-[10px] text-slate-400 font-mono block">
                            User: {s.username || s.name}
                          </span>
                        </div>
                      </div>
                    </td>

                    <td className="py-3.5 px-4 font-mono font-bold text-purple-900 whitespace-nowrap">
                      {s.student_id}
                    </td>

                    <td className="py-3.5 px-4 whitespace-nowrap">
                      <div className="font-medium text-slate-800 font-mono flex items-center gap-1">
                        <Phone className="w-3 h-3 text-slate-400" /> {s.phone}
                      </div>
                      {s.email && (
                        <div className="text-[10px] text-slate-400 flex items-center gap-1 mt-0.5">
                          <Mail className="w-2.5 h-2.5 text-slate-400" /> {s.email}
                        </div>
                      )}
                    </td>

                    <td className="py-3.5 px-4">
                      {s.location_name ? (
                        <span className="inline-flex items-center gap-1 bg-emerald-50 text-emerald-800 border border-emerald-200/80 text-[10px] font-semibold px-2 py-0.5 rounded-full">
                          <MapPin className="w-2.5 h-2.5 text-emerald-600" />
                          {s.location_name}
                        </span>
                      ) : (
                        <span className="text-[11px] text-slate-400 italic">Unassigned</span>
                      )}
                    </td>

                    <td className="py-3.5 px-4">
                      {s.group_name ? (
                        <span className="inline-flex items-center gap-1 bg-indigo-50 text-indigo-800 border border-indigo-200/80 text-[10px] font-semibold px-2 py-0.5 rounded-full">
                          <Users className="w-2.5 h-2.5 text-indigo-600" />
                          {s.group_name}
                        </span>
                      ) : (
                        <span className="text-[11px] text-slate-400 italic">Individual</span>
                      )}
                    </td>

                    <td className="py-3.5 px-4 text-right font-mono font-bold text-purple-900 whitespace-nowrap">
                      {currency} {Number(s.today_collection || 0).toLocaleString()}
                    </td>

                    <td className="py-3.5 px-4 text-right font-mono font-black text-slate-900 whitespace-nowrap">
                      {currency} {Number(s.overall_collection || 0).toLocaleString()}
                    </td>

                    <td className="py-3.5 px-4 text-center whitespace-nowrap">
                      {s.must_change_password ? (
                        <span className="inline-block bg-amber-100 text-amber-800 text-[10px] font-bold px-2 py-0.5 rounded-full">
                          Change Required
                        </span>
                      ) : (
                        <span className="inline-block bg-slate-100 text-slate-600 text-[10px] font-semibold px-2 py-0.5 rounded-full">
                          Active Secured
                        </span>
                      )}
                    </td>

                    <td className="py-3.5 px-4 text-right whitespace-nowrap">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          type="button"
                          onClick={() => {
                            setCustomPassword('');
                            setResetSuccessMsg('');
                            setResetModalStudent(s);
                          }}
                          className="px-2 py-1 rounded-lg bg-amber-50 hover:bg-amber-100 text-amber-800 text-[11px] font-bold flex items-center gap-1 transition-colors border border-amber-200"
                          title="Reset student password"
                        >
                          <KeyRound className="w-3 h-3 text-amber-600" />
                          <span>Reset Pwd</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => onViewStudentDetails(s.student_id)}
                          className="px-2 py-1 rounded-lg bg-purple-50 hover:bg-purple-100 text-purple-800 text-[11px] font-bold flex items-center gap-1 transition-colors border border-purple-200"
                          title="View student collection details"
                        >
                          <Eye className="w-3 h-3 text-purple-600" />
                          <span>Details</span>
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* REGISTRATION MODAL (Requirements 1, 2, 3, 4, 10, 14, 15) */}
      {isRegisterOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl shadow-2xl border border-slate-200 w-full max-w-xl overflow-hidden animate-scaleUp">
            <div className="bg-gradient-to-r from-purple-900 via-indigo-900 to-blue-900 p-5 text-white flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center">
                  <GraduationCap className="w-5 h-5 text-purple-300" />
                </div>
                <div>
                  <h3 className="text-base font-extrabold text-white">Register Student Collector</h3>
                  <p className="text-[11px] text-purple-200">
                    Administrator creation with auto-generated ID & mobile initial password
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsRegisterOpen(false)}
                className="p-1 rounded-lg hover:bg-white/10 text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* If Student was just created, show credentials box */}
            {createdSummary ? (
              <div className="p-6 space-y-4">
                <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-4 text-xs">
                  <div className="flex items-center gap-2 text-emerald-900 font-bold text-sm mb-2">
                    <CheckCircle className="w-4 h-4 text-emerald-600" /> Student Successfully Registered!
                  </div>
                  <p className="text-emerald-700 leading-relaxed mb-3">
                    The student can now log in on the 3D portal with their registered name and mobile number. They will be prompted to change their password on first login.
                  </p>

                  <div className="bg-white rounded-xl p-3 border border-emerald-200 font-mono space-y-1.5 text-[11px]">
                    <div className="flex justify-between">
                      <span className="text-slate-500 font-sans">Student ID:</span>
                      <span className="font-bold text-purple-900">{createdSummary.student_id}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500 font-sans">Login Username:</span>
                      <span className="font-bold text-slate-800">{createdSummary.username}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500 font-sans">Initial Password:</span>
                      <span className="font-bold text-emerald-700">{createdSummary.initialPassword}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500 font-sans">Location:</span>
                      <span className="font-bold text-slate-700">{createdSummary.location_name || 'None'}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500 font-sans">Group:</span>
                      <span className="font-bold text-slate-700">{createdSummary.group_name || 'Individual'}</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <button
                    type="button"
                    onClick={() =>
                      copyToClipboard(
                        `MDSA Portal Student Login:\nUsername: ${createdSummary.username}\nPassword: ${createdSummary.initialPassword}\nStudent ID: ${createdSummary.student_id}\nURL: ${window.location.origin}`
                      )
                    }
                    className="flex-1 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow"
                  >
                    {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                    <span>{copied ? 'Copied to Clipboard!' : 'Copy Login Credentials'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setCreatedSummary(null);
                      setIsRegisterOpen(false);
                    }}
                    className="px-5 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs"
                  >
                    Done
                  </button>
                </div>
              </div>
            ) : (
              <form onSubmit={handleRegisterStudent} className="p-6 space-y-4">
                {regError && (
                  <div className="p-3.5 rounded-xl bg-rose-50 border border-rose-200 text-xs text-rose-700 flex items-start gap-2">
                    <AlertCircle className="w-4 h-4 text-rose-600 flex-shrink-0 mt-0.5" />
                    <span>{regError}</span>
                  </div>
                )}

                {/* Important Rules Info Box */}
                <div className="bg-purple-50/70 border border-purple-200/60 rounded-2xl p-3 text-xs text-purple-900 leading-relaxed space-y-1">
                  <div className="font-bold flex items-center gap-1.5">
                    <ShieldAlert className="w-3.5 h-3.5 text-purple-700" /> System Account Configuration
                  </div>
                  <ul className="list-disc pl-4 text-[11px] text-purple-800 space-y-0.5">
                    <li>Username will automatically be set to the registered name.</li>
                    <li>Initial password will automatically be set to the mobile number.</li>
                    <li>Password change is strictly enforced upon first login.</li>
                  </ul>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                  <div>
                    <label className="text-xs font-bold text-slate-700 block mb-1">
                      Student Full Name <span className="text-rose-500">*</span>
                    </label>
                    <input
                      type="text"
                      required
                      value={regName}
                      onChange={(e) => setRegName(e.target.value)}
                      placeholder="e.g. Tariq Mansoor"
                      className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-xs font-medium focus:outline-none focus:ring-1 focus:ring-purple-600"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-bold text-slate-700 block mb-1">
                      Mobile Number <span className="text-rose-500">*</span>
                    </label>
                    <input
                      type="tel"
                      required
                      value={regPhone}
                      onChange={(e) => setRegPhone(e.target.value)}
                      placeholder="+91 98471 22334"
                      className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-xs font-mono font-medium focus:outline-none focus:ring-1 focus:ring-purple-600"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                  <div>
                    <label className="text-xs font-bold text-slate-700 block mb-1">
                      Email Address (Optional)
                    </label>
                    <input
                      type="email"
                      value={regEmail}
                      onChange={(e) => setRegEmail(e.target.value)}
                      placeholder="student@mdsa.org"
                      className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-xs font-medium focus:outline-none focus:ring-1 focus:ring-purple-600"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-bold text-slate-700 block mb-1">
                      Class / Program Batch
                    </label>
                    <input
                      type="text"
                      value={regClass}
                      onChange={(e) => setRegClass(e.target.value)}
                      placeholder="MDSA Batch 2026"
                      className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-xs font-medium focus:outline-none focus:ring-1 focus:ring-purple-600"
                    />
                  </div>
                </div>

                {/* Assignment: Location and Group (Requirement 10) */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 pt-2 border-t border-slate-100">
                  <div>
                    <label className="text-xs font-bold text-slate-700 block mb-1">
                      Assign Collection Location
                    </label>
                    <select
                      value={regLocationId}
                      onChange={(e) => setRegLocationId(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs font-medium bg-white focus:outline-none focus:ring-1 focus:ring-purple-600"
                    >
                      <option value="">No Location (General)</option>
                      {locations.map((loc) => (
                        <option key={loc.id} value={loc.id}>
                          {loc.name} ({loc.location_code})
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="text-xs font-bold text-slate-700 block mb-1">
                      Assign to Collection Group
                    </label>
                    <select
                      value={regGroupId}
                      onChange={(e) => setRegGroupId(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs font-medium bg-white focus:outline-none focus:ring-1 focus:ring-purple-600"
                    >
                      <option value="">Individual Collector</option>
                      {groups.map((grp) => (
                        <option key={grp.id} value={grp.group_id}>
                          {grp.group_name} ({grp.group_id})
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                <div className="pt-3 border-t border-slate-200 flex items-center justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => setIsRegisterOpen(false)}
                    className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs"
                  >
                    Cancel
                  </button>

                  <button
                    type="submit"
                    disabled={regLoading}
                    className="px-5 py-2 rounded-xl bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs flex items-center gap-1.5 shadow disabled:opacity-50"
                  >
                    {regLoading ? 'Registering...' : 'Register Student'}
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}

      {/* PASSWORD RESET MODAL (Requirement 5) */}
      {resetModalStudent && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl shadow-2xl border border-slate-200 w-full max-w-md overflow-hidden animate-scaleUp">
            <div className="bg-gradient-to-r from-amber-600 to-amber-700 p-5 text-white flex items-center justify-between">
              <div className="flex items-center gap-3">
                <KeyRound className="w-6 h-6 text-amber-200" />
                <div>
                  <h3 className="text-base font-extrabold text-white">Reset Student Password</h3>
                  <p className="text-xs text-amber-100">
                    {resetModalStudent.name} ({resetModalStudent.student_id})
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setResetModalStudent(null)}
                className="p-1 rounded-lg hover:bg-white/10 text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-4">
              {resetSuccessMsg ? (
                <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-4 text-xs text-emerald-800">
                  <div className="font-bold flex items-center gap-1.5 mb-1 text-emerald-900">
                    <CheckCircle className="w-4 h-4 text-emerald-600" /> Password Reset Complete
                  </div>
                  <p className="leading-relaxed">{resetSuccessMsg}</p>
                  <button
                    type="button"
                    onClick={() => setResetModalStudent(null)}
                    className="mt-3 w-full py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs"
                  >
                    Close
                  </button>
                </div>
              ) : (
                <>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    By default, resetting will set the password back to the student's registered mobile number (<span className="font-mono font-bold text-slate-800">{resetModalStudent.phone}</span>) and force them to change it on their next login.
                  </p>

                  <div>
                    <label className="text-xs font-bold text-slate-700 block mb-1">
                      Custom Temporary Password (Optional)
                    </label>
                    <input
                      type="text"
                      value={customPassword}
                      onChange={(e) => setCustomPassword(e.target.value)}
                      placeholder="Leave blank to use registered phone number"
                      className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-xs font-mono focus:outline-none focus:ring-1 focus:ring-amber-600"
                    />
                  </div>

                  <div className="pt-2 flex items-center justify-end gap-2">
                    <button
                      type="button"
                      onClick={() => setResetModalStudent(null)}
                      className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs"
                    >
                      Cancel
                    </button>
                    <button
                      type="button"
                      onClick={handleResetPassword}
                      disabled={resetLoading}
                      className="px-5 py-2 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs disabled:opacity-50 flex items-center gap-1.5"
                    >
                      <KeyRound className="w-3.5 h-3.5" />
                      <span>{resetLoading ? 'Resetting...' : 'Confirm Reset Password'}</span>
                    </button>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

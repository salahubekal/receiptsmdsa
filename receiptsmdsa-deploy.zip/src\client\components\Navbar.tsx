import React from 'react';
import {
  FileText,
  User,
  LogOut,
  LogIn,
  Menu,
  ShieldCheck,
  Search,
  Bell,
  Settings as SettingsIcon,
  ChevronDown,
  Mail,
  LifeBuoy,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { Settings } from '../types';

interface Props {
  settings: Partial<Settings>;
  onMenuToggle: () => void;
  onOpenLogin: () => void;
  onOpenSettings?: () => void;
  searchQuery?: string;
  onSearchChange?: (q: string) => void;
}

export const Navbar: React.FC<Props> = ({
  settings,
  onMenuToggle,
  onOpenLogin,
  onOpenSettings,
  searchQuery = '',
  onSearchChange,
}) => {
  const { user, isAuthenticated, logout } = useAuth();
  const orgName = settings.org_name || 'MDSA DIGITAL RECEIPT';

  return (
    <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-slate-100">
      <div className="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
        {/* Left: Mobile Toggle & Brand Logo */}
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={onMenuToggle}
            className="md:hidden p-2 rounded-xl text-slate-600 hover:bg-slate-100 transition-colors"
          >
            <Menu className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-2.5">
            {settings.logo_image ? (
              <img
                src={settings.logo_image}
                alt="Logo"
                className="w-9 h-9 object-contain rounded-xl p-0.5"
              />
            ) : (
              <div className="w-9 h-9 rounded-xl bg-purple-600 text-white flex items-center justify-center font-bold font-serif shadow-sm">
                M
              </div>
            )}
            <div>
              <span className="font-extrabold text-sm sm:text-base text-slate-900 tracking-tight block leading-tight">
                {orgName}
              </span>
              <span className="text-[10px] text-purple-700 font-bold tracking-wider uppercase block">
                Management Portal
              </span>
            </div>
          </div>
        </div>

        {/* Center: Search Bar Pill (Matching the Model Image Header!) */}
        <div className="hidden sm:flex flex-1 max-w-md mx-4">
          <div className="relative w-full">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-2.5 pointer-events-none" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => onSearchChange && onSearchChange(e.target.value)}
              placeholder="Search receipts, payers, students, venues..."
              className="w-full bg-[#F3F4F8] hover:bg-[#EBEDF4] focus:bg-white text-slate-700 placeholder-slate-400 text-xs font-medium pl-10 pr-4 py-2 rounded-full border border-transparent focus:border-purple-300 focus:outline-none focus:ring-2 focus:ring-purple-500/20 transition-all"
            />
          </div>
        </div>

        {/* Right: Settings, Notification Bell & User Profile Pill */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Developer Support Pill */}
          <a
            href="mailto:salahubekal@gmail.com"
            title="Technical Support & Developer: salahubekal@gmail.com"
            className="flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-full bg-purple-50 hover:bg-purple-100 text-purple-700 text-[11px] sm:text-xs font-bold border border-purple-200/60 transition-colors"
          >
            <Mail className="w-3.5 h-3.5 text-purple-600 flex-shrink-0" />
            <span className="hidden sm:inline">Support</span>
          </a>

          {/* Settings Icon */}
          <button
            type="button"
            onClick={onOpenSettings}
            title="Settings & Receipt Designer"
            className="w-9 h-9 rounded-full bg-slate-50 hover:bg-slate-100 text-slate-600 flex items-center justify-center transition-colors"
          >
            <SettingsIcon className="w-4 h-4" />
          </button>

          {/* Notification Bell with Indicator */}
          <div className="relative">
            <button
              type="button"
              title="Real-time Live Sync Notifications"
              className="w-9 h-9 rounded-full bg-slate-50 hover:bg-slate-100 text-slate-600 flex items-center justify-center transition-colors"
            >
              <Bell className="w-4 h-4" />
            </button>
            <span className="w-2 h-2 rounded-full bg-emerald-500 ring-2 ring-white absolute top-1 right-1"></span>
          </div>

          {/* User Profile Pill */}
          {isAuthenticated ? (
            <div className="flex items-center gap-2 pl-1 sm:pl-2">
              <div className="flex items-center gap-2 bg-slate-50 hover:bg-slate-100 p-1 sm:pr-2.5 rounded-full border border-slate-200/60 transition-colors cursor-pointer">
                {/* Purple Circular Avatar matching model */}
                <div className="w-7 h-7 rounded-full bg-gradient-to-tr from-purple-600 to-indigo-600 text-white flex items-center justify-center text-xs font-bold shadow-xs">
                  {user?.full_name ? user.full_name.charAt(0).toUpperCase() : 'A'}
                </div>
                <span className="text-xs font-extrabold text-slate-800 hidden sm:inline">
                  {user?.full_name ? user.full_name.split(' ')[0] : user?.username || 'Admin'}
                </span>
                <ChevronDown className="w-3 h-3 text-slate-400 hidden sm:inline" />
              </div>

              {/* Logout Button */}
              <button
                type="button"
                onClick={logout}
                className="p-2 rounded-full text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors"
                title="Sign Out"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <button
              type="button"
              onClick={onOpenLogin}
              className="px-3.5 py-1.5 rounded-full bg-purple-600 hover:bg-purple-700 text-white text-xs font-bold flex items-center gap-1.5 transition-colors shadow-sm"
            >
              <LogIn className="w-3.5 h-3.5" />
              <span>Login</span>
            </button>
          )}
        </div>
      </div>
    </header>
  );
};


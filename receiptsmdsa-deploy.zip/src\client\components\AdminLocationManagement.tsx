import React, { useState, useEffect } from 'react';
import {
  MapPin,
  PlusCircle,
  Search,
  Building,
  Users,
  GraduationCap,
  Trash2,
  Edit2,
  CheckCircle,
  AlertCircle,
  X,
  RefreshCw,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { LocationRecord, Settings } from '../types';

interface Props {
  settings: Partial<Settings>;
}

export const AdminLocationManagement: React.FC<Props> = ({ settings }) => {
  const currency = settings.currency_symbol || '₹';
  const token = localStorage.getItem('receipt_auth_token');

  const [locations, setLocations] = useState<LocationRecord[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [search, setSearch] = useState<string>('');

  // Create Modal State
  const [isCreateOpen, setIsCreateOpen] = useState<boolean>(false);
  const [name, setName] = useState<string>('');
  const [cityOrArea, setCityOrArea] = useState<string>('');
  const [description, setDescription] = useState<string>('');
  const [formError, setFormError] = useState<string>('');
  const [formLoading, setFormLoading] = useState<boolean>(false);

  const fetchLocations = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/admin/locations', {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) setLocations(await res.json());
    } catch (err) {
      console.error('Failed to load locations:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchLocations();
  }, []);

  const handleCreateLocation = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError('');

    if (!name.trim()) {
      setFormError('Location Name is required.');
      return;
    }

    setFormLoading(true);
    try {
      const res = await fetch('/api/admin/locations', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          name: name.trim(),
          city_or_area: cityOrArea.trim(),
          description: description.trim(),
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        setFormError(data.error || 'Failed to create collection location.');
        setFormLoading(false);
        return;
      }

      confetti({ particleCount: 70, spread: 60, origin: { y: 0.6 } });
      setIsCreateOpen(false);
      setName('');
      setCityOrArea('');
      setDescription('');
      fetchLocations();
    } catch (err: any) {
      setFormError(err.message || 'Error creating location.');
    } finally {
      setFormLoading(false);
    }
  };

  const filteredLocations = locations.filter((loc) => {
    const term = search.toLowerCase();
    return (
      loc.name.toLowerCase().includes(term) ||
      loc.location_code.toLowerCase().includes(term) ||
      (loc.city_or_area && loc.city_or_area.toLowerCase().includes(term))
    );
  });

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-extrabold text-slate-900 flex items-center gap-2">
              <MapPin className="w-6 h-6 text-emerald-600" />
              Collection Locations & Venue Hubs
            </h2>
            <span className="bg-emerald-100 text-emerald-800 text-xs font-bold px-2.5 py-0.5 rounded-full">
              Venue Tracking
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Designate collection venues, counters, and zones for individual collectors and squads.
          </p>
        </div>

        <button
          type="button"
          onClick={() => {
            setFormError('');
            setIsCreateOpen(true);
          }}
          className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-bold text-xs flex items-center gap-2 shadow-lg shadow-emerald-600/25 transition-all"
        >
          <PlusCircle className="w-4 h-4" />
          <span>Add Collection Location</span>
        </button>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-sm">
          <span className="text-[10px] font-bold uppercase text-slate-400 block mb-1">
            Total Locations
          </span>
          <div className="text-2xl font-black font-mono text-emerald-950">{locations.length}</div>
          <span className="text-[10px] text-slate-500 mt-0.5 block">Designated collection venues</span>
        </div>

        <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-sm">
          <span className="text-[10px] font-bold uppercase text-slate-400 block mb-1">
            Assigned Students
          </span>
          <div className="text-2xl font-black font-mono text-purple-700">
            {locations.reduce((acc, l) => acc + (Number(l.assigned_students_count) || 0), 0)}
          </div>
          <span className="text-[10px] text-slate-500 mt-0.5 block">Collectors stationed</span>
        </div>

        <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-sm">
          <span className="text-[10px] font-bold uppercase text-slate-400 block mb-1">
            Assigned Groups
          </span>
          <div className="text-2xl font-black font-mono text-indigo-700">
            {locations.reduce((acc, l) => acc + (Number(l.assigned_groups_count) || 0), 0)}
          </div>
          <span className="text-[10px] text-slate-500 mt-0.5 block">Squads stationed</span>
        </div>

        <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-sm">
          <span className="text-[10px] font-bold uppercase text-slate-400 block mb-1">
            Total Venue Collections
          </span>
          <div className="text-2xl font-black font-mono text-slate-900">
            {currency} {locations.reduce((acc, l) => acc + (Number(l.overall_collection) || 0), 0).toLocaleString()}
          </div>
          <span className="text-[10px] text-slate-500 mt-0.5 block">Location intake</span>
        </div>
      </div>

      {/* Locations Table */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-4 sm:p-5 border-b border-slate-200 bg-slate-50/50 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
          <div className="relative flex-1 max-w-md">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search by venue name, code or city/area..."
              className="w-full pl-9 pr-3 py-1.5 rounded-xl border border-slate-300 text-xs font-medium focus:outline-none focus:ring-1 focus:ring-emerald-600"
            />
          </div>

          <div className="flex items-center gap-2 text-xs text-slate-500 font-medium">
            <span>{filteredLocations.length} Locations</span>
            <button
              type="button"
              onClick={fetchLocations}
              className="p-1.5 rounded-lg border border-slate-200 hover:bg-slate-100"
            >
              <RefreshCw className="w-3.5 h-3.5 text-slate-500" />
            </button>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="bg-slate-50 text-slate-500 font-semibold border-b border-slate-200 uppercase tracking-wider text-[11px]">
                <th className="py-3 px-4">Location Name</th>
                <th className="py-3 px-4">Code</th>
                <th className="py-3 px-4">Area / Zone</th>
                <th className="py-3 px-4 text-center">Assigned Collectors</th>
                <th className="py-3 px-4 text-center">Assigned Squads</th>
                <th className="py-3 px-4 text-right">Today's Coll.</th>
                <th className="py-3 px-4 text-right">Overall Coll.</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {loading ? (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-slate-400 text-xs">
                    Loading collection venues...
                  </td>
                </tr>
              ) : filteredLocations.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-slate-400 text-xs">
                    No locations found. Click "Add Collection Location" to create one.
                  </td>
                </tr>
              ) : (
                filteredLocations.map((loc) => (
                  <tr key={loc.id} className="hover:bg-slate-50/70 transition-colors">
                    <td className="py-4 px-4">
                      <div className="flex items-center gap-2.5">
                        <div className="w-8 h-8 rounded-xl bg-emerald-100 text-emerald-800 font-black text-xs flex items-center justify-center flex-shrink-0">
                          <MapPin className="w-4 h-4 text-emerald-700" />
                        </div>
                        <div>
                          <span className="font-bold text-slate-900 block">{loc.name}</span>
                          {loc.description && (
                            <span className="text-[10px] text-slate-400 block max-w-xs truncate">
                              {loc.description}
                            </span>
                          )}
                        </div>
                      </div>
                    </td>

                    <td className="py-4 px-4 font-mono font-bold text-emerald-900 whitespace-nowrap">
                      {loc.location_code}
                    </td>

                    <td className="py-4 px-4 whitespace-nowrap font-medium text-slate-700">
                      {loc.city_or_area || 'General'}
                    </td>

                    <td className="py-4 px-4 text-center whitespace-nowrap">
                      <span className="inline-block bg-purple-50 text-purple-800 border border-purple-200 px-2.5 py-0.5 rounded-full font-bold text-xs">
                        {loc.assigned_students_count || 0} Students
                      </span>
                    </td>

                    <td className="py-4 px-4 text-center whitespace-nowrap">
                      <span className="inline-block bg-indigo-50 text-indigo-800 border border-indigo-200 px-2.5 py-0.5 rounded-full font-bold text-xs">
                        {loc.assigned_groups_count || 0} Squads
                      </span>
                    </td>

                    <td className="py-4 px-4 text-right font-mono font-bold text-emerald-900 whitespace-nowrap">
                      {currency} {Number(loc.today_collection || 0).toLocaleString()}
                    </td>

                    <td className="py-4 px-4 text-right font-mono font-black text-slate-900 whitespace-nowrap">
                      {currency} {Number(loc.overall_collection || 0).toLocaleString()}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* CREATE LOCATION MODAL */}
      {isCreateOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl shadow-2xl border border-slate-200 w-full max-w-md overflow-hidden animate-scaleUp">
            <div className="bg-gradient-to-r from-emerald-800 to-teal-900 p-5 text-white flex items-center justify-between">
              <div className="flex items-center gap-3">
                <MapPin className="w-5 h-5 text-emerald-200" />
                <h3 className="text-base font-extrabold text-white">Add Collection Location</h3>
              </div>
              <button
                type="button"
                onClick={() => setIsCreateOpen(false)}
                className="p-1 rounded-lg hover:bg-white/10 text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateLocation} className="p-6 space-y-4">
              {formError && (
                <div className="p-3.5 rounded-xl bg-rose-50 border border-rose-200 text-xs text-rose-700 flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 text-rose-600 flex-shrink-0 mt-0.5" />
                  <span>{formError}</span>
                </div>
              )}

              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">
                  Location / Venue Name <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. South Campus Main Gate"
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-xs font-medium focus:outline-none focus:ring-1 focus:ring-emerald-600"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">
                  City / District / Zone
                </label>
                <input
                  type="text"
                  value={cityOrArea}
                  onChange={(e) => setCityOrArea(e.target.value)}
                  placeholder="e.g. South District"
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-xs font-medium focus:outline-none focus:ring-1 focus:ring-emerald-600"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">
                  Description / Landmark
                </label>
                <textarea
                  rows={2}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="e.g. Counter adjacent to auditorium entrance"
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-xs font-medium focus:outline-none focus:ring-1 focus:ring-emerald-600"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsCreateOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={formLoading}
                  className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow disabled:opacity-50"
                >
                  {formLoading ? 'Saving...' : 'Save Location'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

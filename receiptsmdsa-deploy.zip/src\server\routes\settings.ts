import { Router } from 'express';
import { db } from '../db/index.js';

const router = Router();

// GET /api/settings - Retrieve all settings
router.get('/', (req, res) => {
  try {
    const rows = db.prepare('SELECT key, value FROM settings').all() as { key: string; value: string }[];
    const settings: Record<string, string> = {};
    rows.forEach(r => {
      settings[r.key] = r.value;
    });
    res.json(settings);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/settings - Update multiple settings
router.post('/', (req, res) => {
  const updates = req.body;

  if (!updates || typeof updates !== 'object') {
    return res.status(400).json({ error: 'Invalid settings payload' });
  }

  try {
    const setStmt = db.prepare('INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)');
    const updateTransaction = db.transaction((items) => {
      for (const [key, val] of Object.entries(items)) {
        setStmt.run(key, typeof val === 'string' ? val : JSON.stringify(val));
      }
    });

    updateTransaction(updates);

    // Return all updated settings
    const rows = db.prepare('SELECT key, value FROM settings').all() as { key: string; value: string }[];
    const settings: Record<string, string> = {};
    rows.forEach(r => {
      settings[r.key] = r.value;
    });

    res.json({ success: true, settings });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/settings/upload-logo - Save base64 or custom logo
router.post('/upload-logo', (req, res) => {
  const { logoData } = req.body;
  if (!logoData) {
    return res.status(400).json({ error: 'Logo data required' });
  }

  try {
    db.prepare('INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)').run('logo_image', logoData);
    res.json({ success: true, message: 'Logo updated successfully' });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/settings/upload-signature - Save base64 signature
router.post('/upload-signature', (req, res) => {
  const { signatureData } = req.body;
  if (!signatureData) {
    return res.status(400).json({ error: 'Signature data required' });
  }

  try {
    db.prepare('INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)').run('signature_image', signatureData);
    res.json({ success: true, message: 'Signature updated successfully' });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

export default router;


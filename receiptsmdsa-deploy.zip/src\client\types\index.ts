export interface LineItem {
  id?: string;
  description: string;
  quantity: number;
  rate: number;
  amount: number;
}

export interface Customer {
  id: number;
  name: string;
  phone: string;
  email?: string;
  address?: string;
  notes?: string;
  total_receipts?: number;
  total_paid?: number;
  total_balance?: number;
  created_at?: string;
  updated_at?: string;
}

export interface Receipt {
  id: number;
  receipt_number: string;
  receipt_date: string;
  customer_id?: number | null;
  customer_name: string;
  customer_phone: string;
  customer_address?: string;
  student_id?: string;
  student_name?: string;
  group_id?: string;
  group_name?: string;
  collecting_member_name?: string;
  collecting_member_phone?: string;
  location_id?: number | null;
  location_name?: string;
  description: string;
  amount: number;
  payment_method: 'Cash' | 'UPI' | 'Bank Transfer' | 'Cheque' | 'Card' | 'Other' | string;
  transaction_id?: string;
  payment_status: 'Paid' | 'Partially Paid' | 'Pending';
  verification_status?: 'Self-Reported' | 'Admin Verified' | 'Flagged' | string;
  paid_amount: number;
  balance_amount: number;
  remarks?: string;
  items_json?: string;
  whatsapp_status: string;
  whatsapp_message_id?: string;
  whatsapp_sent_at?: string;
  created_at: string;
  updated_at: string;
}

export interface PaymentRecord {
  id: number;
  receipt_id?: number;
  receipt_number: string;
  student_id: string;
  student_name: string;
  group_id?: string;
  group_name?: string;
  collecting_member_name?: string;
  collecting_member_phone?: string;
  location_id?: number | null;
  location_name?: string;
  payer_name: string;
  payer_phone: string;
  amount: number;
  payment_purpose: string;
  payment_method: string;
  transaction_ref?: string;
  payment_date: string;
  verification_status: 'Self-Reported' | 'Admin Verified' | 'Flagged';
  verified_by?: string;
  verified_at?: string;
  remarks?: string;
  created_at: string;
}

export interface StudentStats {
  id: number;
  student_id: string;
  name: string;
  phone: string;
  email: string;
  class_name: string;
  location_id?: number;
  location_name?: string;
  group_id?: string;
  group_name?: string;
  username?: string;
  must_change_password?: boolean;
  today_collection: number;
  today_transactions: number;
  overall_collection: number;
  total_transactions: number;
  last_payment_time?: string;
}

export interface GroupMember {
  id?: number;
  group_id?: number;
  student_id?: string;
  member_name: string;
  member_phone: string;
  role?: 'Leader' | 'Member' | string;
}

export interface GroupRecord {
  id: number;
  group_id: string;
  group_name: string;
  leader_student_id?: string;
  leader_name: string;
  leader_phone: string;
  location_id?: number | null;
  location_name?: string;
  notes?: string;
  status: string;
  members_count?: number;
  members?: GroupMember[];
  today_collection?: number;
  today_transactions?: number;
  overall_collection?: number;
  total_transactions?: number;
  last_payment_time?: string;
  created_at?: string;
}

export interface LocationRecord {
  id: number;
  location_code: string;
  name: string;
  city_or_area?: string;
  description?: string;
  status: string;
  assigned_students_count?: number;
  assigned_groups_count?: number;
  today_collection?: number;
  today_transactions?: number;
  overall_collection?: number;
  total_transactions?: number;
  last_payment_time?: string;
  created_at?: string;
}

export interface AuditLog {
  id: number;
  receipt_id: number;
  receipt_number: string;
  action: string;
  changed_fields?: string;
  previous_data?: string;
  new_data?: string;
  performed_by: string;
  created_at: string;
}

export interface Settings {
  org_name: string;
  org_tagline: string;
  org_address: string;
  org_phone: string;
  org_email: string;
  org_tax_id: string;
  org_reg_no: string;
  currency_symbol: string;
  currency_code: string;
  receipt_prefix: string;
  receipt_start_number: string;
  primary_color: string;
  accent_color: string;
  theme_style: string;
  show_qr_code: string;
  show_signature: string;
  signatory_name: string;
  signatory_title: string;
  signature_image?: string;
  logo_image?: string;
  terms_and_conditions: string;
  whatsapp_default_message: string;
  whatsapp_cloud_api_phone_id?: string;
  whatsapp_cloud_api_token?: string;
  whatsapp_cloud_api_template?: string;
}

export interface DashboardStats {
  totalReceipts: number;
  totalAmountCollected: number;
  todayReceiptsCount: number;
  todayAmountCollected: number;
  monthlyReceiptsCount: number;
  monthlyAmountCollected: number;
  pendingCount: number;
  pendingAmount: number;
  paymentMethods: { payment_method: string; count: number; total: number }[];
}

export interface User {
  id: number;
  username: string;
  role: 'admin' | 'student';
  full_name: string;
  student_id?: string;
  customer_id?: number | null;
  must_change_password?: boolean;
}
